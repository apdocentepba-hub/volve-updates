# VOLVÉ 0.28.7 — single-file container (PILOTO / NO INSTALAR)

Fuentes Go para el empaquetado de un *único* `.exe` Windows que contiene las ocho piezas obligatorias del producto, preservando el manifiesto firmado del editor.

**Esto NO es todavía un instalador funcional.** El bootstrapper compila únicamente el comando `--verify-bundle` y rechaza cualquier otro argumento. No extrae, instala, ejecuta, toca el DNS o crea tareas SYSTEM. Las pruebas sintéticas verifican el ensamblado y la lectura sin efectos laterales. Las claves generadas por `cmd/fixture` son exclusivas de laboratorio y no autorizan una release.

El flujo de CI compila un PE con una clave pública sintética fijada en tiempo de compilación, fabrica un paquete de ocho componentes ficticios, anexa un ZIP sin compresión con tráiler de integridad, **ejecuta el `.exe` en Windows**, verifica que reconoce el manifiesto editorial sintético y exige el rechazo de una alteración de bytes. El empaquetador prohíbe sobrescribir un archivo de salida. También puede localizar el tráiler delante de un bloque Authenticode adosado al PE, pero NO verifica dicho bloque; la validación Authenticode de Windows es obligatoria en un instalador productivo.

Fuentes editables del módulo Go están en `singlefile-src.zip` con SHA-256 fijado por CI. La CI extrae ese archivo a `development/0.28.7/singlefile`, establece `replace ../unifiedbundle` y compila. Se utiliza un ZIP de fuentes para mantener coherencia con la distribución de fuentes del resto del motor piloto.

## Antes de distribuir

1. Integrar este contenedor con el instalador privado y transacciones seguras, sin subir sus fuentes privadas a este repositorio.
2. Aportar ejecutables/catálogo/políticas auténticos y verificables, no fixtures.
3. Incrustar una clave pública editorial auténtica, firmar el EXE final con Authenticode y validar con WinVerifyTrust.
4. Extraer únicamente a un área NTFS privada bajo identidad autorizada, revalidar hashes y ACL, y ejecutar instalación o actualización con watchdog SYSTEM y rollback.
5. Probar instalación limpia, upgrade real 0.28.6 -> 0.28.7, interrupción, reboot persistente, DNS v4/v6 e Internet.

**NO MERGE / NO RELEASE** hasta esos hitos. Ningún host productivo se modifica en esta etapa.
