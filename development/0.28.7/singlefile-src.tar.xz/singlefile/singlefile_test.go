package singlefile

import (
	"archive/zip"
	"bytes"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	"volve.local/installer/unifiedbundle"
)

func fixture(t *testing.T) (string, ed25519.PublicKey, ed25519.PrivateKey) {
	t.Helper()
	root := t.TempDir()
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	m := unifiedbundle.Manifest{Schema: 1, Release: "0.28.7", Platform: "windows-amd64"}
	for id, name := range unifiedbundle.RequiredFiles() {
		data := []byte("test synthetic " + id)
		if err := os.WriteFile(filepath.Join(root, name), data, 0600); err != nil {
			t.Fatal(err)
		}
		hash := sha256.Sum256(data)
		m.Components = append(m.Components, unifiedbundle.Component{ID: id, File: name, Size: int64(len(data)), SHA256: hex.EncodeToString(hash[:])})
	}
	raw, err := json.Marshal(m)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(root, "manifest.json"), raw, 0600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(root, "manifest.ed25519"), ed25519.Sign(priv, raw), 0600); err != nil {
		t.Fatal(err)
	}
	return root, pub, priv
}
func fakePE(t *testing.T) string {
	t.Helper()
	path := filepath.Join(t.TempDir(), "boot.exe")
	b := make([]byte, 512)
	copy(b[:2], "MZ")
	binary.LittleEndian.PutUint32(b[0x3c:0x40], 0x80)
	copy(b[0x80:0x84], []byte{'P', 'E', 0, 0})
	binary.LittleEndian.PutUint16(b[0x80+24:0x80+26], 0x20b)
	if err := os.WriteFile(path, b, 0600); err != nil {
		t.Fatal(err)
	}
	return path
}
func TestSingleFileBuildAndInspectNoInstallation(t *testing.T) {
	root, pub, _ := fixture(t)
	exe := filepath.Join(t.TempDir(), "VOLVE_Setup_LAB_NO_INSTALAR.exe")
	if err := Assemble(fakePE(t), root, exe, pub); err != nil {
		t.Fatal(err)
	}
	m, err := InspectExecutable(exe, pub)
	if err != nil {
		t.Fatal(err)
	}
	if len(m.Components) != 8 {
		t.Fatal("wrong number of signed assets")
	}
	// A second attempt may never overwrite an output silently.
	if err := Assemble(fakePE(t), root, exe, pub); err == nil {
		t.Fatal("replaced existing exe")
	}
}
func TestRejectWrongKeyAlteredFooterAndTruncatedEXE(t *testing.T) {
	root, pub, _ := fixture(t)
	exe := filepath.Join(t.TempDir(), "test.exe")
	if err := Assemble(fakePE(t), root, exe, pub); err != nil {
		t.Fatal(err)
	}
	other, _, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := InspectExecutable(exe, other); err == nil {
		t.Fatal("wrong publisher accepted")
	}
	raw, err := os.ReadFile(exe)
	if err != nil {
		t.Fatal(err)
	}
	raw[len(raw)-footerSize-1] ^= 1
	altered := filepath.Join(t.TempDir(), "altered.exe")
	if err := os.WriteFile(altered, raw, 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := InspectExecutable(altered, pub); err == nil {
		t.Fatal("modified ZIP accepted")
	}
	short := filepath.Join(t.TempDir(), "truncated.exe")
	if err := os.WriteFile(short, raw[:len(raw)-8], 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := InspectExecutable(short, pub); err == nil {
		t.Fatal("truncated footer accepted")
	}
}
func TestRejectMissingSignedAssetBeforeOutput(t *testing.T) {
	root, pub, _ := fixture(t)
	if err := os.Remove(filepath.Join(root, "VOLVE_Uninstall.exe")); err != nil {
		t.Fatal(err)
	}
	out := filepath.Join(t.TempDir(), "exe.exe")
	if err := Assemble(fakePE(t), root, out, pub); err == nil {
		t.Fatal("missing uninstaller accepted")
	}
	if _, err := os.Stat(out); !os.IsNotExist(err) {
		t.Fatal("partial EXE left after failed preflight")
	}
}
func TestRejectArchiveDuplicateEntryAndUnexpectedFile(t *testing.T) {
	root, pub, _ := fixture(t)
	var b bytes.Buffer
	zw := zip.NewWriter(&b)
	for _, name := range []string{"manifest.json", "manifest.ed25519", "manifest.json"} {
		fh := &zip.FileHeader{Name: name, Method: zip.Store}
		fh.SetMode(0600)
		w, err := zw.CreateHeader(fh)
		if err != nil {
			t.Fatal(err)
		}
		data, err := os.ReadFile(filepath.Join(root, name))
		if err != nil {
			t.Fatal(err)
		}
		if _, err := w.Write(data); err != nil {
			t.Fatal(err)
		}
	}
	if err := zw.Close(); err != nil {
		t.Fatal(err)
	}
	if _, err := VerifyPayloadBytes(b.Bytes(), pub); err == nil {
		t.Fatal("duplicate ZIP accepted")
	}
}
func TestRequiredFilesCannotBeModifiedByCaller(t *testing.T) {
	files := unifiedbundle.RequiredFiles()
	files["system-watchdog"] = "evil.exe"
	if unifiedbundle.RequiredFiles()["system-watchdog"] == "evil.exe" {
		t.Fatal("mutable required allowlist")
	}
}

func TestSignedPEOverlayLocatesFooterBeforeCertificate(t *testing.T) {
	root, pub, _ := fixture(t)
	exe := filepath.Join(t.TempDir(), "pre-cert.exe")
	if err := Assemble(fakePE(t), root, exe, pub); err != nil {
		t.Fatal(err)
	}
	raw, err := os.ReadFile(exe)
	if err != nil {
		t.Fatal(err)
	}
	// The security directory is in the PE optional header.
	certOffset := len(raw)
	padding := (8 - certOffset%8) % 8
	dataDirectory := 0x80 + 24 + 112
	binary.LittleEndian.PutUint32(raw[dataDirectory+32:dataDirectory+36], uint32(certOffset+padding))
	binary.LittleEndian.PutUint32(raw[dataDirectory+36:dataDirectory+40], 8)
	raw = append(raw, make([]byte, padding+8)...)
	signed := filepath.Join(t.TempDir(), "unsigned-certificate-metadata-test.exe")
	if err := os.WriteFile(signed, raw, 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := InspectExecutable(signed, pub); err != nil {
		t.Fatal("valid overlay with certificate table rejected:", err)
	}
	// The test above only exercises PE layout. No Authenticode validation is claimed.
	raw[len(raw)-1] = 7
	if err := os.WriteFile(signed, raw, 0600); err != nil {
		t.Fatal(err)
	}
	// The certificate bytes aren't authenticated here; production MUST also use WinVerifyTrust.
	if _, err := InspectExecutable(signed, pub); err != nil {
		t.Fatal("certificate validation belongs to WinVerifyTrust, not payload loader:", err)
	}
}
