package main

import (
	"crypto/ed25519"
	"encoding/hex"
	"fmt"
	"os"

	"volve.local/installer/singlefile"
)

// Supplied only at build-time by the trusted publisher's private build process.
// Empty by default: unsigned CI/source build cannot authenticate real bundles.
var trustedKeyHex string

func main() {
	if len(os.Args) != 2 || os.Args[1] != "--verify-bundle" {
		fmt.Fprintln(os.Stderr, "VOLVÉ: installation disabled; this bootstrapper only validates embedded signed assets (NO INSTALAR).")
		os.Exit(2)
	}
	decoded, err := hex.DecodeString(trustedKeyHex)
	if err != nil || len(decoded) != ed25519.PublicKeySize {
		fmt.Fprintln(os.Stderr, "VOLVÉ: no trusted publisher key compiled; bundle rejected")
		os.Exit(3)
	}
	exe, err := os.Executable()
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(4)
	}
	manifest, err := singlefile.InspectExecutable(exe, ed25519.PublicKey(decoded))
	if err != nil {
		fmt.Fprintln(os.Stderr, "VOLVÉ: signed bundle rejected:", err)
		os.Exit(5)
	}
	fmt.Printf("PASS VOLVE_SINGLEFILE_SIGNED_BUNDLE release=%s items=%d NO_INSTALL NO_DNS_CHANGE\n", manifest.Release, len(manifest.Components))
}
