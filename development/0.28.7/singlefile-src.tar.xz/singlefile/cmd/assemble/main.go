package main

import (
	"crypto/ed25519"
	"encoding/hex"
	"flag"
	"fmt"
	"os"
	"volve.local/installer/singlefile"
)

func main() {
	boot := flag.String("bootstrapper", "", "compiled Windows PE with fixed publisher public key")
	root := flag.String("bundle", "", "complete signed component folder")
	out := flag.String("out", "", "new single-file EXE path (must not exist)")
	key := flag.String("pubkey", "", "trusted publisher Ed25519 public key in hexadecimal")
	flag.Parse()
	pub, err := hex.DecodeString(*key)
	if err != nil || len(pub) != ed25519.PublicKeySize {
		fmt.Fprintln(os.Stderr, "invalid external trusted publisher key")
		os.Exit(2)
	}
	if err := singlefile.Assemble(*boot, *root, *out, ed25519.PublicKey(pub)); err != nil {
		fmt.Fprintln(os.Stderr, "REFUSE:", err)
		os.Exit(1)
	}
	fmt.Println("PASS: one Windows EXE with authenticated embedded payload; no installation, no DNS, no SYSTEM task.")
}
