// Command fixture creates synthetic CI-only inputs; never use for a release.
package main

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"volve.local/installer/unifiedbundle"
)

func main() {
	dir := flag.String("out", "", "fresh synthetic CI fixture directory")
	flag.Parse()
	if *dir == "" {
		fmt.Fprintln(os.Stderr, "--out required")
		os.Exit(1)
	}
	if err := os.Mkdir(*dir, 0700); err != nil {
		panic(err)
	}
	pub, private, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		panic(err)
	}
	m := unifiedbundle.Manifest{Schema: 1, Release: "0.28.7", Platform: "windows-amd64"}
	for id, name := range unifiedbundle.RequiredFiles() {
		data := []byte("VOLVE test-only synthetic component " + id)
		if err := os.WriteFile(filepath.Join(*dir, name), data, 0600); err != nil {
			panic(err)
		}
		sum := sha256.Sum256(data)
		m.Components = append(m.Components, unifiedbundle.Component{ID: id, File: name, Size: int64(len(data)), SHA256: hex.EncodeToString(sum[:])})
	}
	raw, err := json.Marshal(m)
	if err != nil {
		panic(err)
	}
	if err := os.WriteFile(filepath.Join(*dir, "manifest.json"), raw, 0600); err != nil {
		panic(err)
	}
	if err := os.WriteFile(filepath.Join(*dir, "manifest.ed25519"), ed25519.Sign(private, raw), 0600); err != nil {
		panic(err)
	}
	fmt.Println(hex.EncodeToString(pub))
}
