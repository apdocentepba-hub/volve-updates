// Package singlefile assembles and inspects an inert Windows PE with a
// publisher-signed VOLVE bundle appended as an authenticated PE overlay.
// It cannot install, execute or activate components.
package singlefile

import (
	"archive/zip"
	"bytes"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"volve.local/installer/unifiedbundle"
)

const (
	magic             = "VOLVE0287BUNDLE!" // 16 bytes, last 56 bytes of the EXE
	footerSize        = 16 + 8 + sha256.Size
	maxPayload  int64 = 512 << 20
	maxPE       int64 = 256 << 20
	maxPart     int64 = 256 << 20
	maxManifest int64 = 1 << 20
)

// Assemble creates a NEW, noninstalling Windows .exe. It never overwrites a
// prior output. The supplied public key must be the one pinned in the
// bootstrapper at build time; the Windows self-check in CI enforces this.
func Assemble(bootstrapper, bundleRoot, output string, trusted ed25519.PublicKey) error {
	m, err := unifiedbundle.Verify(bundleRoot, trusted)
	if err != nil {
		return fmt.Errorf("signed input bundle rejected: %w", err)
	}
	pe, err := os.ReadFile(bootstrapper)
	if err != nil {
		return err
	}
	if int64(len(pe)) > maxPE || !isPE(pe) {
		return errors.New("bootstrapper must be a valid, bounded Windows PE")
	}
	var archive bytes.Buffer
	zw := zip.NewWriter(&archive)
	names := []string{"manifest.json", "manifest.ed25519"}
	for _, c := range m.Components {
		names = append(names, c.File)
	}
	sort.Strings(names)
	totalUncompressed := int64(0)
	for _, name := range names {
		// The complete input tree has already passed the signed-bundle verifier.
		data, err := os.ReadFile(filepath.Join(bundleRoot, name))
		if err != nil {
			return err
		}
		totalUncompressed += int64(len(data))
		if totalUncompressed > maxPayload {
			return errors.New("bundle larger than single-file cap")
		}
		header := &zip.FileHeader{Name: name, Method: zip.Store}
		header.SetMode(0600)
		w, err := zw.CreateHeader(header)
		if err != nil {
			return err
		}
		if _, err := w.Write(data); err != nil {
			return err
		}
	}
	if err := zw.Close(); err != nil {
		return err
	}
	if int64(archive.Len()) > maxPayload {
		return errors.New("compressed payload exceeds allowed cap")
	}
	// Validate exact ZIP content before committing output. This also detects
	// host file drift between verifying the source and forming the payload.
	if _, err := validateArchive(archive.Bytes(), trusted); err != nil {
		return fmt.Errorf("new archive rejected: %w", err)
	}
	if output == "" || filepath.Clean(output) == filepath.Clean(bootstrapper) {
		return errors.New("output must be distinct from the bootstrapper")
	}
	out, err := os.OpenFile(output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return err
	}
	completed := false
	defer func() {
		out.Close()
		if !completed {
			os.Remove(output)
		}
	}()
	if _, err := out.Write(pe); err != nil {
		return err
	}
	payload := archive.Bytes()
	if _, err := out.Write(payload); err != nil {
		return err
	}
	trailer := make([]byte, footerSize)
	copy(trailer[:16], magic)
	binary.LittleEndian.PutUint64(trailer[16:24], uint64(len(payload)))
	digest := sha256.Sum256(payload)
	copy(trailer[24:], digest[:])
	if _, err := out.Write(trailer); err != nil {
		return err
	}
	if err := out.Sync(); err != nil {
		return err
	}
	if err := out.Close(); err != nil {
		return err
	}
	if _, err := InspectExecutable(output, trusted); err != nil {
		return fmt.Errorf("packaged exe failed readback: %w", err)
	}
	completed = true
	return nil
}

// InspectExecutable authenticates the full internal archive before any
// extraction or installation. It does NOT change the Windows host.
func InspectExecutable(path string, trusted ed25519.PublicKey) (*unifiedbundle.Manifest, error) {
	if len(trusted) != ed25519.PublicKeySize {
		return nil, errors.New("missing trusted publisher key")
	}
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	stat, err := f.Stat()
	if err != nil {
		return nil, err
	}
	if !stat.Mode().IsRegular() {
		return nil, errors.New("not a regular executable")
	}
	size := stat.Size()
	if size < footerSize+64 || size > maxPE+maxPayload+footerSize+(32<<20) {
		return nil, errors.New("exe size outside bounds")
	}
	header := make([]byte, 4096)
	count, err := f.ReadAt(header, 0)
	if err != nil && err != io.EOF {
		return nil, err
	}
	header = header[:count]
	if !isPE(header) {
		return nil, errors.New("file is not a Windows PE")
	}
	end, err := payloadLogicalEnd(f, header, size)
	if err != nil {
		return nil, err
	}
	trailer := make([]byte, footerSize)
	if _, err := f.ReadAt(trailer, end-footerSize); err != nil {
		return nil, err
	}
	if string(trailer[:16]) != magic {
		return nil, errors.New("no VOLVE signed payload footer")
	}
	n := binary.LittleEndian.Uint64(trailer[16:24])
	if n == 0 || n > uint64(maxPayload) || int64(n) > end-footerSize {
		return nil, errors.New("invalid payload length")
	}
	offset := end - footerSize - int64(n)
	if offset <= 0 || offset > maxPE {
		return nil, errors.New("invalid PE length")
	}
	section := io.NewSectionReader(f, offset, int64(n))
	hasher := sha256.New()
	if _, err := io.Copy(hasher, section); err != nil {
		return nil, err
	}
	if !bytes.Equal(hasher.Sum(nil), trailer[24:]) {
		return nil, errors.New("payload hash mismatch")
	}
	zr, err := zip.NewReader(io.NewSectionReader(f, offset, int64(n)), int64(n))
	if err != nil {
		return nil, fmt.Errorf("ZIP invalid: %w", err)
	}
	return verifyZip(zr, trusted)
}

// An Authenticode signature is appended as a WIN_CERTIFICATE table *after*
// the signed PE payload. The PE security directory uses file offsets (not RVA).
// Accept only an end-of-file certificate table; permit at most 7 bytes of
// alignment padding between the signed bundle trailer and certificate table.
// This locates the bundle; it does NOT validate the Authenticode signature.
func payloadLogicalEnd(f *os.File, hdr []byte, fileSize int64) (int64, error) {
	peOffset := int(binary.LittleEndian.Uint32(hdr[0x3c:0x40]))
	optional := peOffset + 24
	if optional+2 > len(hdr) {
		return 0, errors.New("PE optional header unavailable")
	}
	magicOpt := binary.LittleEndian.Uint16(hdr[optional : optional+2])
	var dataDirectory int
	switch magicOpt {
	case 0x20b:
		dataDirectory = optional + 112
	case 0x10b:
		dataDirectory = optional + 96
	default:
		return 0, errors.New("unsupported Windows PE optional header")
	}
	certEntry := dataDirectory + 4*8
	if certEntry+8 > len(hdr) {
		return 0, errors.New("PE certificate metadata missing")
	}
	certOffset := int64(binary.LittleEndian.Uint32(hdr[certEntry : certEntry+4]))
	certLength := int64(binary.LittleEndian.Uint32(hdr[certEntry+4 : certEntry+8]))
	if certOffset == 0 && certLength == 0 {
		return fileSize, nil
	}
	if certOffset == 0 || certLength < 8 || certOffset%8 != 0 || certOffset < 512 || certOffset > fileSize || certLength > (32<<20) || certLength != fileSize-certOffset {
		return 0, errors.New("unsafe or malformed PE certificate table")
	}
	for pad := int64(0); pad <= 7; pad++ {
		end := certOffset - pad
		if end < footerSize+64 {
			continue
		}
		marker := make([]byte, len(magic))
		if _, err := f.ReadAt(marker, end-footerSize); err != nil {
			return 0, err
		}
		if string(marker) != magic {
			continue
		}
		if pad > 0 {
			padding := make([]byte, pad)
			if _, err := f.ReadAt(padding, end); err != nil {
				return 0, err
			}
			valid := true
			for _, b := range padding {
				if b != 0 {
					valid = false
					break
				}
			}
			if !valid {
				return 0, errors.New("unexpected bytes before PE certificate")
			}
		}
		return end, nil
	}
	return 0, errors.New("signed EXE does not contain its VOLVE trailer before certificate")
}

func isPE(data []byte) bool {
	if len(data) < 0x40 || data[0] != 'M' || data[1] != 'Z' {
		return false
	}
	offset := binary.LittleEndian.Uint32(data[0x3c:0x40])
	if offset > uint32(len(data)-4) {
		return false
	}
	return bytes.Equal(data[offset:offset+4], []byte{'P', 'E', 0, 0})
}

func validateArchive(payload []byte, trusted ed25519.PublicKey) (*unifiedbundle.Manifest, error) {
	zr, err := zip.NewReader(bytes.NewReader(payload), int64(len(payload)))
	if err != nil {
		return nil, err
	}
	return verifyZip(zr, trusted)
}

func verifyZip(zr *zip.Reader, trusted ed25519.PublicKey) (*unifiedbundle.Manifest, error) {
	if len(trusted) != ed25519.PublicKeySize {
		return nil, errors.New("missing trusted key")
	}
	allowed := map[string]bool{"manifest.json": true, "manifest.ed25519": true}
	for _, name := range unifiedbundle.RequiredFiles() {
		allowed[name] = true
	}
	if len(zr.File) != len(allowed) {
		return nil, errors.New("ZIP missing components or has extras")
	}
	files := make(map[string][]byte, len(allowed))
	var total int64
	for _, part := range zr.File {
		if !fileIsCanonicalBase(part.Name) || !allowed[part.Name] || files[part.Name] != nil || !part.Mode().IsRegular() || part.UncompressedSize64 > uint64(maxPart) {
			return nil, fmt.Errorf("ZIP unexpected, duplicate, linked or oversized entry %q", part.Name)
		}
		if part.Flags&0x1 != 0 {
			return nil, errors.New("encrypted ZIP is forbidden")
		}
		limit := maxPart
		if part.Name == "manifest.json" || part.Name == "manifest.ed25519" {
			limit = maxManifest
		}
		if int64(part.UncompressedSize64) > limit {
			return nil, errors.New("ZIP entry exceeds read cap")
		}
		rc, err := part.Open()
		if err != nil {
			return nil, err
		}
		data, readErr := io.ReadAll(io.LimitReader(rc, limit+1))
		closeErr := rc.Close()
		if readErr != nil {
			return nil, readErr
		}
		if closeErr != nil {
			return nil, closeErr
		}
		if int64(len(data)) != int64(part.UncompressedSize64) || int64(len(data)) > limit {
			return nil, errors.New("ZIP entry size mismatch")
		}
		total += int64(len(data))
		if total > maxPayload {
			return nil, errors.New("ZIP uncompressed total exceeds cap")
		}
		files[part.Name] = data
	}
	raw, sig := files["manifest.json"], files["manifest.ed25519"]
	if len(raw) == 0 || len(sig) != ed25519.SignatureSize || !ed25519.Verify(trusted, raw, sig) {
		return nil, errors.New("publisher signature mismatch")
	}
	dec := json.NewDecoder(bytes.NewReader(raw))
	dec.DisallowUnknownFields()
	var m unifiedbundle.Manifest
	if err := dec.Decode(&m); err != nil {
		return nil, err
	}
	var trailing any
	if dec.Decode(&trailing) != io.EOF {
		return nil, errors.New("signed manifest trailing content")
	}
	if m.Schema != 1 || m.Release != "0.28.7" || m.Platform != "windows-amd64" {
		return nil, errors.New("signed manifest wrong version or platform")
	}
	required := unifiedbundle.RequiredFiles()
	if len(m.Components) != len(required) {
		return nil, errors.New("signed manifest incomplete")
	}
	seen := map[string]bool{}
	for _, c := range m.Components {
		expected, exists := required[c.ID]
		if !exists || seen[c.ID] || c.File != expected {
			return nil, fmt.Errorf("signed component ID or filename invalid: %q", c.ID)
		}
		seen[c.ID] = true
		part := files[c.File]
		if len(part) == 0 || c.Size != int64(len(part)) || c.Size <= 0 {
			return nil, fmt.Errorf("signed component size mismatch: %s", c.ID)
		}
		sum := sha256.Sum256(part)
		if c.SHA256 != hex.EncodeToString(sum[:]) {
			return nil, fmt.Errorf("signed component checksum mismatch: %s", c.ID)
		}
	}
	return &m, nil
}

// VerifyPayloadBytes is exposed only for tests and for future sandboxed
// integration testing; input remains inert, with no execution or disk writes.
func VerifyPayloadBytes(data []byte, trusted ed25519.PublicKey) (*unifiedbundle.Manifest, error) {
	return validateArchive(data, trusted)
}

// Fail closed on paths which could be used to confuse a Windows ZIP extractor.
func fileIsCanonicalBase(name string) bool {
	return name != "" && filepath.Base(name) == name && !strings.ContainsAny(name, "/\\\x00")
}
