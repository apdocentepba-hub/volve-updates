# Disposable Windows CI demonstration only. NEVER targets production VOLVE tasks.
# Requires a fresh hosted runner; no reboot, DNS writes, or motor service starts.
param(
 [Parameter(Mandatory=$true)][ValidateSet('switch','recover','tamper')][string]$Phase,
 [Parameter(Mandatory=$true)][string]$TaskName,
 [Parameter(Mandatory=$true)][string]$JournalExe,
 [Parameter(Mandatory=$true)][string]$Workspace
)
$ErrorActionPreference='Stop'
if($TaskName -notmatch '^VOLVE-CI-EngineRecovery-[0-9]+$'){throw 'Only numeric disposable CI task names are allowed'}
if(-not [IO.Path]::IsPathRooted($Workspace)){throw 'Workspace must be absolute'}
if(-not (Test-Path -LiteralPath $JournalExe -PathType Leaf)){throw 'Journal helper missing'}
$original=Join-Path $env:WINDIR 'System32/cmd.exe'
$candidate=Join-Path $env:WINDIR 'System32/notepad.exe'
$journal=Join-Path $Workspace 'recovery.json'
$snapshot=Join-Path $Workspace 'original-task.xml'
$old=Join-Path $Workspace 'old-engine-test.bin'
$new=Join-Path $Workspace 'candidate-engine-test.bin'
function Invoke-Journal([string[]]$argv){
  & $JournalExe @argv
  if($LASTEXITCODE -ne 0){throw ('Journal failure: '+($argv -join ' '))}
}
function Assert-TestTask([string]$expectedExe,[string]$expectedArgs){
  $task=Get-ScheduledTask -TaskName $TaskName -ErrorAction Stop
  if($task.TaskPath -ne '\'){throw 'Unexpected task namespace'}
  if($task.Principal.UserId -notin @('SYSTEM','S-1-5-18')){throw 'Unexpected task principal'}
  if(@($task.Actions).Count -ne 1){throw 'Unexpected action count'}
  $action=@($task.Actions)[0]
  if($action.Execute -ne $expectedExe){throw ('Unexpected executable: '+$action.Execute)}
  if(($action.Arguments+'').Trim() -ne $expectedArgs){throw ('Unexpected task arguments: '+$action.Arguments)}
}
if($Phase -eq 'switch'){
  if(Test-Path -LiteralPath $Workspace){throw 'Workspace must not already exist for a fresh transaction'}
  New-Item -Path $Workspace -ItemType Directory -Force | Out-Null
  if(Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue){throw 'Task already exists; refuse takeover'}
  [IO.File]::WriteAllBytes($old,[Text.Encoding]::ASCII.GetBytes('MZ_lab_old_motor_for_hash'))
  [IO.File]::WriteAllBytes($new,[Text.Encoding]::ASCII.GetBytes('MZ_lab_new_motor_for_hash'))
  $action=New-ScheduledTaskAction -Execute $original -Argument '/C exit 0'
  $trigger=New-ScheduledTaskTrigger -Once -At ((Get-Date).AddYears(1))
  Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -User SYSTEM -RunLevel Highest | Out-Null
  Assert-TestTask $original '/C exit 0'
  $xml=Export-ScheduledTask -TaskName $TaskName
  [IO.File]::WriteAllText($snapshot,$xml,[Text.UTF8Encoding]::new($false))
  # Real product must verify ACLs. This isolated runner uses only its private temp area.
  Invoke-Journal -argv @('prepare',$journal,$old,$new,$snapshot,'0.29.0')
  Invoke-Journal -argv @('advance',$journal,'switching')
  # Break point: exact original task has been persisted BEFORE any edit.
  Set-ScheduledTask -TaskName $TaskName -Action (New-ScheduledTaskAction -Execute $candidate) | Out-Null
  Assert-TestTask $candidate ''
  Invoke-Journal -argv @('advance',$journal,'proving')
  $status=& $JournalExe status $journal
  if($LASTEXITCODE -ne 0 -or $status -ne 'ROLLBACK_REQUIRED'){throw 'Journal did not mark interrupted transaction'}
  $ready=Join-Path $Workspace 'switched.ready'
  [IO.File]::WriteAllText($ready,'SWITCHED_AND_JOURNALED',[Text.Encoding]::ASCII)
  Write-Host 'READY: task switched and journal durable; runner must forcibly terminate this worker.'
  Start-Sleep -Seconds 120
  throw 'Worker was not terminated; crash simulation invalid'
}
if($Phase -eq 'recover'){
  # A NEW powershell process runs after the updater process has terminated.
  $status=& $JournalExe status $journal
  if($LASTEXITCODE -ne 0 -or $status -ne 'ROLLBACK_REQUIRED'){throw 'No verified incomplete update to restore'}
  Invoke-Journal -argv @('verify-snapshot',$journal,$snapshot)
  Invoke-Journal -argv @('verify-previous',$journal,$old)
  Assert-TestTask $candidate ''
  Invoke-Journal -argv @('advance',$journal,'restoring')
  $xml=[IO.File]::ReadAllText($snapshot)
  if(-not $xml.Contains('cmd.exe')){throw 'Unexpected task snapshot'}
  Register-ScheduledTask -TaskName $TaskName -Xml $xml -Force | Out-Null
  Assert-TestTask $original '/C exit 0'
  Invoke-Journal -argv @('advance',$journal,'restored')
  $status=& $JournalExe status $journal
  if($LASTEXITCODE -ne 0 -or $status -ne 'NO_ROLLBACK:restored'){throw 'Recovery journal not terminal'}
  Write-Host 'PASS: original SYSTEM task recovered and journal marked restored from separate process'
  exit 0
}
if($Phase -eq 'tamper'){
  # Security regression: after recovery, unauthorized snapshot change must be detected.
  [IO.File]::AppendAllText($snapshot,'<!-- tampered -->')
  & $JournalExe verify-snapshot $journal $snapshot
  if($LASTEXITCODE -eq 0){throw 'Snapshot tampering was not rejected'}
  Write-Host 'PASS: recovery helper rejected altered snapshot'
  exit 0
}
