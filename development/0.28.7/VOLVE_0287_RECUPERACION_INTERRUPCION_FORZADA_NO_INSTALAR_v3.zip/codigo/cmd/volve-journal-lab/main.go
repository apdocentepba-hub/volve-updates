// VOLVÉ CI recovery lab. NOT a production updater. The command only manipulates
// a local recovery journal; it never touches DNS, scheduled tasks, or registry.
package main

import (
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"time"
	"volve-browser-protection/motorupdate"
)

func run(args []string) error {
	if len(args) < 2 {
		return errors.New("usage: volve-journal-lab <prepare|advance|status|verify-snapshot> <journal> [args]")
	}
	verb, journal := args[0], args[1]
	switch verb {
	case "prepare":
		if len(args) != 6 {
			return errors.New("prepare requires journal, oldEngine, candidateEngine, savedTaskXml, candidateVersion")
		}
		if _, err := os.Lstat(journal); err == nil {
			return errors.New("journal already exists; refuse overwrite")
		} else if !os.IsNotExist(err) {
			return err
		}
		old, err := os.ReadFile(args[2])
		if err != nil {
			return err
		}
		candidate, err := os.ReadFile(args[3])
		if err != nil {
			return err
		}
		snapshot, err := os.ReadFile(args[4])
		if err != nil {
			return err
		}
		if len(old) == 0 || len(candidate) == 0 || len(snapshot) == 0 {
			return errors.New("empty snapshot or binaries")
		}
		j, err := motorupdate.NewRecoveryJournal(args[5], old, candidate, snapshot, time.Now().UTC())
		if err != nil {
			return err
		}
		return motorupdate.WriteRecoveryJournalDurable(journal, j)
	case "advance":
		if len(args) != 3 {
			return errors.New("advance requires journal and phase")
		}
		j, err := motorupdate.ReadRecoveryJournal(journal)
		if err != nil {
			return err
		}
		next, err := j.Next(args[2])
		if err != nil {
			return err
		}
		return motorupdate.WriteRecoveryJournalDurable(journal, next)
	case "status":
		if len(args) != 2 {
			return errors.New("status requires only journal")
		}
		j, err := motorupdate.ReadRecoveryJournal(journal)
		if err != nil {
			return err
		}
		if j.NeedsRollback() {
			fmt.Println("ROLLBACK_REQUIRED")
			return nil
		}
		fmt.Println("NO_ROLLBACK:" + j.Phase)
		return nil
	case "verify-previous":
		if len(args) != 3 {
			return errors.New("verify-previous requires journal and saved engine")
		}
		j, err := motorupdate.ReadRecoveryJournal(journal)
		if err != nil {
			return err
		}
		fi, err := os.Lstat(args[2])
		if err != nil {
			return err
		}
		if !fi.Mode().IsRegular() || fi.Size() <= 0 || fi.Size() > 80<<20 {
			return errors.New("unsafe old motor file")
		}
		data, err := os.ReadFile(args[2])
		if err != nil {
			return err
		}
		sum := sha256.Sum256(data)
		if hex.EncodeToString(sum[:]) != j.PreviousEngineSHA {
			return errors.New("previous engine hash mismatch")
		}
		fmt.Println("PREVIOUS_ENGINE_VERIFIED")
		return nil
	case "verify-snapshot":
		if len(args) != 3 {
			return errors.New("verify-snapshot requires journal and savedTaskXml")
		}
		j, err := motorupdate.ReadRecoveryJournal(journal)
		if err != nil {
			return err
		}
		file := args[2]
		fi, err := os.Lstat(file)
		if err != nil {
			return err
		}
		if !fi.Mode().IsRegular() || fi.Size() <= 0 || fi.Size() > 1024*1024 {
			return errors.New("task snapshot is not a safe regular file")
		}
		data, err := os.ReadFile(filepath.Clean(file))
		if err != nil {
			return err
		}
		sum := sha256.Sum256(data)
		if hex.EncodeToString(sum[:]) != j.OriginalTaskXMLSHA {
			return errors.New("task XML snapshot hash mismatch")
		}
		fmt.Println("TASK_SNAPSHOT_VERIFIED")
		return nil
	default:
		return errors.New("unknown recovery lab command")
	}
}
func main() {
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, "RECOVERY_LAB_FAIL:", err)
		os.Exit(1)
	}
}
