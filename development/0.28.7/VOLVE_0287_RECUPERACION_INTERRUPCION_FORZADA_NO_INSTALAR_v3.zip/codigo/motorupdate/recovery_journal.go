package motorupdate

// Recovery journal prototype for an eventual Windows task switchover.
// It is deliberately independent of any Windows API and never executes paths,
// changes DNS, or alters a scheduled task. A future privileged driver must
// authenticate task ownership, validate backup ACLs, and implement recovery.

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const RecoveryJournalSchema = 1
const recoveryJournalMaxBytes = 4096

const (
	PhasePrepared  = "prepared"  // Snapshot exists; old task still assigned.
	PhaseSwitching = "switching" // Must be durable before editing SYSTEM task.
	PhaseProving   = "proving"   // New task assigned; health verification pending.
	PhaseCommitted = "committed" // New engine probed and switch committed.
	PhaseRestoring = "restoring" // Rollback started; retry on next invocation.
	PhaseRestored  = "restored"  // Old task reinstalled and probed successfully.
)

type RecoveryJournal struct {
	Schema             int    `json:"schema"`
	Component          string `json:"component"`
	Phase              string `json:"phase"`
	PreviousEngineSHA  string `json:"previous_engine_sha256"`
	CandidateEngineSHA string `json:"candidate_engine_sha256"`
	OriginalTaskXMLSHA string `json:"original_task_xml_sha256"`
	StartedUTC         string `json:"started_utc"`
	CandidateVersion   string `json:"candidate_version"`
}

func NewRecoveryJournal(version string, oldEngine, newEngine, originalTaskXML []byte, now time.Time) (RecoveryJournal, error) {
	oldHash := sha256.Sum256(oldEngine)
	newHash := sha256.Sum256(newEngine)
	taskHash := sha256.Sum256(originalTaskXML)
	j := RecoveryJournal{
		Schema: RecoveryJournalSchema, Component: "dns-engine", Phase: PhasePrepared,
		PreviousEngineSHA:  hex.EncodeToString(oldHash[:]),
		CandidateEngineSHA: hex.EncodeToString(newHash[:]),
		OriginalTaskXMLSHA: hex.EncodeToString(taskHash[:]),
		StartedUTC:         now.UTC().Format(time.RFC3339Nano), CandidateVersion: version,
	}
	return j, j.Validate()
}

func (j RecoveryJournal) Validate() error {
	if j.Schema != RecoveryJournalSchema || j.Component != "dns-engine" || !versionRe.MatchString(j.CandidateVersion) {
		return errors.New("registro de recuperación con esquema o componente inválido")
	}
	if !hexRe.MatchString(j.PreviousEngineSHA) || !hexRe.MatchString(j.CandidateEngineSHA) || !hexRe.MatchString(j.OriginalTaskXMLSHA) {
		return errors.New("registro con huellas inválidas")
	}
	if j.PreviousEngineSHA == j.CandidateEngineSHA {
		return errors.New("el motor nuevo no debe ser idéntico al anterior")
	}
	switch j.Phase {
	case PhasePrepared, PhaseSwitching, PhaseProving, PhaseCommitted, PhaseRestoring, PhaseRestored:
	default:
		return errors.New("fase de recuperación desconocida")
	}
	parsed, err := time.Parse(time.RFC3339Nano, j.StartedUTC)
	if err != nil || parsed.Location() == nil || !strings.HasSuffix(j.StartedUTC, "Z") {
		return errors.New("fecha de transacción no es UTC")
	}
	return nil
}

// NeedsRollback is true only after the task *could* have been changed.
// Recovery must not auto-run an untrusted script based on a journal field:
// this journal intentionally stores no task command or executable path.
func (j RecoveryJournal) NeedsRollback() bool {
	return j.Phase == PhaseSwitching || j.Phase == PhaseProving || j.Phase == PhaseRestoring
}

func validTransition(from, to string) bool {
	switch from {
	case PhasePrepared:
		return to == PhaseSwitching || to == PhaseRestored
	case PhaseSwitching:
		return to == PhaseProving || to == PhaseRestoring
	case PhaseProving:
		return to == PhaseCommitted || to == PhaseRestoring
	case PhaseRestoring:
		return to == PhaseRestored
	default:
		return false
	}
}

func (j RecoveryJournal) Next(phase string) (RecoveryJournal, error) {
	if err := j.Validate(); err != nil {
		return RecoveryJournal{}, err
	}
	if !validTransition(j.Phase, phase) {
		return RecoveryJournal{}, fmt.Errorf("transición de recuperación prohibida: %s → %s", j.Phase, phase)
	}
	j.Phase = phase
	return j, nil
}

func ReadRecoveryJournal(path string) (RecoveryJournal, error) {
	var j RecoveryJournal
	st, err := os.Lstat(path)
	if err != nil {
		return j, err
	}
	if !st.Mode().IsRegular() || st.Size() <= 0 || st.Size() > recoveryJournalMaxBytes {
		return j, errors.New("registro de recuperación no regular o de tamaño inválido")
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		return j, err
	}
	dec := json.NewDecoder(bytes.NewReader(raw))
	dec.DisallowUnknownFields()
	if err := dec.Decode(&j); err != nil {
		return RecoveryJournal{}, err
	}
	var trailing any
	if dec.Decode(&trailing) != io.EOF {
		return RecoveryJournal{}, errors.New("datos sobrantes en registro")
	}
	return j, j.Validate()
}

// WriteRecoveryJournalDurable writes atomically in an ALREADY PROTECTED private
// directory. A Windows driver must set/verify SYSTEM+Administrators-only ACLs
// on this directory before first use. Atomic rename is not a substitute for
// independent startup recovery or for durable fsync of the underlying drive.
func WriteRecoveryJournalDurable(path string, next RecoveryJournal) error {
	if err := next.Validate(); err != nil {
		return err
	}
	dir := filepath.Dir(path)
	st, err := os.Lstat(dir)
	if err != nil {
		return err
	}
	if !st.IsDir() || st.Mode()&os.ModeSymlink != 0 {
		return errors.New("directorio de journal no autorizado")
	}
	if current, err := ReadRecoveryJournal(path); err == nil {
		if current.Phase != next.Phase {
			allowed, e := current.Next(next.Phase)
			if e != nil {
				return e
			}
			if allowed != next {
				return errors.New("cambio no permitido de identidad de la transacción")
			}
		} else if current != next {
			return errors.New("no se puede reescribir identidad de transacción")
		}
	} else if errors.Is(err, os.ErrNotExist) {
		// A missing journal must only be initialized in PREPARED state.
		// Otherwise a tampered or orphan transaction could be replayed as
		// COMMITTED/RESTORED without ever saving the original task.
		if next.Phase != PhasePrepared {
			return errors.New("no se puede iniciar transacción sin respaldo preparado")
		}
	} else {
		return err
	}
	raw, err := json.Marshal(next)
	if err != nil {
		return err
	}
	if len(raw) > recoveryJournalMaxBytes {
		return errors.New("registro de recuperación excesivo")
	}
	f, err := os.CreateTemp(dir, ".volve-recovery-")
	if err != nil {
		return err
	}
	defer os.Remove(f.Name())
	if err = f.Chmod(0600); err != nil {
		f.Close()
		return err
	}
	if _, err = f.Write(raw); err != nil {
		f.Close()
		return err
	}
	if err = f.Sync(); err != nil {
		f.Close()
		return err
	}
	if err = f.Close(); err != nil {
		return err
	}
	return os.Rename(f.Name(), path)
}
