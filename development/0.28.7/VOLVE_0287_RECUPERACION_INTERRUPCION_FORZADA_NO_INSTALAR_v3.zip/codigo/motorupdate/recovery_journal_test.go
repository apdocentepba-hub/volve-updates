package motorupdate

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func testRecovery(t *testing.T) RecoveryJournal {
	t.Helper()
	j, err := NewRecoveryJournal("0.29.0", []byte("MZ_old"), []byte("MZ_new"), []byte("<?xml version='1.0'?><Task />"), time.Date(2026, 10, 29, 20, 0, 0, 0, time.UTC))
	if err != nil {
		t.Fatal(err)
	}
	return j
}
func TestJournalSurvivesRestartAndRequiresRollback(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "recovery.json")
	j := testRecovery(t)
	if err := WriteRecoveryJournalDurable(path, j); err != nil {
		t.Fatal(err)
	}
	got, err := ReadRecoveryJournal(path)
	if err != nil || got != j || got.NeedsRollback() {
		t.Fatalf("prepared snapshot: %+v %v", got, err)
	}
	j, _ = j.Next(PhaseSwitching)
	if err = WriteRecoveryJournalDurable(path, j); err != nil {
		t.Fatal(err)
	}
	// Simulated process death; a separate process reads the durable checkpoint.
	got, err = ReadRecoveryJournal(path)
	if err != nil || !got.NeedsRollback() {
		t.Fatalf("interrupted switchover must rollback: %+v %v", got, err)
	}
	j, _ = got.Next(PhaseRestoring)
	if err = WriteRecoveryJournalDurable(path, j); err != nil {
		t.Fatal(err)
	}
	got, err = ReadRecoveryJournal(path)
	if err != nil || !got.NeedsRollback() {
		t.Fatal("restart during rollback must retry")
	}
	j, _ = got.Next(PhaseRestored)
	if err = WriteRecoveryJournalDurable(path, j); err != nil {
		t.Fatal(err)
	}
	got, err = ReadRecoveryJournal(path)
	if err != nil || got.NeedsRollback() {
		t.Fatal("restored state should be terminal")
	}
}
func TestJournalCommitOnlyAfterProvingAndNoDowngrade(t *testing.T) {
	j := testRecovery(t)
	if _, err := j.Next(PhaseCommitted); err == nil {
		t.Fatal("commit before switch")
	}
	j, _ = j.Next(PhaseSwitching)
	if _, err := j.Next(PhaseCommitted); err == nil {
		t.Fatal("commit before probe")
	}
	j, _ = j.Next(PhaseProving)
	j, err := j.Next(PhaseCommitted)
	if err != nil || j.NeedsRollback() {
		t.Fatalf("commit failed %v", err)
	}
	if _, err = j.Next(PhaseSwitching); err == nil {
		t.Fatal("replayed completed transaction")
	}
}
func TestJournalRejectsTamperedAndUnsafeData(t *testing.T) {
	root := t.TempDir()
	file := filepath.Join(root, "recovery.json")
	j := testRecovery(t)
	if err := WriteRecoveryJournalDurable(file, j); err != nil {
		t.Fatal(err)
	}
	altered := j
	altered.PreviousEngineSHA = strings.Repeat("0", 64)
	if err := WriteRecoveryJournalDurable(file, altered); err == nil {
		t.Fatal("accepted changed previous engine hash")
	}
	raw, _ := os.ReadFile(file)
	if err := os.WriteFile(file, append(raw, []byte(`{"extra":true}`)...), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := ReadRecoveryJournal(file); err == nil {
		t.Fatal("accepted extra object")
	}
	if err := os.Remove(file); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink(filepath.Join(root, "outside.json"), file); err == nil {
		if _, err := ReadRecoveryJournal(file); err == nil {
			t.Fatal("accepted symlink journal")
		}
		if err := WriteRecoveryJournalDurable(file, j); err == nil {
			t.Fatal("accepted symlink journal overwrite")
		}
	}
}
func TestJournalDoesNotCarryExecutableOrTaskCommand(t *testing.T) {
	j := testRecovery(t)
	dir := t.TempDir()
	p := filepath.Join(dir, "recovery.json")
	if err := WriteRecoveryJournalDurable(p, j); err != nil {
		t.Fatal(err)
	}
	raw, _ := os.ReadFile(p)
	for _, bad := range []string{"task_command", "powershell", "C:\\", "/bin/sh"} {
		if strings.Contains(string(raw), bad) {
			t.Fatalf("unexpected executable path/command: %s", bad)
		}
	}
}

func TestJournalMissingFileCannotStartInProgressOrCompleted(t *testing.T) {
	for _, phase := range []string{PhaseSwitching, PhaseProving, PhaseRestoring, PhaseRestored, PhaseCommitted} {
		t.Run(phase, func(t *testing.T) {
			path := filepath.Join(t.TempDir(), "recovery.json")
			j := testRecovery(t)
			j.Phase = phase
			if err := WriteRecoveryJournalDurable(path, j); err == nil {
				t.Fatal("allowed unbacked phase " + phase)
			}
			if _, err := os.Lstat(path); !os.IsNotExist(err) {
				t.Fatal("created forged journal", err)
			}
		})
	}
}
