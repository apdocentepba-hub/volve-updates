//go:build windows

package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

type dohReceipt struct {
	Version string      `json:"version"`
	Status  string      `json:"status"`
	Created []dohPolicy `json:"created"`
	Skipped []string    `json:"skipped"`
}

func dohReceiptPath() (string, error) {
	p, e := statePath()
	if e != nil {
		return "", e
	}
	return filepath.Join(filepath.Dir(p), "doh-0220.json"), nil
}
func readDoHReceipt() (dohReceipt, error) {
	var r dohReceipt
	p, e := dohReceiptPath()
	if e != nil {
		return r, e
	}
	b, e := os.ReadFile(p)
	if e != nil {
		return r, e
	}
	if len(b) > 16000 {
		return r, errors.New("registro DoH excede límite")
	}
	if e = json.Unmarshal(b, &r); e != nil {
		return r, e
	}
	if r.Version != "0.22.0" || len(r.Created) > 4 || len(r.Skipped) > 4 || (r.Status != "active" && r.Status != "pending" && r.Status != "restoring") {
		return r, errors.New("recibo DoH no reconocido")
	}
	seen := map[string]bool{}
	for _, x := range r.Created {
		if !approvedDoH(x) || seen[x.Key+"/"+x.Name] {
			return r, errors.New("recibo DoH contiene regla desconocida o duplicada")
		}
		seen[x.Key+"/"+x.Name] = true
	}
	return r, nil
}
func writeDoHReceipt(r dohReceipt) error {
	p, e := dohReceiptPath()
	if e != nil {
		return e
	}
	if e = os.MkdirAll(filepath.Dir(p), 0700); e != nil {
		return e
	}
	b, e := json.MarshalIndent(r, "", "  ")
	if e != nil {
		return e
	}
	f, e := os.CreateTemp(filepath.Dir(p), ".doh-")
	if e != nil {
		return e
	}
	defer os.Remove(f.Name())
	if _, e = f.Write(b); e != nil {
		f.Close()
		return e
	}
	if e = f.Sync(); e != nil {
		f.Close()
		return e
	}
	if e = f.Close(); e != nil {
		return e
	}
	return os.Rename(f.Name(), p)
}
func isRegMissing(output string) bool {
	lower := strings.ToLower(output)
	for _, x := range []string{"unable to find", "not found", "no se encuentra", "no existe", "no ha podido encontrar", "no puede encontrar", "no se encontró"} {
		if strings.Contains(lower, x) {
			return true
		}
	}
	return false
}
func readDoHReg(p dohPolicy) (typ, val string, exists bool, err error) {
	raw, e := reg("query", p.Key, "/v", p.Name)
	if e != nil {
		if isRegMissing(raw) {
			return "", "", false, nil
		}
		return "", "", false, fmt.Errorf("consulta %s/%s: %w: %s", p.Key, p.Name, e, strings.TrimSpace(raw))
	}
	return parseRegValue(raw, p.Name)
}
func installOneDoH(p dohPolicy) error {
	if !approvedDoH(p) {
		return errors.New("regla DoH ajena a VOLVE")
	}
	// Windows reg.exe /d uses decimal for DWORD values; hex 0x0 and 0x1 also work.
	raw, e := reg("add", p.Key, "/v", p.Name, "/t", p.Type, "/d", p.Value, "/f")
	if e != nil {
		return fmt.Errorf("no se pudo escribir %s/%s: %s (%w)", p.Key, p.Name, strings.TrimSpace(raw), e)
	}
	return nil
}
func applyDoH() error {
	if !isAdmin() {
		return errors.New("requiere administrador")
	}
	receipt, e := readDoHReceipt()
	if e == nil {
		if receipt.Status != "active" {
			return errors.New("operación DoH interrumpida: ejecutá --uninstall para restaurar")
		}
		for _, p := range receipt.Created {
			typ, val, exists, er := readDoHReg(p)
			if er != nil {
				return er
			}
			if !exists || typ != p.Type || val != p.Value {
				return fmt.Errorf("regla DNS modificada: %s/%s; no sobrescribir", p.Key, p.Name)
			}
		}
		return nil
	}
	if !errors.Is(e, os.ErrNotExist) {
		return fmt.Errorf("no se sobrescribe estado DoH: %w", e)
	}
	receipt = dohReceipt{Version: "0.22.0", Status: "pending"}
	for _, p := range dohSpecs() {
		typ, val, exists, er := readDoHReg(p)
		if er != nil {
			return er
		}
		if exists {
			receipt.Skipped = append(receipt.Skipped, fmt.Sprintf("%s/%s (valor previo %s %s)", p.Key, p.Name, typ, val))
			continue
		}
		receipt.Created = append(receipt.Created, p)
	}
	if e = writeDoHReceipt(receipt); e != nil {
		return e
	}
	for _, p := range receipt.Created {
		// Recheck before changing registry to avoid overwriting changes by another admin.
		_, _, exists, er := readDoHReg(p)
		if er != nil {
			return er
		}
		if exists {
			return errors.New("política añadida por otro administrador durante instalación; restaurar VOLVE")
		}
		if er = installOneDoH(p); er != nil {
			return er
		}
		typ, val, exists, er := readDoHReg(p)
		if er != nil || !exists || typ != p.Type || val != p.Value {
			return fmt.Errorf("no se pudo verificar política %s/%s: %v", p.Key, p.Name, er)
		}
	}
	receipt.Status = "active"
	return writeDoHReceipt(receipt)
}
func restoreDoH() error {
	r, e := readDoHReceipt()
	if errors.Is(e, os.ErrNotExist) {
		return nil
	}
	if e != nil {
		return e
	}
	r.Status = "restoring"
	if e = writeDoHReceipt(r); e != nil {
		return e
	}
	for _, p := range r.Created {
		typ, val, exists, er := readDoHReg(p)
		if er != nil {
			return er
		}
		if !exists {
			continue
		}
		if typ != p.Type || val != p.Value {
			return fmt.Errorf("no borrar política modificada por tercero: %s/%s", p.Key, p.Name)
		}
		raw, er := reg("delete", p.Key, "/v", p.Name, "/f")
		if er != nil {
			return fmt.Errorf("falló restauración %s/%s: %s (%w)", p.Key, p.Name, strings.TrimSpace(raw), er)
		}
	}
	path, e := dohReceiptPath()
	if e != nil {
		return e
	}
	return os.Remove(path)
}
func dohStatusText() string {
	r, e := readDoHReceipt()
	if errors.Is(e, os.ErrNotExist) {
		return "Refuerzo DoH: no registrado.\n"
	}
	if e != nil {
		return "Refuerzo DoH: registro ilegible o modificado, NO asumir protección.\n"
	}
	verified := 0
	for _, p := range r.Created {
		typ, val, exists, e := readDoHReg(p)
		if e == nil && exists && typ == p.Type && val == p.Value {
			verified++
		}
	}
	return fmt.Sprintf("Refuerzo DoH en navegadores: %d/%d reglas propias verificadas; %d políticas preexistentes respetadas; estado %s.\n", verified, len(r.Created), len(r.Skipped), r.Status)
}
