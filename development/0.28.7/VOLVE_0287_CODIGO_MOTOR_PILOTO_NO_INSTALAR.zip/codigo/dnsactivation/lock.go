package dnsactivation

import (
	"errors"
	"os"
	"path/filepath"
)

func lease(store Store) (func(), error) {
	fstore, ok := store.(FileStore)
	if !ok {
		return func() {}, nil
	} // mock stores; production always FileStore
	if _, e := fstore.path(); e != nil {
		return nil, e
	}
	path := filepath.Join(fstore.Directory, "dns-activation.lock")
	f, e := os.OpenFile(path, os.O_CREATE|os.O_RDWR, 0600)
	if e != nil {
		return nil, e
	}
	info, e := f.Stat()
	if e != nil || !info.Mode().IsRegular() {
		f.Close()
		return nil, errors.New("invalid DNS activation lock")
	}
	unlock, e := acquirePlatformLease(f)
	if e != nil {
		f.Close()
		return nil, e
	}
	return func() { unlock(); f.Close() }, nil
}
