// Package dnsactivation implements a deliberately separate, fail-closed
// transaction for activating a local DNS filter. A privileged Windows driver
// must implement each operation; merely installing files NEVER calls Activate.
package dnsactivation

import (
	"context"
	"errors"
	"fmt"
	"net/netip"
	"strconv"
	"strings"
	"time"
)

// Snapshot is a TRUSTED LOCAL record. It must never originate in an online
// update manifest and must be durable before changing a network adapter.
type Snapshot struct {
	Schema         int      `json:"schema"`
	InterfaceIndex int      `json:"interface_index"`
	InterfaceGUID  string   `json:"interface_guid"`
	Alias          string   `json:"alias"`
	RestoreMode    string   `json:"restore_mode"` // automatic or manual
	IPv4           []string `json:"ipv4"`
	IPv6           []string `json:"ipv6"`
}

func (s Snapshot) Validate() error {
	if s.Schema != 1 || s.InterfaceIndex <= 0 || len(s.InterfaceGUID) < 10 || len(s.InterfaceGUID) > 96 || strings.TrimSpace(s.Alias) == "" || len(s.Alias) > 256 {
		return errors.New("incomplete network interface identity")
	}
	if s.RestoreMode != "automatic" && s.RestoreMode != "manual" {
		return errors.New("unknown original DNS assignment mode")
	}
	if len(s.IPv4) > 8 || len(s.IPv6) > 8 || (s.RestoreMode == "manual" && len(s.IPv4)+len(s.IPv6) == 0) {
		return errors.New("invalid original DNS server count")
	}
	// A snapshot describes the DNS resolvers that Windows already uses. IPv6
	// link-local DNS servers (fe80::/10) are legitimate on many LANs, even
	// though they are unsuitable as universal upstream DNS servers. Preserve
	// them unchanged for a future restore; never route traffic to them outside
	// their original interface.
	seen := map[string]bool{}
	for family, servers := range [][]string{s.IPv4, s.IPv6} {
		for i, server := range servers {
			addr, err := netip.ParseAddr(server)
			if err != nil || !addr.IsValid() {
				return fmt.Errorf("DNS original familia %d entrada %d: dirección IP inválida", family, i+1)
			}
			if (family == 0 && !addr.Is4()) || (family == 1 && !addr.Is6()) {
				return fmt.Errorf("DNS original familia %d entrada %d: familia de IP incorrecta", family, i+1)
			}
			if addr.IsLoopback() || addr.IsUnspecified() || addr.IsMulticast() {
				return fmt.Errorf("DNS original familia %d entrada %d: dirección local/reservada no apta", family, i+1)
			}
			if family == 0 && addr.IsLinkLocalUnicast() {
				return fmt.Errorf("DNS original IPv4 entrada %d: enlace local no apto", i+1)
			}
			if addr.Zone() != "" {
				if family != 1 || !addr.IsLinkLocalUnicast() || addr.Zone() != strconv.Itoa(s.InterfaceIndex) {
					return fmt.Errorf("DNS original IPv6 entrada %d: ámbito no coincide con interfaz %d", i+1, s.InterfaceIndex)
				}
			} else if family == 1 && addr.IsLinkLocalUnicast() && s.RestoreMode == "manual" {
				// A static, unscoped link-local address is ambiguous to restore.
				return fmt.Errorf("DNS original IPv6 entrada %d: enlace local manual sin ámbito de interfaz", i+1)
			}
			key := addr.String()
			if seen[key] {
				// Some DHCP-supplied DNS lists returned by Windows contain
				// repeated servers. For automatic mode restoration means
				// restoring DHCP/automatic assignment, not writing this list
				// back manually. Keep the ORIGINAL array, duplicates included,
				// so the read-only backup is faithful to Windows.
				// A manually configured duplicate is still rejected because
				// lossless Set-DnsClientServerAddress restoration is untested.
				if s.RestoreMode == "manual" {
					return fmt.Errorf("DNS original familia %d entrada %d: servidor duplicado en configuración manual; restauración no verificada", family, i+1)
				}
				continue
			}
			seen[key] = true
		}
	}
	return nil
}

// DuplicateServers reports redundancy WITHOUT altering the original array.
// The diagnostic may report how many repeated entries Windows returned.
func (s Snapshot) DuplicateServers() int {
	seen := map[string]struct{}{}
	duplicates := 0
	for _, servers := range [][]string{s.IPv4, s.IPv6} {
		for _, original := range servers {
			addr, err := netip.ParseAddr(original)
			if err != nil {
				continue
			}
			key := addr.String()
			if _, ok := seen[key]; ok {
				duplicates++
			} else {
				seen[key] = struct{}{}
			}
		}
	}
	return duplicates
}

type Journal struct {
	Schema   int      `json:"schema"`
	Phase    string   `json:"phase"` // pending, active or recovered
	Snapshot Snapshot `json:"snapshot"`
}

func (j Journal) Validate() error {
	if j.Schema != 1 || (j.Phase != "pending" && j.Phase != "active" && j.Phase != "recovered") {
		return errors.New("unsupported DNS activation journal")
	}
	return j.Snapshot.Validate()
}

type Store interface {
	Load() (*Journal, error)
	Save(Journal) error // must be durable and protected before returning
	Clear() error
}

// Driver is a privileged implementation bound to the local Windows instance.
// Every verification must inspect OS state, not just a cached return value.
type Driver interface {
	Capture(context.Context) (Snapshot, error)
	Preflight(context.Context, Snapshot) error
	ArmRescue(context.Context) error
	VerifyRescue(context.Context) error
	StartMotor(context.Context, Snapshot) error
	VerifyMotor(context.Context) error
	SetLoopback(context.Context, Snapshot) error
	VerifyWindowsDNS(context.Context, Snapshot) error
	RestoreDNS(context.Context, Snapshot) error
	VerifyRestored(context.Context, Snapshot) error
	StopNewMotor(context.Context) error
}

// Activate never presents success unless the motor and Windows resolver have
// both passed real checks. On ANY ambiguous error it tries rollback using an
// independent context. A failed rollback retains the journal for retry.
func Activate(ctx context.Context, store Store, driver Driver) error {
	if store == nil || driver == nil {
		return errors.New("DNS transaction dependencies missing")
	}
	release, lockErr := lease(store)
	if lockErr != nil {
		return fmt.Errorf("another activation or rescue is running: %w", lockErr)
	}
	defer release()
	old, err := store.Load()
	if err != nil {
		return fmt.Errorf("DNS journal not readable: %w", err)
	}
	if old != nil {
		return errors.New("an existing DNS journal requires recovery or inspection before activation")
	}
	snapshot, err := driver.Capture(ctx)
	if err != nil {
		return err
	}
	if err = snapshot.Validate(); err != nil {
		return err
	}
	if err = driver.Preflight(ctx, snapshot); err != nil {
		return fmt.Errorf("DNS preflight rejected: %w", err)
	}
	journal := Journal{Schema: 1, Phase: "pending", Snapshot: snapshot}
	if err = store.Save(journal); err != nil {
		return fmt.Errorf("cannot persist original DNS configuration: %w", err)
	}
	// From here onward, every failed step MUST attempt a restore. Preflight
	// and journal checks alone did not mutate the machine.
	fail := func(cause error) error {
		recoverCtx, cancel := context.WithTimeout(context.Background(), 75*time.Second)
		defer cancel()
		if recoveryErr := Recover(recoverCtx, store, driver); recoveryErr != nil {
			return errors.Join(fmt.Errorf("DNS activation aborted: %w", cause), fmt.Errorf("CRITICAL: recovery not verified; backup retained: %w", recoveryErr))
		}
		return fmt.Errorf("DNS activation cancelled; original DNS restored: %w", cause)
	}
	if err = driver.ArmRescue(ctx); err != nil {
		return fail(err)
	}
	if err = driver.VerifyRescue(ctx); err != nil {
		return fail(err)
	}
	if err = driver.StartMotor(ctx, snapshot); err != nil {
		return fail(err)
	}
	if err = driver.VerifyMotor(ctx); err != nil {
		return fail(err)
	}
	if err = driver.SetLoopback(ctx, snapshot); err != nil {
		return fail(err)
	}
	if err = driver.VerifyWindowsDNS(ctx, snapshot); err != nil {
		return fail(err)
	}
	if err = driver.VerifyMotor(ctx); err != nil {
		return fail(err)
	}
	if err = driver.VerifyRescue(ctx); err != nil {
		return fail(fmt.Errorf("DNS rescue not armed after change: %w", err))
	}
	// Persist an active record with original DNS settings for future recovery.
	journal.Phase = "active"
	if err = store.Save(journal); err != nil {
		return fail(fmt.Errorf("active DNS journal not durable: %w", err))
	}
	return nil
}

// Recover is idempotent for the known 'pending' state and never clears a
// backup until Windows confirms the original resolver configuration.
func Recover(ctx context.Context, store Store, driver Driver) error {
	if store == nil || driver == nil {
		return errors.New("missing DNS recovery dependencies")
	}
	j, err := store.Load()
	if err != nil {
		return err
	}
	if j == nil {
		return nil
	}
	if err = j.Validate(); err != nil {
		return err
	}
	if j.Phase != "pending" {
		return errors.New("active DNS backup must not be discarded during recovery")
	}
	var failures []error
	if e := driver.RestoreDNS(ctx, j.Snapshot); e != nil {
		failures = append(failures, fmt.Errorf("restore adapter: %w", e))
	}
	if e := driver.VerifyRestored(ctx, j.Snapshot); e != nil {
		failures = append(failures, fmt.Errorf("verify adapter restored: %w", e))
	}
	// Stop only the motor the trusted installer started; NEVER kill an
	// arbitrary process using UDP 53.
	if len(failures) == 0 {
		if e := driver.StopNewMotor(ctx); e != nil {
			failures = append(failures, fmt.Errorf("stop new motor: %w", e))
		}
	}
	if len(failures) > 0 {
		return fmt.Errorf("CRITICAL: original DNS state not confirmed; journal retained: %w", errors.Join(failures...))
	}
	if e := store.Clear(); e != nil {
		return fmt.Errorf("CRITICAL: DNS restored but journal could not be cleared: %w", e)
	}
	return nil
}

// Monitor is called by a separate SYSTEM scheduled task. A pending journal
// means a crash/interruption during setup; it must restore original DNS. An
// active journal is checked conservatively before restoring for persistent
// engine failure. Once restored, the journal remains for diagnosis and no
// active protection is claimed.
func Monitor(ctx context.Context, store Store, driver Driver) error {
	if store == nil || driver == nil {
		return errors.New("DNS rescue dependencies missing")
	}
	release, lockErr := lease(store)
	if lockErr != nil {
		return fmt.Errorf("activation is running; rescue will retry: %w", lockErr)
	}
	defer release()
	j, e := store.Load()
	if e != nil {
		return e
	}
	if j == nil || j.Phase == "recovered" {
		return nil
	}
	if j.Phase == "pending" {
		return Recover(ctx, store, driver)
	}
	// Three checks avoid disabling protection for a single transient probe.
	for i := 0; i < 3; i++ {
		if e = driver.VerifyMotor(ctx); e == nil {
			if e = driver.VerifyWindowsDNS(ctx, j.Snapshot); e == nil {
				return nil
			}
		}
		if i < 2 {
			select {
			case <-ctx.Done():
				return ctx.Err()
			case <-time.After(3 * time.Second):
			}
		}
	}
	cause := e
	// Preserve the record regardless of errors, do not fabricate success.
	if e = driver.RestoreDNS(ctx, j.Snapshot); e != nil {
		return errors.Join(fmt.Errorf("local filter repeatedly unhealthy: %w", cause), fmt.Errorf("CRITICAL: DNS restore failed: %w", e))
	}
	if e = driver.VerifyRestored(ctx, j.Snapshot); e != nil {
		return fmt.Errorf("CRITICAL: DNS restoration unverified; backup preserved: %w", e)
	}
	if e = driver.StopNewMotor(ctx); e != nil {
		return fmt.Errorf("CRITICAL: original DNS restored but motor task stop unverified: %w", e)
	}
	j.Phase = "recovered"
	if e = store.Save(*j); e != nil {
		return fmt.Errorf("CRITICAL: original DNS restored but status was not saved: %w", e)
	}
	return fmt.Errorf("VOLVE DNS DISABLED AND ORIGINAL SETTINGS RESTORED after motor failure: %w", cause)
}
