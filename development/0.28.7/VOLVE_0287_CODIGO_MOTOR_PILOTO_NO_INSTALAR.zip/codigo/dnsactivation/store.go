package dnsactivation

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
)

// FileStore expects a directory whose ACL is already restricted to SYSTEM and
// administrators. It rejects directories and journal symlinks rather than
// trusting a writable location. On Windows the caller must separately verify
// the ACL. Never store backups inside a web-downloaded release directory.
type FileStore struct{ Directory string }

const fileName = "dns-activation.json"

func (s FileStore) path() (string, error) {
	if !filepath.IsAbs(s.Directory) {
		return "", errors.New("DNS journal directory must be absolute")
	}
	info, e := os.Lstat(s.Directory)
	if e != nil {
		return "", e
	}
	if !info.IsDir() || info.Mode()&os.ModeSymlink != 0 {
		return "", errors.New("unsafe DNS journal directory")
	}
	return filepath.Join(s.Directory, fileName), nil
}
func (s FileStore) Load() (*Journal, error) {
	path, e := s.path()
	if e != nil {
		return nil, e
	}
	info, e := os.Lstat(path)
	if errors.Is(e, os.ErrNotExist) {
		return nil, nil
	}
	if e != nil {
		return nil, e
	}
	if !info.Mode().IsRegular() || info.Size() > 32768 {
		return nil, errors.New("unsafe DNS journal file")
	}
	f, e := os.Open(path)
	if e != nil {
		return nil, e
	}
	defer f.Close()
	dec := json.NewDecoder(io.LimitReader(f, 32769))
	dec.DisallowUnknownFields()
	var j Journal
	if e = dec.Decode(&j); e != nil {
		return nil, e
	}
	var remainder any
	if e = dec.Decode(&remainder); e != io.EOF {
		return nil, errors.New("invalid trailing data in DNS journal")
	}
	if e = j.Validate(); e != nil {
		return nil, e
	}
	return &j, nil
}
func (s FileStore) Save(j Journal) error {
	if e := j.Validate(); e != nil {
		return e
	}
	path, e := s.path()
	if e != nil {
		return e
	}
	if info, e := os.Lstat(path); e == nil {
		if !info.Mode().IsRegular() {
			return errors.New("DNS journal was replaced with unsafe file")
		}
		old, ee := s.Load()
		if ee != nil {
			return ee
		}
		if old == nil || !((old.Phase == "pending" && j.Phase == "active") || (old.Phase == "active" && j.Phase == "recovered")) || !reflect.DeepEqual(old.Snapshot, j.Snapshot) {
			return errors.New("refusing to overwrite an unrelated DNS journal")
		}
	} else if !errors.Is(e, os.ErrNotExist) {
		return e
	}
	contents, e := json.MarshalIndent(j, "", "  ")
	if e != nil {
		return e
	}
	if len(contents) > 32768 {
		return errors.New("DNS journal excessive")
	}
	temp, e := os.CreateTemp(s.Directory, ".volve-dns-journal-")
	if e != nil {
		return e
	}
	defer os.Remove(temp.Name())
	if e = temp.Chmod(0600); e != nil {
		temp.Close()
		return e
	}
	if _, e = temp.Write(contents); e == nil {
		e = temp.Sync()
	}
	if c := temp.Close(); e == nil {
		e = c
	}
	if e != nil {
		return e
	}
	if e = os.Rename(temp.Name(), path); e != nil {
		return fmt.Errorf("atomic DNS journal write failed: %w", e)
	}
	// Sync the journal directory on platforms supporting this operation.
	if d, e := os.Open(s.Directory); e == nil {
		_ = d.Sync()
		_ = d.Close()
	}
	return nil
}
func (s FileStore) Clear() error {
	path, e := s.path()
	if e != nil {
		return e
	}
	j, e := s.Load()
	if e != nil {
		return e
	}
	if j == nil {
		return nil
	}
	if j.Phase != "pending" {
		return errors.New("cannot delete active DNS recovery evidence")
	}
	return os.Remove(path)
}
