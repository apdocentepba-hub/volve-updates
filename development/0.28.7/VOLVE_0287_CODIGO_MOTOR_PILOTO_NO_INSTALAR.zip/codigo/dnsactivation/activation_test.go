package dnsactivation

import (
	"context"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func sample() Snapshot {
	return Snapshot{Schema: 1, InterfaceIndex: 12, InterfaceGUID: "{6a102a16-54af-472e-9744-83ae649e3344}", Alias: "Ethernet", RestoreMode: "automatic", IPv4: []string{"192.0.2.53"}, IPv6: []string{"2001:4860:4860::8888"}}
}

type fakeDriver struct {
	fail     string
	calls    []string
	restored bool
	verified bool
}

func (f *fakeDriver) step(n string) error {
	f.calls = append(f.calls, n)
	if f.fail == n {
		return errors.New(n + " failed")
	}
	return nil
}
func (f *fakeDriver) Capture(context.Context) (Snapshot, error)        { return sample(), f.step("capture") }
func (f *fakeDriver) Preflight(context.Context, Snapshot) error        { return f.step("preflight") }
func (f *fakeDriver) ArmRescue(context.Context) error                  { return f.step("arm-rescue") }
func (f *fakeDriver) VerifyRescue(context.Context) error               { return f.step("verify-rescue") }
func (f *fakeDriver) StartMotor(context.Context, Snapshot) error       { return f.step("start") }
func (f *fakeDriver) VerifyMotor(context.Context) error                { return f.step("motor") }
func (f *fakeDriver) SetLoopback(context.Context, Snapshot) error      { return f.step("set") }
func (f *fakeDriver) VerifyWindowsDNS(context.Context, Snapshot) error { return f.step("windows-dns") }
func (f *fakeDriver) RestoreDNS(context.Context, Snapshot) error {
	if err := f.step("restore"); err != nil {
		return err
	}
	f.restored = true
	return nil
}
func (f *fakeDriver) VerifyRestored(context.Context, Snapshot) error {
	if err := f.step("verify-restored"); err != nil {
		return err
	}
	f.verified = f.restored
	return nil
}
func (f *fakeDriver) StopNewMotor(context.Context) error { return f.step("stop") }
func freshStore(t *testing.T) FileStore                  { t.Helper(); return FileStore{Directory: t.TempDir()} }

func TestActivateVerifiedAndRetainsOriginal(t *testing.T) {
	s := freshStore(t)
	f := &fakeDriver{}
	if e := Activate(context.Background(), s, f); e != nil {
		t.Fatal(e)
	}
	j, e := s.Load()
	if e != nil || j == nil || j.Phase != "active" || j.Snapshot.InterfaceIndex != 12 {
		t.Fatalf("journal: %#v %v", j, e)
	}
	if e := Recover(context.Background(), s, f); e == nil {
		t.Fatal("recovery cannot erase active DNS")
	}
}
func TestNoMutationIfPreflightOrJournalFails(t *testing.T) {
	for _, n := range []string{"capture", "preflight"} {
		t.Run(n, func(t *testing.T) {
			s := freshStore(t)
			f := &fakeDriver{fail: n}
			if e := Activate(context.Background(), s, f); e == nil {
				t.Fatal("expected failure")
			}
			if strings.Contains(strings.Join(f.calls, ","), "set") {
				t.Fatal("modified DNS")
			}
			j, _ := s.Load()
			if j != nil {
				t.Fatal("created journal despite failed preflight")
			}
		})
	}
}
func TestActivationFailuresRestoreOriginal(t *testing.T) {
	for _, n := range []string{"start", "motor", "set", "windows-dns"} {
		t.Run(n, func(t *testing.T) {
			s := freshStore(t)
			f := &fakeDriver{fail: n}
			if e := Activate(context.Background(), s, f); e == nil || !strings.Contains(e.Error(), "restored") {
				t.Fatalf("expected verified rollback: %v", e)
			}
			if !f.restored || !f.verified {
				t.Fatal("rollback not verified")
			}
			j, e := s.Load()
			if e != nil || j != nil {
				t.Fatalf("should clear recovered journal: %#v %v", j, e)
			}
		})
	}
}
func TestRecoveryFailureRetainsJournalAndRetry(t *testing.T) {
	s := freshStore(t)
	f := &fakeDriver{fail: "set"}
	r := &fakeDriver{fail: "restore"}
	if e := s.Save(Journal{Schema: 1, Phase: "pending", Snapshot: sample()}); e != nil {
		t.Fatal(e)
	}
	if e := Recover(context.Background(), s, r); e == nil || !strings.Contains(e.Error(), "CRITICAL") {
		t.Fatalf("expected critical: %v", e)
	}
	j, _ := s.Load()
	if j == nil {
		t.Fatal("journal lost")
	}
	if e := Recover(context.Background(), s, f); e != nil {
		t.Fatal(e)
	}
	j, _ = s.Load()
	if j != nil {
		t.Fatal("journal not cleared")
	}
}
func TestPendingJournalBlocksRepeatedActivation(t *testing.T) {
	s := freshStore(t)
	if e := s.Save(Journal{Schema: 1, Phase: "pending", Snapshot: sample()}); e != nil {
		t.Fatal(e)
	}
	f := &fakeDriver{}
	if e := Activate(context.Background(), s, f); e == nil {
		t.Fatal("did not block pending activation")
	}
	if len(f.calls) > 0 {
		t.Fatal("should not call driver")
	}
}
func TestStoreRejectsSymlinkAndCorruption(t *testing.T) {
	s := freshStore(t)
	j := Journal{Schema: 1, Phase: "pending", Snapshot: sample()}
	if e := s.Save(j); e != nil {
		t.Fatal(e)
	}
	p := filepath.Join(s.Directory, fileName)
	if e := os.WriteFile(p, []byte(`{"schema":1,"phase":"pending","snapshot":{}}`), 0600); e != nil {
		t.Fatal(e)
	}
	if _, e := s.Load(); e == nil {
		t.Fatal("must reject corrupt journal")
	}
	if e := os.Remove(p); e != nil {
		t.Fatal(e)
	}
	out := filepath.Join(t.TempDir(), "outside")
	_ = os.WriteFile(out, []byte("critical"), 0600)
	if e := os.Symlink(out, p); e != nil {
		t.Skipf("no symlink permission: %v", e)
	}
	if e := s.Save(j); e == nil {
		t.Fatal("must reject symlink")
	}
	b, _ := os.ReadFile(out)
	if string(b) != "critical" {
		t.Fatal("modified target")
	}
}
func TestValidateOriginalBackup(t *testing.T) {
	base := sample()
	cases := []Snapshot{{}, {Schema: 1, InterfaceIndex: 0, InterfaceGUID: base.InterfaceGUID, Alias: "e", RestoreMode: "automatic"}, {Schema: 1, InterfaceIndex: 1, InterfaceGUID: base.InterfaceGUID, Alias: "e", RestoreMode: "manual"}}
	for _, s := range cases {
		if s.Validate() == nil {
			t.Fatalf("accepted %+v", s)
		}
	}
	base.IPv4 = []string{"127.0.0.1"}
	if base.Validate() == nil {
		t.Fatal("accepted loopback as original DNS")
	}
}

func TestRecoveryMustBeArmedBeforeNetworkMutation(t *testing.T) {
	for _, n := range []string{"arm-rescue", "verify-rescue"} {
		t.Run(n, func(t *testing.T) {
			s := freshStore(t)
			f := &fakeDriver{fail: n}
			if e := Activate(context.Background(), s, f); e == nil {
				t.Fatal("expected activation failure")
			}
			for _, step := range f.calls {
				if step == "set" {
					t.Fatal("DNS was modified without rescue")
				}
			}
		})
	}
}
func TestMonitorDisabledOnRepeatedEngineFailure(t *testing.T) {
	s := freshStore(t)
	f := &fakeDriver{fail: "motor"}
	if e := s.Save(Journal{Schema: 1, Phase: "pending", Snapshot: sample()}); e != nil {
		t.Fatal(e)
	}
	if e := s.Save(Journal{Schema: 1, Phase: "active", Snapshot: sample()}); e != nil {
		t.Fatal(e)
	}
	if e := Monitor(context.Background(), s, f); e == nil || !strings.Contains(e.Error(), "DISABLED") {
		t.Fatalf("expected explicit disabled state: %v", e)
	}
	j, e := s.Load()
	if e != nil || j.Phase != "recovered" {
		t.Fatalf("expected kept recovered backup: %#v %v", j, e)
	}
}
func TestMonitorActiveHealthyNoChange(t *testing.T) {
	s := freshStore(t)
	f := &fakeDriver{}
	_ = s.Save(Journal{Schema: 1, Phase: "pending", Snapshot: sample()})
	_ = s.Save(Journal{Schema: 1, Phase: "active", Snapshot: sample()})
	if e := Monitor(context.Background(), s, f); e != nil {
		t.Fatal(e)
	}
	if f.restored {
		t.Fatal("monitor should not restore a healthy motor")
	}
}

// Windows can legitimately report the home router as an IPv6 link-local DNS
// server. For DHCP/automatic mode, the backup must remain readable and keep
// the exact address without substituting it for a public upstream.
func TestOriginalLinkLocalIPv6Snapshot(t *testing.T) {
	for _, tc := range []struct {
		label, ipv6, mode string
		wantOK            bool
	}{
		{"automatic-unscoped", "fe80::1", "automatic", true},
		{"automatic-scoped", "fe80::abcd%12", "automatic", true},
		{"manual-scoped", "fe80::abcd%12", "manual", true},
		{"mismatched-zone", "fe80::abcd%13", "automatic", false},
		{"manual-unscoped", "fe80::abcd", "manual", false},
		{"loopback", "::1", "automatic", false},
		{"unspecified", "::", "automatic", false},
		{"multicast", "ff02::1", "automatic", false},
		{"non-linklocal-zone", "2001:db8::1%12", "automatic", false},
		{"invalid", "fe80::xyz", "automatic", false},
		{"site-local-legacy", "fec0:0:0:ffff::1", "automatic", true},
	} {
		t.Run(tc.label, func(t *testing.T) {
			s := sample()
			s.IPv6 = []string{tc.ipv6}
			s.RestoreMode = tc.mode
			e := s.Validate()
			if (e == nil) != tc.wantOK {
				t.Fatalf("Validate()=%v wantOK=%v", e, tc.wantOK)
			}
		})
	}
	s := sample()
	s.IPv6 = []string{"fe80::1", "FE80:0:0::1"}
	if err := s.Validate(); err != nil {
		t.Fatalf("automatic DHCP DNS list with duplicate should remain restorable: %v", err)
	}
	if got := s.DuplicateServers(); got != 1 {
		t.Fatalf("expected one repeated address, got %d", got)
	}
	s.RestoreMode = "manual"
	if s.Validate() == nil {
		t.Fatal("manual duplicate DNS list must be rejected until restoration is validated")
	}
	s = sample()
	s.IPv4 = []string{"169.254.1.1"}
	if s.Validate() == nil {
		t.Fatal("IPv4 link-local unexpectedly accepted")
	}
}

func TestAutomaticDuplicateDNSDoesNotAlterSnapshot(t *testing.T) {
	original := sample()
	original.IPv4 = []string{"192.0.2.53", "192.0.2.53"}
	original.IPv6 = []string{"fe80::1", "FE80:0:0::1", "2001:4860:4860::8888"}
	if err := original.Validate(); err != nil {
		t.Fatal(err)
	}
	if original.DuplicateServers() != 2 {
		t.Fatalf("duplicates %d want 2", original.DuplicateServers())
	}
	store := freshStore(t)
	if err := store.Save(Journal{Schema: 1, Phase: "pending", Snapshot: original}); err != nil {
		t.Fatal(err)
	}
	restored, err := store.Load()
	if err != nil {
		t.Fatal(err)
	}
	if restored == nil || len(restored.Snapshot.IPv6) != 3 || restored.Snapshot.IPv6[1] != "FE80:0:0::1" || len(restored.Snapshot.IPv4) != 2 {
		t.Fatalf("Backup was normalized or lost duplicate original entries: %#v", restored)
	}
}
