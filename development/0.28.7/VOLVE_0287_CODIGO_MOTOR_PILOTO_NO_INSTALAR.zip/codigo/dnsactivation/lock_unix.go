//go:build !windows

package dnsactivation

import (
	"os"
	"syscall"
)

func acquirePlatformLease(f *os.File) (func(), error) {
	if e := syscall.Flock(int(f.Fd()), syscall.LOCK_EX|syscall.LOCK_NB); e != nil {
		return nil, e
	}
	return func() { _ = syscall.Flock(int(f.Fd()), syscall.LOCK_UN) }, nil
}
