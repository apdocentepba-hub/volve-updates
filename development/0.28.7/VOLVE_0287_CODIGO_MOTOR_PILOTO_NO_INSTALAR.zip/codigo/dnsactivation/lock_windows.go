//go:build windows

package dnsactivation

import (
	"os"
	"runtime"
	"syscall"
	"unsafe"
)

var (
	leaseKernel = syscall.NewLazyDLL("kernel32.dll")
	leaseLock   = leaseKernel.NewProc("LockFileEx")
	leaseUnlock = leaseKernel.NewProc("UnlockFileEx")
)

func acquirePlatformLease(f *os.File) (func(), error) {
	o := new(syscall.Overlapped)
	const exclusiveAndImmediate = 0x00000002 | 0x00000001
	ok, _, e := leaseLock.Call(f.Fd(), exclusiveAndImmediate, 0, 1, 0, uintptr(unsafe.Pointer(o)))
	runtime.KeepAlive(o)
	if ok == 0 {
		return nil, e
	}
	return func() { leaseUnlock.Call(f.Fd(), 0, 1, 0, uintptr(unsafe.Pointer(o))); runtime.KeepAlive(o) }, nil
}
