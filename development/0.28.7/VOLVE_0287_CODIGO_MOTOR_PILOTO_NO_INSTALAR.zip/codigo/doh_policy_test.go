package main

import "testing"

func TestDoHPolicyDefinitions(t *testing.T) {
	p := dohSpecs()
	if len(p) != 4 {
		t.Fatalf("expected 4, got %d", len(p))
	}
	for _, e := range p {
		if !approvedDoH(e) {
			t.Fatal("invalid policy")
		}
	}
	if approvedDoH(dohPolicy{Key: `HKLM\foo`, Name: "Locked", Type: "REG_DWORD", Value: "0x1"}) {
		t.Fatal("accepted foreign policy")
	}
}
func TestParseRegistryDoH(t *testing.T) {
	text := `HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Mozilla\Firefox\DNSOverHTTPS
    Enabled    REG_DWORD    0x00000000
    Locked     REG_DWORD    0x1
`
	typ, val, present, err := parseRegValue(text, "Enabled")
	if err != nil || !present || typ != "REG_DWORD" || val != "0x0" {
		t.Fatalf("%q %q %v %v", typ, val, present, err)
	}
	_, _, present, err = parseRegValue(text, "Extra")
	if err != nil || present {
		t.Fatal("unexpected present")
	}
}
