//go:build windows

package main

import (
	"fmt"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
)

// This is a local, optional help page, not an interception of HTTPS traffic.
// HTTPS sites cannot be safely redirected to a local message by changing DNS.
const supportHTML = `<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src 'none'; base-uri 'none'; form-action 'none'"><title>VOLVÉ - Un paso a la vez</title><style>
:root{color-scheme:light}*{box-sizing:border-box}body{margin:0;background:#f1f6f6;color:#143040;font-family:system-ui,-apple-system,'Segoe UI',sans-serif;line-height:1.55}.bar{background:#123b43;color:white;padding:20px 5vw;font-weight:800;letter-spacing:.09em}.container{max-width:930px;margin:5vh auto;padding:0 22px}.hero{background:white;border:1px solid #dce8e8;border-radius:24px;padding:clamp(26px,5vw,55px);box-shadow:0 18px 40px #173d4720}.eyebrow{color:#087f79;font-weight:700;text-transform:uppercase;letter-spacing:.12em;font-size:12px}h1{font-size:clamp(35px,5vw,53px);line-height:1.09;letter-spacing:-.04em;margin:13px 0 20px}p{font-size:18px;color:#526b73}.quote{border-left:5px solid #2a9d8f;padding-left:18px;font-size:21px;color:#173c43}.pill{display:inline-block;border-radius:999px;background:#dcf3ed;color:#126a5e;padding:9px 16px;font-weight:700}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:15px;margin:26px 0}.cell{background:#f2f8f6;border-radius:14px;padding:19px}.cell h2{font-size:18px;margin:0 0 8px}.cell p{font-size:15px;margin:0}.help{background:#163f49;color:white;padding:25px;border-radius:20px;margin-top:23px}.help p{color:#d9ece9;font-size:16px}.help strong{font-size:26px}.help a{color:#bcf1db}.foot{text-align:center;color:#658084;font-size:13px;padding:30px 0}a{overflow-wrap:anywhere}
</style></head><body><div class="bar">VOLVÉ · UN PASO A LA VEZ</div><main class="container"><article class="hero"><div class="eyebrow">Un recordatorio de cuidado</div><h1>Elegiste darte una oportunidad.</h1><p class="quote">No tenés que resolverlo todo hoy. Este momento también puede pasar sin apostar.</p><span class="pill">Tu decisión de cuidarte importa.</span><div class="grid"><section class="cell"><h2>01 · Cambiá de actividad</h2><p>Dejá el dispositivo unos minutos y elegí algo simple: caminar, tomar agua o conversar.</p></section><section class="cell"><h2>02 · No lo atravieses a solas</h2><p>Si te ayuda, escribile a alguien de confianza y contale que estás teniendo ganas de apostar.</p></section><section class="cell"><h2>03 · Cuidá tu dinero</h2><p>No tomes decisiones financieras impulsivas ni intentes recuperar pérdidas mediante nuevas apuestas.</p></section></div><div class="help"><div class="eyebrow" style="color:#a6f0d0">Ayuda gratuita en Argentina</div><p><strong>141</strong> · Orientación y escucha nacional sobre consumos problemáticos, incluidos los juegos de apuestas (24 h).</p><p><strong>0800-444-4000</strong> · Programa de Prevención y Asistencia al Juego Compulsivo, Provincia de Buenos Aires.</p><p>Recursos oficiales: <a href="https://www.argentina.gob.ar/noticias/la-linea-141-de-la-sedronar-recibio-mas-de-23-mil-llamados-en-lo-que-va-del-2026">Línea 141</a> · <a href="https://loteria.gba.gob.ar/juego-compulsivo">Asistencia en PBA</a></p></div></article><p class="foot">VOLVÉ no reemplaza el acompañamiento profesional. Este mensaje no registra tu navegación ni solicita datos personales.</p></main></body></html>`

func preferredBrowsers() []string {
	// Choose an actual browser instead of the machine's file:// handler.
	// On some PCs .html is associated with VS Code or another editor.
	roots := []string{os.Getenv("ProgramFiles(x86)"), os.Getenv("ProgramFiles"), os.Getenv("LOCALAPPDATA")}
	relatives := []string{
		filepath.Join("Microsoft", "Edge", "Application", "msedge.exe"),
		filepath.Join("Google", "Chrome", "Application", "chrome.exe"),
		filepath.Join("Mozilla Firefox", "firefox.exe"),
	}
	candidates := []string{}
	seen := make(map[string]bool)
	for _, name := range relatives {
		for _, root := range roots {
			if root == "" || !filepath.IsAbs(root) {
				continue
			}
			path := filepath.Join(root, name)
			if _, err := os.Stat(path); err == nil && !seen[strings.ToLower(path)] {
				seen[strings.ToLower(path)] = true
				candidates = append(candidates, path)
			}
		}
	}
	return candidates
}

func openSupportPage() error {
	cache, e := os.UserCacheDir()
	if e != nil {
		return e
	}
	dir := filepath.Join(cache, "VOLVE", "ayuda")
	if e = os.MkdirAll(dir, 0700); e != nil {
		return e
	}
	file := filepath.Join(dir, "un-paso-a-la-vez.html")
	if e = os.WriteFile(file, []byte(supportHTML), 0600); e != nil {
		return e
	}
	u := url.URL{Scheme: "file", Path: "/" + filepath.ToSlash(file)}
	for _, exe := range preferredBrowsers() {
		args := []string{"--new-window", u.String()}
		if strings.Contains(strings.ToLower(filepath.Base(exe)), "firefox") {
			args = []string{"-new-window", u.String()}
		}
		cmd := exec.Command(exe, args...)
		cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
		if e = cmd.Start(); e == nil {
			return nil
		}
	}
	return fmt.Errorf("no se encontró Chrome, Edge o Firefox para mostrar la ayuda. Abrí el archivo %s desde un navegador (no desde el editor)", file)
}
