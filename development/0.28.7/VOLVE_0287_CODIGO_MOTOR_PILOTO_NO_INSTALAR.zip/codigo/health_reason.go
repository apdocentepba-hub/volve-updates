package main

import (
	"errors"
	"os"
	"strings"
)

// Preserve ambiguous tasks and disclose only a bounded, categorical reason.
func explainTaskReason(err error) string {
	if err == nil {
		return "sin detalle"
	}
	if errors.Is(err, os.ErrPermission) {
		return "acceso denegado"
	}
	s := strings.ToLower(err.Error())
	switch {
	case strings.Contains(s, "argumentos distintos"):
		return "argumentos de la tarea distintos"
	case strings.Contains(s, "otro ejecutable"):
		return "ruta del ejecutable distinta"
	case strings.Contains(s, "no pertenece a system"):
		return "principal distinto de SYSTEM"
	case strings.Contains(s, "acciones ajenas"), strings.Contains(s, "número de acciones"):
		return "acciones adicionales o inesperadas"
	case strings.Contains(s, "xml"):
		return "XML de la tarea no legible"
	case strings.Contains(s, "acceso denegado"), strings.Contains(s, "access is denied"):
		return "acceso denegado al consultar la tarea"
	case strings.Contains(s, "no puedo comprobar"), strings.Contains(s, "no pude leer"):
		return "consulta al Programador de tareas fallida"
	default:
		return "identidad o configuración no coincidente"
	}
}
