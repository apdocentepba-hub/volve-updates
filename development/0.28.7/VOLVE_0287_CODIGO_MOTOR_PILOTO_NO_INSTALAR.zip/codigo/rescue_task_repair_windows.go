//go:build windows

package main

import (
	"crypto/sha256"
	"encoding/xml"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// repairRescueTask changes ONLY the action arguments of a positively-owned
// SYSTEM watchdog task created by the specific legacy escaping bug.
// It does not start/stop the DNS engine, change DNS or write to the journal.
func repairRescueTask() (string, error) {
	if !isAdmin() {
		return "", errors.New("Se necesita administrador")
	}
	root, e := installRoot()
	if e != nil {
		return "", e
	}
	watchdog := filepath.Join(root, "VOLVE_DNS_Watchdog_0270.ps1")
	rescue := filepath.Join(root, "VOLVE_DNS_Rescue_0270.ps1")
	for _, f := range []struct{ path, expected string }{{watchdog, watchdogPS}, {rescue, rescuePS}} {
		b, er := os.ReadFile(f.path)
		if er != nil {
			return "", fmt.Errorf("No se puede verificar el script protegido %s: %w", filepath.Base(f.path), er)
		}
		if sha256.Sum256(b) != sha256.Sum256([]byte(f.expected)) {
			return "", fmt.Errorf("Script %s distinto del original; no modificar tarea", filepath.Base(f.path))
		}
	}
	powershell := filepath.Join(os.Getenv("WINDIR"), "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
	if os.Getenv("WINDIR") == "" || !filepath.IsAbs(powershell) {
		return "", errors.New("No se identificó WindowsPowerShell")
	}
	wanted := expectedRescueArgs(watchdog)
	legacy := legacyRescueArgs(watchdog)
	raw, exists, e := taskQuery(dnsRescueTask)
	if e != nil {
		return "", e
	}
	if !exists {
		return "", errors.New("No existe la tarea de rescate. No se crea una nueva automáticamente")
	}
	if verifySystemTaskXML(raw, powershell, wanted) == nil {
		return "La tarea de rescate ya coincide exactamente. No se cambió nada.", nil
	}
	// All checks must pass, including executable, SYSTEM principal and exactly
	// one action. A task with unknown args is preserved untouched.
	if e = verifySystemTaskXML(raw, powershell, legacy); e != nil {
		return "", fmt.Errorf("No se puede atribuir la tarea al formato heredado de VOLVÉ: %w", e)
	}
	original, er := decodeTaskXML(raw)
	if er != nil {
		return "", er
	}
	if i := strings.Index(original, "?>"); i >= 0 && strings.HasPrefix(strings.TrimSpace(original), "<?xml") {
		original = strings.TrimSpace(original[i+2:])
	}
	var doc taskDocument
	if e = xml.Unmarshal([]byte(original), &doc); e != nil {
		return "", e
	}
	if len(doc.Actions.Exec) != 1 || !repairableRescueArgs(doc.Actions.Exec[0].Arguments, watchdog) {
		return "", errors.New("Los parámetros no coinciden con la única variante reparable")
	}
	// Backup the task to an admin/SYSTEM-only file before changing its action.
	backup := filepath.Join(root, "VOLVE_DNS_rescue_task_before_0275.xml")
	if _, er = os.Stat(backup); er == nil {
		return "", errors.New("Ya existe un respaldo de reparación; evitar sobrescribirlo. Diagnóstico manual requerido")
	}
	if er != nil && !errors.Is(er, os.ErrNotExist) {
		return "", er
	}
	if e = fileAtomic(backup, raw); e != nil {
		return "", e
	}
	if e = protectDNSFile(backup); e != nil {
		return "", fmt.Errorf("Respaldo no protegido; no se reparó: %w", e)
	}
	setAction := func(args string) error {
		ps := "$ErrorActionPreference='Stop';" +
			"$a=New-ScheduledTaskAction -Execute " + psQuote(powershell) + " -Argument " + psQuote(args) + ";" +
			"Set-ScheduledTask -TaskName " + psQuote(dnsRescueTask) + " -Action $a -ErrorAction Stop | Out-Null"
		out, er := runPS(ps)
		if er != nil {
			return fmt.Errorf("No se pudo configurar tarea: %s: %w", out, er)
		}
		return nil
	}
	if e = setAction(wanted); e != nil {
		return "", e
	}
	if ok, er := confirmOwnTask(dnsRescueTask, powershell, wanted); er == nil && ok {
		return "Tarea de rescate reparada y verificada; programación y cuenta SYSTEM conservadas. DNS sin cambios. No se ha probado una caída real del motor.", nil
	}
	// Failure to verify: attempt to restore the legacy action and report both outcomes.
	rollErr := setAction(legacy)
	if rollErr != nil {
		return "", fmt.Errorf("REPARACIÓN NO CONFIRMADA y reversión de tarea fallida: %w. Conservar BAT de emergencia", rollErr)
	}
	if ok, er := confirmOwnTask(dnsRescueTask, powershell, legacy); er != nil || !ok {
		return "", errors.New("Reparación no confirmada; se intentó restaurar acción anterior pero tampoco pudo verificarse")
	}
	return "", errors.New("Reparación no confirmada: se restauró la acción anterior y se mantuvo el DNS")
}
