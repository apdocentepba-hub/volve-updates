@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul 2>&1
title VOLVE - Rescate de DNS de Windows
color 1F

echo ================================================================
echo   VOLVE - RESTAURAR DNS AUTOMATICO (RESCATE DE EMERGENCIA)
echo ================================================================
echo.
echo Este BAT restaura DNS automatico en adaptadores fisicos ACTIVOS.
echo No elimina VOLVE, no cambia IP, hosts, firewall ni politicas.
echo.

set "VOLVE_BATCH_PATH=%~f0"
fltmc >nul 2>&1
if errorlevel 1 (
    echo Solicitando permisos de administrador de Windows...
    powershell.exe -NoLogo -NoProfile -NonInteractive -Command "Start-Process -FilePath $env:VOLVE_BATCH_PATH -Verb RunAs"
    if errorlevel 1 (
        echo ERROR: no se pudo solicitar elevacion.
        pause
    )
    exit /b
)

set "VOLVE_PS1_PATH=%TEMP%\VOLVE_RESCATE_%RANDOM%_%RANDOM%.ps1"
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$lines=[IO.File]::ReadAllLines($env:VOLVE_BATCH_PATH); $marker='#===VOLVE_DNS_RECOVERY_SCRIPT==='; $i=[Array]::IndexOf($lines,$marker); if($i -lt 0){throw 'Falta seccion de recuperacion'}; $body=($lines[($i+1)..($lines.Length-1)] -join [Environment]::NewLine); [IO.File]::WriteAllText($env:VOLVE_PS1_PATH,$body,([Text.UTF8Encoding]::new($false)))"
if errorlevel 1 (
    echo ERROR: no se pudo cargar el modulo de recuperacion.
    pause
    exit /b 2
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%VOLVE_PS1_PATH%"
set "VOLVE_RESULT=%ERRORLEVEL%"
del /f /q "%VOLVE_PS1_PATH%" >nul 2>&1
echo.
if "%VOLVE_RESULT%"=="0" (
    echo Proceso finalizado. Revisa los mensajes anteriores.
) else (
    echo AVISO: la recuperacion no pudo completarse totalmente.
    echo Consulta los errores anteriores antes de modificar nada mas.
)
echo.
pause
exit /b %VOLVE_RESULT%

#===VOLVE_DNS_RECOVERY_SCRIPT===
$ErrorActionPreference = 'Stop'

function Read-DnsInfo([int]$idx) {
    $v4 = @( (Get-DnsClientServerAddress -InterfaceIndex $idx -AddressFamily IPv4 -ErrorAction Stop).ServerAddresses | Where-Object { $_ } )
    $v6 = @( (Get-DnsClientServerAddress -InterfaceIndex $idx -AddressFamily IPv6 -ErrorAction Stop).ServerAddresses | Where-Object { $_ } )
    return [pscustomobject]@{ IPv4 = $v4; IPv6 = $v6 }
}

Write-Host ''
Write-Host 'VOLVE - RESTAURAR DNS AUTOMATICO' -ForegroundColor Cyan
Write-Host 'Esto SOLO restablece los servidores DNS obtenidos automaticamente por Windows.'
Write-Host 'No restaura servidores DNS manuales y no elimina bloqueos hosts ni politicas de navegador.' -ForegroundColor Yellow
Write-Host ''

try {
    $adapters = @(Get-NetAdapter -Physical -ErrorAction Stop | Where-Object { $_.Status -eq 'Up' } | Sort-Object -Property ifIndex)
    if ($adapters.Count -eq 0) {
        throw 'No se encontro un adaptador fisico activo. No se realizo ningun cambio.'
    }
    Write-Host 'Adaptadores fisicos activos detectados:'
    foreach ($adapter in $adapters) {
        Write-Host ('  - {0} (indice {1})' -f $adapter.Name, $adapter.ifIndex)
    }
    Write-Host ''
    Write-Host 'ATENCION: si configuraste DNS manualmente por otro motivo, esta accion lo reemplaza por automatico.' -ForegroundColor Yellow
    $answer = Read-Host 'Escribi RESTAURAR para guardar respaldo y restablecer DNS (o Enter para cancelar)'
    if ($answer -cne 'RESTAURAR') {
        Write-Host 'Operacion cancelada. No se modifico nada.' -ForegroundColor Yellow
        exit 0
    }

    $backup = @()
    foreach ($adapter in $adapters) {
        $info = Read-DnsInfo -idx ([int]$adapter.ifIndex)
        $backup += [pscustomobject]@{
            Name = [string]$adapter.Name
            InterfaceIndex = [int]$adapter.ifIndex
            InterfaceGuid = [string]$adapter.InterfaceGuid
            OriginalIPv4 = @($info.IPv4)
            OriginalIPv6 = @($info.IPv6)
        }
    }
    $folder = Join-Path $env:ProgramData 'VOLVE-Rescate-DNS'
    New-Item -ItemType Directory -Path $folder -Force -ErrorAction Stop | Out-Null
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $file = Join-Path $folder ("DNS_antes_del_rescate_{0}.json" -f $stamp)
    $snapshot = [pscustomobject]@{
        Fecha = (Get-Date).ToString('o')
        Explicacion = 'Copia informativa de direcciones DNS ANTES de restablecer a automatico. No es un restaurador automatico de configuraciones manuales.'
        Adaptadores = @($backup)
    }
    $snapshot | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $file -Encoding UTF8 -ErrorAction Stop
    if (-not (Test-Path -LiteralPath $file)) { throw 'No se pudo verificar el archivo de respaldo.' }
    $saved = Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
    if (@($saved.Adaptadores).Count -ne $adapters.Count) { throw 'Respaldo incompleto; no se modifico la red.' }
    Write-Host ''
    Write-Host ('Respaldo guardado: {0}' -f $file) -ForegroundColor Green

    $errors = 0
    foreach ($adapter in $adapters) {
        $idx = [int]$adapter.ifIndex
        try {
            Write-Host ('Restableciendo DNS automatico: {0} ...' -f $adapter.Name)
            Set-DnsClientServerAddress -InterfaceIndex $idx -ResetServerAddresses -ErrorAction Stop
            $after = Read-DnsInfo -idx $idx
            Write-Host ('  OK. IPv4 actuales: {0}' -f ($after.IPv4 -join ', ')) -ForegroundColor Green
            Write-Host ('  IPv6 actuales: {0}' -f ($after.IPv6 -join ', '))
        } catch {
            $errors++
            Write-Host ('  ERROR en {0}: {1}' -f $adapter.Name, $_.Exception.Message) -ForegroundColor Red
        }
    }

    try {
        Clear-DnsClientCache -ErrorAction Stop
        Write-Host 'Cache DNS de Windows vaciada.' -ForegroundColor Green
    } catch {
        Write-Host ('No se pudo vaciar la cache DNS: {0}' -f $_.Exception.Message) -ForegroundColor Yellow
    }

    Write-Host ''
    if ($errors -eq 0) {
        Write-Host 'FINALIZADO: Windows volvio a solicitar DNS automaticos en los adaptadores seleccionados.' -ForegroundColor Green
        Write-Host 'Si una pagina sigue bloqueada, VOLVE puede mantener reglas hosts o politicas del navegador.' -ForegroundColor Yellow
        Write-Host 'Si no tenes Internet, espera a que DHCP/tu router entregue servidores y volve a probar.'
        exit 0
    }
    Write-Host ('RECUPERACION PARCIAL: {0} adaptador(es) con errores.' -f $errors) -ForegroundColor Red
    Write-Host ('Consulta el respaldo: {0}' -f $file)
    exit 2
} catch {
    Write-Host ('ERROR: {0}' -f $_.Exception.Message) -ForegroundColor Red
    Write-Host 'No se fuerza la eliminacion de tareas, servicios, politicas o archivos de VOLVE.'
    exit 3
}
