//go:build windows

package main

// VOLVE experimental DNS integration. The administrator must explicitly opt
// into activation. DNS failback is independent of this program (SYSTEM task).
import (
	"context"
	"crypto/sha256"
	_ "embed"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"time"
	"volve-browser-protection/blocker"
	"volve-browser-protection/dnsproxy"
	"volve-browser-protection/dnsrollout"
)

//go:embed assets/VOLVE_RESTAURAR_DNS_EMERGENCIA.bat
var embeddedEmergencyBAT []byte

const dnsServiceTask = "VOLVE-DNS-SERVER-0270"
const dnsRescueTask = "VOLVE-DNS-RESCUE-0270"
const dnsServiceFile = "VOLVE_DNS_Server_0270.exe"
const rescueFile = "VOLVE_DNS_Rescue_0270.ps1"
const rescueJournal = "VOLVE_DNS_rescue_0270.json"

type dnsProductionBackup struct {
	Schema         int    `json:"schema"`
	Phase          string `json:"phase"`
	Mode           string `json:"mode"`
	InterfaceIndex int    `json:"interface_index"`
	InterfaceGUID  string `json:"interface_guid"`
	ActivatedAt    string `json:"activated_at"`
}

func installRoot() (string, error) {
	p, e := statePath()
	if e != nil {
		return "", e
	}
	return filepath.Dir(p), nil
}
func backupPath() (string, error)  { p, e := installRoot(); return filepath.Join(p, rescueJournal), e }
func scriptPath() (string, error)  { p, e := installRoot(); return filepath.Join(p, rescueFile), e }
func servicePath() (string, error) { p, e := installRoot(); return filepath.Join(p, dnsServiceFile), e }
func runPS(script string) (string, error) {
	// -EncodedCommand uses UTF-16LE; stdout/stderr may be localized and is for
	// diagnostics only (never parsed as JSON).
	raw := syscall.StringToUTF16(script)
	b := make([]byte, 0, len(raw)*2)
	for _, c := range raw[:len(raw)-1] {
		b = append(b, byte(c), byte(c>>8))
	}
	encoded := base64Of(b)
	ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
	defer cancel()
	c := exec.CommandContext(ctx, "powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-EncodedCommand", encoded)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: createNoWindow}
	output, e := c.CombinedOutput()
	if ctx.Err() != nil {
		return "", ctx.Err()
	}
	if len(output) > 16000 {
		output = output[:16000]
	}
	return strings.TrimSpace(string(output)), e
}

// Minimal encoder avoids console arguments with scripts containing quotes.
func base64Of(data []byte) string {
	const table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
	out := make([]byte, 0, ((len(data)+2)/3)*4)
	for i := 0; i < len(data); i += 3 {
		v := uint(data[i]) << 16
		end := i + 3
		if end > len(data) {
			end = len(data)
		}
		if i+1 < end {
			v |= uint(data[i+1]) << 8
		}
		if i+2 < end {
			v |= uint(data[i+2])
		}
		out = append(out, table[(v>>18)&63], table[(v>>12)&63])
		if i+1 < end {
			out = append(out, table[(v>>6)&63])
		} else {
			out = append(out, '=')
		}
		if i+2 < end {
			out = append(out, table[v&63])
		} else {
			out = append(out, '=')
		}
	}
	return string(out)
}

// Restores only DNS settings. Automatic is REQUIRED by this beta. The script
// never executes any commands originating from the journal.
const rescuePS = `$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$journal=Join-Path $root 'VOLVE_DNS_rescue_0270.json'
if(!(Test-Path -LiteralPath $journal)){exit 0}
try {
 $j=Get-Content -LiteralPath $journal -Raw -Encoding UTF8|ConvertFrom-Json -ErrorAction Stop
 if($j.schema -ne 1 -or $j.mode -ne 'automatic' -or $j.interface_index -le 0 -or [string]::IsNullOrWhiteSpace([string]$j.interface_guid)){throw 'Journal invalid; no adapter changes'}
 $a=@(Get-NetAdapter -ErrorAction Stop | Where-Object { ([string]$_.InterfaceGuid).Trim('{}') -eq ([string]$j.interface_guid).Trim('{}') })
 if($a.Count -ne 1){throw 'Original adapter GUID identity mismatch; no changes'}
 $idx=[int]$a[0].ifIndex
 if($idx -le 0){throw 'Current adapter index invalid'}
 # InterfaceIndex may change after reboot. GUID identifies the same physical adapter.
 # First and every subsequent failure: restore DHCP/automatic DNS for IPv4/6.
 Set-DnsClientServerAddress -InterfaceIndex $idx -ResetServerAddresses -ErrorAction Stop
 Start-Sleep -Seconds 2
 $g=([string]$a[0].InterfaceGuid).Trim('{}')
 $r4=Get-ItemProperty -LiteralPath ('HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\{'+$g+'}') -ErrorAction Stop
 $r6=Get-ItemProperty -LiteralPath ('HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters\Interfaces\{'+$g+'}') -ErrorAction SilentlyContinue
 if(-not [string]::IsNullOrWhiteSpace([string]$r4.NameServer)){throw 'IPv4 still manual; record retained'}
 if($null -ne $r6 -and -not [string]::IsNullOrWhiteSpace([string]$r6.NameServer)){throw 'IPv6 still manual; record retained'}
 $done=Join-Path $root 'VOLVE_DNS_Rescue_last_result.txt'
 [IO.File]::WriteAllText($done,'RESTORED AUTOMATIC '+(Get-Date).ToString('o'))
 Remove-Item -LiteralPath $journal -Force -ErrorAction Stop
 exit 0
} catch { [IO.File]::WriteAllText((Join-Path $root 'VOLVE_DNS_Rescue_last_error.txt'), $_.Exception.Message); exit 2 }
`

// Independent watchdog: runs without launching the potentially broken binary.
const watchdogPS = `$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$journal=Join-Path $root 'VOLVE_DNS_rescue_0270.json'
if(!(Test-Path -LiteralPath $journal)){exit 0}
try {
 $j=Get-Content -LiteralPath $journal -Raw -Encoding UTF8|ConvertFrom-Json -ErrorAction Stop
 if($j.schema -ne 1 -or $j.mode -ne 'automatic' -or $j.phase -notin @('pending','active')){throw 'Unrecognized journal'}
 # An installer may still be running; never race its pending transaction.
 if($j.phase -eq 'pending') {
  $age=((Get-Date).ToUniversalTime()-([datetime]$j.activated_at).ToUniversalTime()).TotalSeconds
  if($age -ge 0 -and $age -lt 120){exit 0}
  & (Join-Path $root 'VOLVE_DNS_Rescue_0270.ps1')
  exit $LASTEXITCODE
 }
} catch {
 [IO.File]::WriteAllText((Join-Path $root 'VOLVE_DNS_Watchdog_last_error.txt'),$_.Exception.Message)
 # Corrupt record must not silently alter any adapter; record stays for manual intervention.
 exit 2
}
function Probe([string]$ip, [string]$domain, [int]$wantCode) {
  $u=$null
  try {
   [byte[]]$q=@(0x76,0x71,0x01,0x00,0x00,0x01,0,0,0,0,0,0)
   foreach($label in $domain.Split('.')){
    $b=[Text.Encoding]::ASCII.GetBytes($label)
    $q+= [byte]$b.Length
    $q+= $b
   }
   $q+= [byte[]]@(0,0,1,0,1)
   if($ip -eq '::1'){$u=[Net.Sockets.UdpClient]::new([Net.Sockets.AddressFamily]::InterNetworkV6)}else{$u=[Net.Sockets.UdpClient]::new()}
   $u.Client.ReceiveTimeout=2500
   $u.Connect($ip,53)
   [void]$u.Send($q,$q.Length)
   $peer=[Net.IPEndPoint]::new([Net.IPAddress]::Any,0)
   if($ip -eq '::1'){$peer=[Net.IPEndPoint]::new([Net.IPAddress]::IPv6Any,0)}
   [byte[]]$r=$u.Receive([ref]$peer)
   if($r.Length -lt 12 -or $r[0] -ne 0x76 -or $r[1] -ne 0x71){return $false}
   if(($r[3] -band 15) -ne $wantCode){return $false}
   if($wantCode -eq 0 -and ($r[6] -eq 0 -and $r[7] -eq 0)){return $false}
   return $true
  } catch {return $false} finally {if($null -ne $u){$u.Dispose()}}
}
for($i=0;$i -lt 3;$i++){
 $good=$true
 foreach($ip in @('127.0.0.1','::1')) {
  if(!(Probe $ip 'stake.com' 3) -or !(Probe $ip 'example.org' 0)){$good=$false;break}
 }
 if($good){exit 0}
 Start-Sleep -Seconds 2
}
& (Join-Path $root 'VOLVE_DNS_Rescue_0270.ps1')
exit $LASTEXITCODE
`

func fileAtomic(path string, data []byte) error {
	dir := filepath.Dir(path)
	if e := os.MkdirAll(dir, 0700); e != nil {
		return e
	}
	f, e := os.CreateTemp(dir, ".volve-snapshot-*")
	if e != nil {
		return e
	}
	defer os.Remove(f.Name())
	if _, e = f.Write(data); e != nil {
		f.Close()
		return e
	}
	if e = f.Sync(); e != nil {
		f.Close()
		return e
	}
	if e = f.Close(); e != nil {
		return e
	}
	return os.Rename(f.Name(), path)
}

// Fail closed if a rescue file cannot be restricted to SYSTEM / Administrators.
func protectDNSFile(path string) error {
	out, e := hiddenCommand("icacls.exe", path, "/inheritance:r", "/grant:r", "*S-1-5-18:F", "*S-1-5-32-544:F").CombinedOutput()
	if e != nil {
		return fmt.Errorf("No se aseguró respaldo de rescate %s: %s: %w", filepath.Base(path), strings.TrimSpace(string(out)), e)
	}
	return nil
}
func installedExe() (string, error) { return servicePath() }
func confirmOwnTask(name, executable, arg string) (bool, error) {
	data, exists, e := taskQuery(name)
	if e != nil {
		return false, e
	}
	if !exists {
		return false, nil
	}
	if e = verifySystemTaskXML(data, executable, arg); e != nil {
		return false, fmt.Errorf("tarea %s no reconocida: %w", name, e)
	}
	return true, nil
}
func makeTask(name, schedule, command, ownershipPath, arg string) error {
	exists, e := confirmOwnTask(name, ownershipPath, arg)
	if e != nil {
		return e
	}
	if exists {
		return nil
	}
	args := []string{"/Create", "/TN", name, "/RU", "SYSTEM", "/RL", "HIGHEST", "/SC", schedule}
	if schedule == "MINUTE" {
		args = append(args, "/MO", "1")
	}
	args = append(args, "/TR", command)
	out, e := hiddenCommand("schtasks.exe", args...).CombinedOutput()
	if e != nil {
		return fmt.Errorf("tarea %s: %s: %w", name, strings.TrimSpace(string(out)), e)
	}
	verified, er := confirmOwnTask(name, ownershipPath, arg)
	if er != nil {
		return er
	}
	if !verified {
		return errors.New("La tarea de rescate no se pudo verificar tras crearla")
	}
	return nil
}
func installDNSComponents() error {
	if !isAdmin() {
		return errors.New("requerido administrador")
	}
	root, e := installRoot()
	if e != nil {
		return e
	}
	if e = os.MkdirAll(root, 0700); e != nil {
		return e
	}
	self, e := os.Executable()
	if e != nil {
		return e
	}
	// This copy is the executable that runs the persistent DNS worker. It is
	// NEVER overwritten while active; upgrades require a stop/restore first.
	exe, _ := installedExe()
	b, e := os.ReadFile(self)
	if e != nil {
		return e
	}
	if old, er := os.ReadFile(exe); er == nil {
		if sha256.Sum256(old) != sha256.Sum256(b) {
			return errors.New("motor DNS previo instalado: restaurá DNS antes de reemplazar")
		}
	} else if errors.Is(er, os.ErrNotExist) {
		if e = fileAtomic(exe, b); e != nil {
			return e
		}
	} else {
		return er
	}
	rescue, _ := scriptPath()
	if e = fileAtomic(rescue, []byte(rescuePS)); e != nil {
		return e
	}
	watchdog := filepath.Join(root, "VOLVE_DNS_Watchdog_0270.ps1")
	if e = fileAtomic(watchdog, []byte(watchdogPS)); e != nil {
		return e
	}
	if e = fileAtomic(filepath.Join(root, "VOLVE_RESTAURAR_DNS_EMERGENCIA.bat"), embeddedEmergencyBAT); e != nil {
		return e
	}
	// Protect scripts + journal directory from non-administrative edits.
	if e = hiddenCommand("icacls.exe", rescue, "/inheritance:r", "/grant:r", "*S-1-5-18:F", "*S-1-5-32-544:F").Run(); e != nil {
		return fmt.Errorf("ACL de rescate no validada: %w", e)
	}
	if e = hiddenCommand("icacls.exe", watchdog, "/inheritance:r", "/grant:r", "*S-1-5-18:F", "*S-1-5-32-544:F").Run(); e != nil {
		return fmt.Errorf("ACL de watchdog no validada: %w", e)
	}
	serviceCmd := quoteTaskScriptPath(exe) + " --dns-service"
	if e = makeTask(dnsServiceTask, "ONSTART", serviceCmd, exe, "--dns-service"); e != nil {
		return e
	}
	watchdogCmd := quoteTaskScriptPath(filepath.Join(os.Getenv("WINDIR"), "System32", "WindowsPowerShell", "v1.0", "powershell.exe")) + " -NoProfile -NonInteractive -ExecutionPolicy Bypass -File " + quoteTaskScriptPath(watchdog)
	if e = makeTask(dnsRescueTask, "MINUTE", watchdogCmd, filepath.Join(os.Getenv("WINDIR"), "System32", "WindowsPowerShell", "v1.0", "powershell.exe"), expectedRescueArgs(watchdog)); e != nil {
		return e
	}
	// Windows Task Scheduler otherwise terminates long-running tasks after the
	// default execution time limit (commonly 72 h). Set unlimited runtime and
	// bounded restart on failure; fail closed before modifying DNS if this fails.
	persist := "$ErrorActionPreference='Stop';" +
		"$task=Get-ScheduledTask -TaskName '" + dnsServiceTask + "' -ErrorAction Stop;" +
		"$settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries;" +
		"Set-ScheduledTask -TaskName '" + dnsServiceTask + "' -Settings $settings -ErrorAction Stop | Out-Null;" +
		"$verify=Get-ScheduledTask -TaskName '" + dnsServiceTask + "' -ErrorAction Stop;" +
		"if([string]$verify.Settings.ExecutionTimeLimit -ne 'PT0S'){throw 'DNS service execution time remains limited'}"
	if out, err := runPS(persist); err != nil {
		return fmt.Errorf("No se configuró tarea DNS persistente: %s: %w", out, err)
	}
	return nil
}
func fullEngine() (*blocker.Engine, error) {
	root, e := installRoot()
	if e != nil {
		return nil, e
	}
	// Use the downloaded Full list, not a status counter.
	feeds := filepath.Join(root, "catalog", "feeds")
	names := []string{"hagezi_gambling_full", "hagezi_gambling_medium", "stevenblack_gambling", "arkynx_gambling"}
	var combined []string
	for i, name := range names {
		path := filepath.Join(feeds, name+".txt")
		f, er := os.Open(path)
		if er != nil {
			if i == 0 {
				return nil, er
			}
			continue
		}
		vals, er := blocker.Parse(f, 950000)
		f.Close()
		if er != nil {
			return nil, er
		}
		if i == 0 && len(vals) < 400000 {
			return nil, fmt.Errorf("catálogo Full insuficiente (%d)", len(vals))
		}
		combined = append(combined, vals...)
	}
	combined = append(combined, "stake.com", "bet.ar")
	return blocker.New(combined, true), nil
}
func feedSignature() [32]byte {
	root, _ := installRoot()
	var parts []string
	for _, name := range []string{"hagezi_gambling_full", "hagezi_gambling_medium", "stevenblack_gambling", "arkynx_gambling"} {
		p := filepath.Join(root, "catalog", "feeds", name+".txt")
		if f, e := os.Stat(p); e == nil {
			parts = append(parts, name, fmt.Sprint(f.ModTime().UnixNano()), fmt.Sprint(f.Size()))
		}
	}
	return sha256.Sum256([]byte(strings.Join(parts, "|")))
}
func catalogDigest() ([32]byte, error) {
	var result [32]byte
	root, e := installRoot()
	if e != nil {
		return result, e
	}
	h := sha256.New()
	for _, name := range []string{"hagezi_gambling_full", "hagezi_gambling_medium", "stevenblack_gambling", "arkynx_gambling"} {
		f, e := os.Open(filepath.Join(root, "catalog", "feeds", name+".txt"))
		if errors.Is(e, os.ErrNotExist) && name != "hagezi_gambling_full" {
			continue
		}
		if e != nil {
			return result, e
		}
		h.Write([]byte(name + "\x00"))
		_, e = io.Copy(h, f)
		f.Close()
		if e != nil {
			return result, e
		}
	}
	copy(result[:], h.Sum(nil))
	return result, nil
}
func runDNSService() error {
	engine, e := fullEngine()
	if e != nil {
		return e
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	sv4 := dnsproxy.New(engine, []string{"1.1.1.1:53", "9.9.9.9:53"})
	sv6 := dnsproxy.New(engine, []string{"1.1.1.1:53", "9.9.9.9:53"})
	errorsCh := make(chan error, 2)
	go func() { errorsCh <- sv4.Run(ctx, "127.0.0.1", 53) }()
	select {
	case <-sv4.Ready():
	case e := <-errorsCh:
		return e
	case <-time.After(10 * time.Second):
		return errors.New("UDP IPv4 no inició")
	}
	go func() { errorsCh <- sv6.Run(ctx, "::1", 53) }()
	select {
	case <-sv6.Ready():
	case e := <-errorsCh:
		return e
	case <-time.After(10 * time.Second):
		return errors.New("UDP IPv6 no inició")
	}
	// Feed updates are installed hourly by an independent task. The resident
	// worker swaps the immutable engine every five minutes, if lists changed.
	tick := time.NewTicker(5 * time.Minute)
	defer tick.Stop()
	last := feedSignature()
	for {
		select {
		case e := <-errorsCh:
			return e
		case <-tick.C:
			stamp := feedSignature()
			if stamp == last {
				continue
			}
			updated, er := fullEngine()
			if er != nil {
				continue
			}
			sv4.SwapRules(updated)
			sv6.SwapRules(updated)
			last = stamp
		}
	}
}
func checkDNSLocal() error {
	if e := dnsproxy.Probe("127.0.0.1:53", "stake.com", "example.org"); e != nil {
		return fmt.Errorf("IPv4: %w", e)
	}
	if e := dnsproxy.Probe("[::1]:53", "stake.com", "example.org"); e != nil {
		return fmt.Errorf("IPv6: %w", e)
	}
	return nil
}
func waitDNSReady() error {
	var e error
	for i := 0; i < 15; i++ {
		e = checkDNSLocal()
		if e == nil {
			return nil
		}
		time.Sleep(1 * time.Second)
	}
	return fmt.Errorf("motor no verificable: %w", e)
}
func dnsSetServer(idx int, loop bool) error {
	if idx <= 0 {
		return errors.New("interface index inválido")
	}
	var cmd string
	if loop {
		cmd = fmt.Sprintf("Set-DnsClientServerAddress -InterfaceIndex %d -ServerAddresses @('127.0.0.1','::1') -ErrorAction Stop", idx)
	} else {
		cmd = fmt.Sprintf("Set-DnsClientServerAddress -InterfaceIndex %d -ResetServerAddresses -ErrorAction Stop", idx)
	}
	out, e := runPS("$ErrorActionPreference='Stop';" + cmd)
	if e != nil {
		return fmt.Errorf("Windows rechazó cambio DNS: %s (%w)", out, e)
	}
	return nil
}
func startTask(name string) error {
	out, e := hiddenCommand("schtasks.exe", "/Run", "/TN", name).CombinedOutput()
	if e != nil {
		return fmt.Errorf("no pudo arrancar %s: %s (%w)", name, strings.TrimSpace(string(out)), e)
	}
	return nil
}
func journalExists() (bool, error) {
	p, e := backupPath()
	if e != nil {
		return false, e
	}
	_, e = os.Stat(p)
	if e == nil {
		return true, nil
	}
	if errors.Is(e, os.ErrNotExist) {
		return false, nil
	}
	return false, e
}
func activateDNS() error {
	if !isAdmin() {
		return errors.New("necesita permisos de administrador")
	}
	already, e := journalExists()
	if e != nil {
		return e
	}
	if already {
		return errors.New("ya hay copia de rescate activa; no se reemplaza")
	}
	snapshot, e := dnsrollout.CaptureOriginalDNS(context.Background())
	if e != nil {
		return e
	}
	if e = snapshot.Validate(); e != nil {
		return e
	}
	if snapshot.RestoreMode != "automatic" {
		return errors.New("esta edición solo activa DNS si Windows tenía asignación AUTOMÁTICA")
	}
	// Avoid changing a machine with multiple physical IPv4 adapters; the
	// CaptureOriginalDNS already enforces this guard.
	if e = installDNSComponents(); e != nil {
		return e
	}
	if e = startTask(dnsServiceTask); e != nil {
		return e
	}
	if e = waitDNSReady(); e != nil {
		return e
	}
	journal := dnsProductionBackup{Schema: 1, Phase: "pending", Mode: "automatic", InterfaceIndex: snapshot.InterfaceIndex, InterfaceGUID: snapshot.InterfaceGUID, ActivatedAt: time.Now().Format(time.RFC3339)}
	b, e := json.Marshal(journal)
	if e != nil {
		return e
	}
	p, _ := backupPath()
	if e = fileAtomic(p, b); e != nil {
		return e
	}
	if e = protectDNSFile(p); e != nil {
		os.Remove(p)
		return e
	}
	// The independent watchdog already exists, and now sees the journal. It
	// must not run BEFORE the installer sets the local DNS; the health probe
	// already succeeds at this point.
	if e = dnsSetServer(snapshot.InterfaceIndex, true); e != nil {
		restoreErr := restoreDNS()
		if restoreErr != nil {
			return errors.Join(e, fmt.Errorf("CRÍTICO restauración no confirmada: %w", restoreErr))
		}
		return e
	}
	if e = waitDNSReady(); e != nil {
		restoreErr := restoreDNS()
		if restoreErr != nil {
			return errors.Join(e, fmt.Errorf("CRÍTICO restauración no confirmada: %w", restoreErr))
		}
		return e
	}
	// Verify exact configured server values after OS mutation.
	out, er := runPS(fmt.Sprintf("$ErrorActionPreference='Stop';$v4=@((Get-DnsClientServerAddress -InterfaceIndex %d -AddressFamily IPv4).ServerAddresses);$v6=@((Get-DnsClientServerAddress -InterfaceIndex %d -AddressFamily IPv6).ServerAddresses);if('127.0.0.1' -notin $v4 -or '::1' -notin $v6){throw 'Windows DNS is not loopback for both families'}", snapshot.InterfaceIndex, snapshot.InterfaceIndex))
	if er != nil {
		restoreErr := restoreDNS()
		if restoreErr != nil {
			return errors.Join(fmt.Errorf("Windows DNS verification: %s", out), restoreErr)
		}
		return fmt.Errorf("Windows DNS verification: %s (%w)", out, er)
	}
	journal.Phase = "active"
	b, e = json.Marshal(journal)
	if e != nil {
		return e
	}
	if e = fileAtomic(p, b); e != nil {
		restoreErr := restoreDNS()
		if restoreErr != nil {
			return errors.Join(e, fmt.Errorf("CRÍTICO: falló el respaldo activo y la recuperación: %w", restoreErr))
		}
		return fmt.Errorf("Respaldo activo falló; DNS restaurado: %w", e)
	}
	if e = protectDNSFile(p); e != nil {
		restoreErr := restoreDNS()
		if restoreErr != nil {
			return errors.Join(e, fmt.Errorf("CRÍTICO: permisos del respaldo y recuperación: %w", restoreErr))
		}
		return fmt.Errorf("Permisos del respaldo no confirmados; DNS restaurado: %w", e)
	}
	return nil
}
func restoreDNS() error {
	if !isAdmin() {
		return errors.New("necesita administrador")
	}
	exists, e := journalExists()
	if e != nil {
		return e
	}
	if !exists {
		return errors.New("no hay activación DNS registrada de VOLVÉ")
	}
	script, e := scriptPath()
	if e != nil {
		return e
	}
	out, e := runPS("& '" + strings.ReplaceAll(script, "'", "''") + "'")
	if e != nil {
		return fmt.Errorf("restauración DNS no verificada; copia preservada: %s (%w)", out, e)
	}
	return nil
}
func dnsStatus() string {
	exists, e := journalExists()
	if e != nil {
		return "DNS real: error leyendo registro: " + e.Error() + "\n"
	}
	if !exists {
		return "DNS real: no activado (catálogo y navegadores pueden estar protegidos).\n"
	}
	if e = checkDNSLocal(); e != nil {
		return "DNS real: RECUPERACIÓN PENDIENTE; motor no comprobado. Usar BAT de rescate.\n"
	}
	return "DNS real: motor responde en 127.0.0.1:53; verificar también configuración IPv4/IPv6.\n"
}
func expectedExeDigest() string {
	p, e := installedExe()
	if e != nil {
		return ""
	}
	b, e := os.ReadFile(p)
	if e != nil {
		return ""
	}
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:])
}
