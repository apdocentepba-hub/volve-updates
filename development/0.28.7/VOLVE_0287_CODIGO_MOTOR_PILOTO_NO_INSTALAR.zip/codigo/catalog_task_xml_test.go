package main

import (
	"encoding/binary"
	"strings"
	"testing"
)

const sampleTask = `<?xml version="1.0" encoding="UTF-16"?><Task xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task"><Principals><Principal><UserId>S-1-5-18</UserId></Principal></Principals><Actions><Exec><Command>C:\ProgramData\VOLVE-Browser-Filter\VOLVE_Motor_0210.exe</Command><Arguments>--refresh</Arguments></Exec></Actions></Task>`
const exepath = `C:\ProgramData\VOLVE-Browser-Filter\VOLVE_Motor_0210.exe`

func utf16Bytes(s string, be bool) []byte {
	b := []byte{0xff, 0xfe}
	var order binary.ByteOrder = binary.LittleEndian
	if be {
		b = []byte{0xfe, 0xff}
		order = binary.BigEndian
	}
	for _, c := range s {
		w := uint16(c)
		v := make([]byte, 2)
		order.PutUint16(v, w)
		b = append(b, v...)
	}
	return b
}
func TestTaskOwnershipUTF16(t *testing.T) {
	for _, input := range [][]byte{[]byte(strings.Replace(sampleTask, `encoding="UTF-16"`, `encoding="UTF-8"`, 1)), utf16Bytes(sampleTask, false), utf16Bytes(sampleTask, true), utf16Bytes(sampleTask, false)[2:], utf16Bytes(sampleTask, true)[2:]} {
		if e := verifyTaskXML(input, exepath); e != nil {
			t.Fatalf("valid own task incorrectly rejected: %v", e)
		}
	}
}
func TestTaskRejectForeign(t *testing.T) {
	tests := []string{
		strings.Replace(sampleTask, exepath, `C:\Windows\System32\cmd.exe`, 1),
		strings.Replace(sampleTask, "--refresh", "--refresh --delete", 1),
		strings.Replace(sampleTask, "S-1-5-18", "other-user", 1),
		strings.Replace(sampleTask, `<Actions><Exec>`, `<Actions><Exec><Command>bad</Command></Exec><Exec>`, 1),
		strings.Replace(sampleTask, `</Actions>`, `<ComHandler><ClassId>bad</ClassId></ComHandler></Actions>`, 1),
	}
	for _, s := range tests {
		if e := verifyTaskXML([]byte(s), exepath); e == nil {
			t.Fatalf("accepted task that must be preserved: %s", s)
		}
	}
}
func TestTaskRejectTruncated(t *testing.T) {
	b := utf16Bytes(sampleTask, false)
	if _, e := decodeTaskXML(b[:len(b)-1]); e == nil {
		t.Fatal("accepted truncated UTF-16")
	}
}

func TestStrictSystemTaskOwnershipForDNSServer(t *testing.T) {
	service := `C:\ProgramData\VOLVE-Browser-Filter\VOLVE_DNS_Server_0270.exe`
	src := strings.ReplaceAll(sampleTask, exepath, service)
	src = strings.ReplaceAll(src, "--refresh", "--dns-service")
	if err := verifySystemTaskXML([]byte(src), service, "--dns-service"); err != nil {
		t.Fatalf("expected exact SYSTEM task to pass: %v", err)
	}
	for _, tt := range []struct{ text, binary, args string }{
		{src, service, "--dns-restore"},
		{strings.Replace(src, "--dns-service", "--dns-service --dns-restore", 1), service, "--dns-service"},
		{strings.Replace(src, "S-1-5-18", "S-1-5-19", 1), service, "--dns-service"},
		{src, `C:\Users\Public\VOLVE_DNS_Server_0270.exe`, "--dns-service"},
	} {
		if err := verifySystemTaskXML([]byte(tt.text), tt.binary, tt.args); err == nil {
			t.Fatalf("accepted untrusted task action/principal/argument")
		}
	}
}
