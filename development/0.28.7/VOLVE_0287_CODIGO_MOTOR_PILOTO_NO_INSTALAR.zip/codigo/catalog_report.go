package main

import (
	"encoding/json"
	"fmt"
	"strings"
)

// A counter in estado.json is not evidence that Windows uses these domains
// as DNS protection. Always display source-level coverage independently.
type catalogCheck struct {
	CatalogDomains int      `json:"catalog_domains"`
	LastCheck      string   `json:"last_check"`
	Warnings       []string `json:"warnings"`
	Sources        []struct {
		ID          string `json:"id"`
		Domains     int    `json:"domains"`
		LastSuccess string `json:"last_success"`
		Error       string `json:"error"`
	} `json:"sources"`
}

func formatCatalogReport(raw []byte) string {
	if len(raw) == 0 || len(raw) > (1<<20) {
		return "Catálogo: informe ausente o demasiado grande. Estado no confirmado.\n"
	}
	var c catalogCheck
	if err := json.Unmarshal(raw, &c); err != nil || c.CatalogDomains < 0 || c.CatalogDomains > 5000000 {
		return "Catálogo: informe inválido; NO asumir cobertura masiva.\n"
	}
	var b strings.Builder
	fmt.Fprintf(&b, "Catálogo en caché: %d dominios únicos (consulta: %s).\n", c.CatalogDomains, c.LastCheck)
	full, found := 0, false
	for _, s := range c.Sources {
		if s.ID == "hagezi_gambling_full" {
			full = s.Domains
			found = true
			break
		}
	}
	if !found {
		b.WriteString("HaGeZi Full: sin datos por fuente en el informe; cobertura NO comprobada.\n")
	} else {
		fmt.Fprintf(&b, "HaGeZi Full: %d entradas informadas.\n", full)
	}
	if c.CatalogDomains < 400000 || full < 400000 {
		b.WriteString("ATENCIÓN: catálogo masivo incompleto/no acreditado. No son 600.000 bloqueos.\n")
	} else {
		b.WriteString("Catálogo masivo informado; esta cifra no demuestra por sí sola que el DNS esté activo.\n")
	}
	if len(c.Warnings) > 0 {
		fmt.Fprintf(&b, "Fuentes con advertencias: %d; revisar descarga/registro del motor.\n", len(c.Warnings))
	}
	return b.String()
}
