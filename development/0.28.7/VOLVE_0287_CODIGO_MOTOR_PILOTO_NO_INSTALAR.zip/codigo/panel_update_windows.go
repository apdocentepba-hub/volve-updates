//go:build windows

package main

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"unsafe"
	"volve-browser-protection/releaseupdate"
)

// The administrative helper is the CURRENT installed VOLVÉ executable, not
// downloaded code. It validates the staged package again before installing
// only the new versioned panel (never replaces the DNS worker or watchdog).
func launchPanelUpdateAdmin(path string) error {
	self, err := os.Executable()
	if err != nil {
		return err
	}
	verb := syscall.StringToUTF16Ptr("runas")
	exepath := syscall.StringToUTF16Ptr(self)
	params := syscall.StringToUTF16Ptr("--apply-staged-panel-update " + syscall.EscapeArg(path))
	r, _, er := shell.NewProc("ShellExecuteW").Call(0, uintptr(unsafe.Pointer(verb)), uintptr(unsafe.Pointer(exepath)), uintptr(unsafe.Pointer(params)), 0, 1)
	if r <= 32 {
		return fmt.Errorf("Windows no autorizó la actualización (código %d): %v", r, er)
	}
	return nil
}

func installVerifiedStagedPanel(staged string) error {
	if !isAdmin() {
		return errors.New("solo administrador")
	}
	key, err := base64.StdEncoding.DecodeString(updaterPublicKey)
	if err != nil {
		return err
	}
	m, err := releaseupdate.VerifyStaged(staged, ed25519.PublicKey(key))
	if err != nil {
		return fmt.Errorf("actualización rechazada: %w", err)
	}
	cmp, err := releaseupdate.CompareVersions(version, m.Version)
	if err != nil {
		return err
	}
	if cmp >= 0 {
		return errors.New("el paquete no es una versión posterior")
	}
	receiptPath, err := statePath()
	if err != nil {
		return err
	}
	dir := filepath.Dir(receiptPath)
	if err = os.MkdirAll(dir, 0700); err != nil {
		return err
	}
	// Do not re-point shortcuts backwards when this installer is launched
	// from an older still-running Centre.
	if err = releaseupdate.EnsureNoInstalledDowngrade(dir, m.Version); err != nil {
		return err
	}
	target := filepath.Join(dir, "VOLVE_Centro_Proteccion_"+strings.ReplaceAll(m.Version, ".", "_")+".exe")
	// Never overwrite an existing EXE. This preserves the previous panel for
	// manual rollback and avoids replacing a currently running process.
	if existing, er := os.Open(target); er == nil {
		h := sha256.New()
		n, readErr := io.Copy(h, existing)
		existing.Close()
		if readErr != nil || n != m.Size || !strings.EqualFold(hex.EncodeToString(h.Sum(nil)), m.SHA256) {
			return errors.New("ya existe una versión diferente en el destino; no se reemplazó")
		}
		return createPanelLinks(target)
	} else if !errors.Is(er, os.ErrNotExist) {
		return er
	}

	input, err := os.Open(staged)
	if err != nil {
		return err
	}
	defer input.Close()
	tmp, err := os.CreateTemp(dir, ".volve-verified-panel-*.exe")
	if err != nil {
		return err
	}
	defer os.Remove(tmp.Name())
	h := sha256.New()
	n, err := io.Copy(io.MultiWriter(tmp, h), io.LimitReader(input, m.Size+1))
	if err != nil {
		tmp.Close()
		return err
	}
	if n != m.Size || !strings.EqualFold(hex.EncodeToString(h.Sum(nil)), m.SHA256) {
		tmp.Close()
		return errors.New("archivo modificado antes de la instalación; no se modificó Windows")
	}
	if err = tmp.Sync(); err != nil {
		tmp.Close()
		return err
	}
	if err = tmp.Close(); err != nil {
		return err
	}
	if err = movePanelExclusive(tmp.Name(), target); err != nil {
		return err
	}
	// Only shortcuts point to this new version; no services, network or DNS.
	return createPanelLinks(target)
}

// Do not replace an existing versioned binary, even if another process
// creates the destination between our initial check and the final move.
func movePanelExclusive(source, target string) error {
	src, err := syscall.UTF16PtrFromString(source)
	if err != nil {
		return err
	}
	dst, err := syscall.UTF16PtrFromString(target)
	if err != nil {
		return err
	}
	const moveFileWriteThrough = 0x00000008
	ok, _, callErr := syscall.NewLazyDLL("kernel32.dll").NewProc("MoveFileExW").Call(
		uintptr(unsafe.Pointer(src)), uintptr(unsafe.Pointer(dst)), moveFileWriteThrough)
	if ok == 0 {
		return fmt.Errorf("no se pudo publicar panel nuevo sin sobrescribir otro archivo: %w", callErr)
	}
	return nil
}
