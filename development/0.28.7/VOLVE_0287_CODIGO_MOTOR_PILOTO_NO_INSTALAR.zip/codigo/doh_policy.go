package main

import (
	"fmt"
	"strings"
)

type dohPolicy struct {
	Key   string `json:"key"`
	Name  string `json:"name"`
	Type  string `json:"type"`
	Value string `json:"value"`
}

// Only missing entries are created. An existing enterprise policy is NEVER overwritten.
func dohSpecs() []dohPolicy {
	return []dohPolicy{
		{`HKLM\SOFTWARE\Policies\Google\Chrome`, "DnsOverHttpsMode", "REG_SZ", "off"},
		{`HKLM\SOFTWARE\Policies\Microsoft\Edge`, "DnsOverHttpsMode", "REG_SZ", "off"},
		{`HKLM\SOFTWARE\Policies\Mozilla\Firefox\DNSOverHTTPS`, "Enabled", "REG_DWORD", "0x0"},
		{`HKLM\SOFTWARE\Policies\Mozilla\Firefox\DNSOverHTTPS`, "Locked", "REG_DWORD", "0x1"},
	}
}
func approvedDoH(p dohPolicy) bool {
	for _, x := range dohSpecs() {
		if p == x {
			return true
		}
	}
	return false
}
func normalizeRegValue(typ, value string) string {
	if typ == "REG_DWORD" {
		if strings.EqualFold(strings.TrimSpace(value), "0x00000000") {
			return "0x0"
		}
		if strings.EqualFold(strings.TrimSpace(value), "0x00000001") {
			return "0x1"
		}
	}
	return strings.TrimSpace(value)
}

// Parse reg.exe query output in any Windows locale; names and types are locale-invariant.
func parseRegValue(output, name string) (typ, value string, present bool, err error) {
	for _, line := range strings.Split(output, "\n") {
		f := strings.Fields(line)
		if len(f) >= 3 && strings.EqualFold(f[0], name) && strings.HasPrefix(strings.ToUpper(f[1]), "REG_") {
			if present {
				return "", "", false, fmt.Errorf("duplicate registry entry: %s", name)
			}
			typ, value, present = strings.ToUpper(f[1]), strings.Join(f[2:], " "), true
		}
	}
	return typ, normalizeRegValue(typ, value), present, nil
}
