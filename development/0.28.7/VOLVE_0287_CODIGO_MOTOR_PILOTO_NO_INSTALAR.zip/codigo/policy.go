package main

import (
	"fmt"
	"regexp"
	"sort"
	"strings"
)

const version = "0.28.7"

// Explicit, reviewable starter catalogue. Browser policies match subdomains.
var domains = []string{
	"casino.example", "bet.ar", "stake.com", "bet365.com", "betsson.com", "betano.com", "bwin.com",
	"1xbet.com", "pokerstars.com", "betwarrior.bet.ar", "citycenteronline.bet.ar",
	"bplay.bet.ar", "vipplay.bet.ar", "betsur.bet.ar", "powerbet.bet.ar",
	"betfair.com", "888casino.com", "888poker.com", "casino.com", "unibet.com",
	"pinnacle.com", "sportingbet.com", "codere.bet.ar", "betway.com", "betmotion.com",
	"parimatch.com", "casinoonline.bet.ar", "betsson.bet.ar", "betano.bet.ar",
	"bet365.bet.ar", "sportsbet.bet.ar", "sports.bet.ar", "stake.bet.ar", "easybet.bet.ar",
	"super7.bet.ar", "jugadon.bet.ar", "playuzu.bet.ar", "betfun.bet.ar",
	"casinobuenosairesonline.bet.ar", "betsson.com.ar",
}

var validDomain = regexp.MustCompile(`^[a-z0-9]+(?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9]+(?:[a-z0-9-]*[a-z0-9])?)+$`)

type entry struct {
	Key   string `json:"key"`
	Name  string `json:"name"`
	Value string `json:"value"`
}
type receipt struct {
	Version string  `json:"version"`
	Status  string  `json:"status"`
	Entries []entry `json:"entries"`
}

func policyEntries() ([]entry, error) {
	var ds []string
	seen := map[string]bool{}
	for _, input := range domains {
		d := strings.ToLower(strings.TrimSpace(input))
		if !validDomain.MatchString(d) {
			return nil, fmt.Errorf("invalid domain: %s", d)
		}
		if !seen[d] {
			ds = append(ds, d)
			seen[d] = true
		}
	}
	sort.Strings(ds)
	keys := []string{
		`HKLM\SOFTWARE\Policies\Google\Chrome\URLBlocklist`,
		`HKLM\SOFTWARE\Policies\Microsoft\Edge\URLBlocklist`,
		`HKLM\SOFTWARE\Policies\Mozilla\Firefox\WebsiteFilter\Block`,
	}
	result := []entry{}
	for _, k := range keys {
		for _, d := range ds {
			if strings.Contains(k, `Mozilla`) {
				// Firefox match patterns: bare host and all its subdomains.
				result = append(result, entry{Key: k, Value: "*://" + d + "/*"}, entry{Key: k, Value: "*://*." + d + "/*"})
			} else {
				// Chrome/Edge domain alone matches the domain + all subdomains.
				result = append(result, entry{Key: k, Value: d})
			}
		}
	}
	return result, nil
}

// parseRegStringValues parses one 'reg query KEY' response. It is used only
// for read-only diagnostic, not for installation or deletion of policy values.
// Windows output can have CRLF, indentation and localized header text.
func parseRegStringValues(output string) map[string]string {
	values := make(map[string]string)
	for _, line := range strings.Split(output, "\n") {
		columns := strings.Fields(line)
		if len(columns) >= 3 && strings.EqualFold(columns[1], "REG_SZ") {
			values[columns[0]] = strings.Join(columns[2:], " ")
		}
	}
	return values
}
