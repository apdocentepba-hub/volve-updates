package main

import "testing"

func TestRescueArgumentsExact(t *testing.T) {
	path := `C:\ProgramData\VOLVE-Browser-Filter\VOLVE_DNS_Watchdog_0270.ps1`
	got := expectedRescueArgs(path)
	want := `-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "C:\ProgramData\VOLVE-Browser-Filter\VOLVE_DNS_Watchdog_0270.ps1"`
	if got != want {
		t.Fatalf("want %q got %q", want, got)
	}
	bad := legacyRescueArgs(path)
	if bad == want || !repairableRescueArgs(bad, path) {
		t.Fatalf("legacy not recognized: %q", bad)
	}
	if repairableRescueArgs(got, path) {
		t.Fatal("correct args must not be flagged")
	}
	for _, s := range []string{bad + " -EncodedCommand evil", "-NoProfile -File " + path, "", bad + " "} {
		if repairableRescueArgs(s, path) {
			t.Fatalf("unsafe accepted %q", s)
		}
	}
}
