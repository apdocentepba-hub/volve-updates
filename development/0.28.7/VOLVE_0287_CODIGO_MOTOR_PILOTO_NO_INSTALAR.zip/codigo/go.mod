module volve-browser-protection

go 1.23
