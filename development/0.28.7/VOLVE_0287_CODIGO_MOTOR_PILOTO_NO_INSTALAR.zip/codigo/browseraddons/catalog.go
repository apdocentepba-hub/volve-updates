package browseraddons

import (
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"
)

// The untrusted store IDs are authenticated before parsing. There is no fallback
// to an unsigned, locally supplied JSON file or an arbitrary extension URL.
const ManifestURL = "https://raw.githubusercontent.com/apdocentepba-hub/volve-updates/main/releases/browser-addons.json"
const maxManifestBytes = 4096

var ErrNotPublished = errors.New("los complementos aún no están publicados en las tiendas oficiales")
var idRe = regexp.MustCompile(`^[a-p]{32}$`)

type Catalog struct {
	Schema     int    `json:"schema"`
	ChromeID   string `json:"chrome_id"`
	EdgeID     string `json:"edge_id"`
	FirefoxURL string `json:"firefox_url"`
}

func ValidCatalog(payload, signature []byte, pub ed25519.PublicKey) (Catalog, error) {
	var c Catalog
	if len(pub) != ed25519.PublicKeySize || len(payload) == 0 || len(payload) > maxManifestBytes {
		return c, errors.New("manifiesto de complementos inválido")
	}
	sig, err := base64.StdEncoding.DecodeString(strings.TrimSpace(string(signature)))
	if err != nil || !ed25519.Verify(pub, payload, sig) {
		return c, errors.New("firma de complementos incorrecta")
	}
	decoder := json.NewDecoder(strings.NewReader(string(payload)))
	decoder.DisallowUnknownFields()
	if err = decoder.Decode(&c); err != nil {
		return c, fmt.Errorf("manifiesto JSON de complementos inválido: %w", err)
	}
	var extra interface{}
	if decoder.Decode(&extra) != io.EOF {
		return c, errors.New("datos adicionales en el manifiesto")
	}
	if c.Schema != 1 || (c.ChromeID == "" && c.EdgeID == "" && c.FirefoxURL == "") {
		return c, errors.New("canal no tiene complementos válidos")
	}
	if c.ChromeID != "" && !idRe.MatchString(c.ChromeID) {
		return c, errors.New("ID de Chrome inválido")
	}
	if c.EdgeID != "" && !idRe.MatchString(c.EdgeID) {
		return c, errors.New("ID de Edge inválido")
	}
	if c.FirefoxURL != "" {
		u, err := url.Parse(c.FirefoxURL)
		if err != nil || u.Scheme != "https" || u.Host != "addons.mozilla.org" ||
			!strings.HasPrefix(u.EscapedPath(), "/en-US/firefox/addon/") ||
			u.User != nil || u.RawQuery != "" || u.Fragment != "" {
			return c, errors.New("URL oficial de Firefox inválida")
		}
	}
	return c, nil
}

// Fetch requires the fixed GitHub release channel and its detached signature.
// HTTP 404 always means 'not yet published' and causes NO registry changes.
func Fetch(ctx context.Context, public ed25519.PublicKey) (Catalog, error) {
	var empty Catalog
	client := &http.Client{Timeout: 18 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error {
		return errors.New("redirecciones de manifiesto no admitidas")
	}}
	get := func(addr string, limit int64) ([]byte, error) {
		req, err := http.NewRequestWithContext(ctx, "GET", addr, nil)
		if err != nil {
			return nil, err
		}
		r, err := client.Do(req)
		if err != nil {
			return nil, err
		}
		defer r.Body.Close()
		if r.StatusCode == http.StatusNotFound {
			return nil, ErrNotPublished
		}
		if r.StatusCode != 200 {
			return nil, fmt.Errorf("canal HTTP %d", r.StatusCode)
		}
		payload, err := io.ReadAll(io.LimitReader(r.Body, limit+1))
		if err != nil {
			return nil, err
		}
		if int64(len(payload)) > limit {
			return nil, errors.New("manifiesto de complementos excesivo")
		}
		return payload, nil
	}
	payload, err := get(ManifestURL, maxManifestBytes)
	if err != nil {
		return empty, err
	}
	signature, err := get(ManifestURL+".sig", 1024)
	if err != nil {
		return empty, err
	}
	return ValidCatalog(payload, signature, public)
}
