package browseraddons

import (
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"strings"
	"testing"
)

func TestSignatureAndCatalog(t *testing.T) {
	public, private, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	payload := []byte(`{"schema":1,"chrome_id":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","edge_id":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","firefox_url":"https://addons.mozilla.org/en-US/firefox/addon/volve-support/"}`)
	sig := []byte(base64.StdEncoding.EncodeToString(ed25519.Sign(private, payload)))
	if _, err := ValidCatalog(payload, sig, public); err != nil {
		t.Fatalf("valid catalog: %v", err)
	}
	changed := []byte(strings.ReplaceAll(string(payload), "addons.mozilla.org", "evil.example"))
	if _, err := ValidCatalog(changed, sig, public); err == nil {
		t.Fatal("tampering accepted")
	}
	trials := []string{
		`{"schema":1,"chrome_id":"notanid"}`,
		`{"schema":1,"chrome_id":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","extra":"x"}`,
		`{"schema":1,"firefox_url":"file:///tmp/payload.xpi"}`,
		`{"schema":1,"firefox_url":"https://example.org/en-US/firefox/addon/volve/"}`,
		`{"schema":1,"firefox_url":"https://addons.mozilla.org/en-US/firefox/addon/volve/?next=evil"}`,
		`{"schema":2,"chrome_id":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"}`,
		`{"schema":1}`,
	}
	for _, str := range trials {
		b := []byte(str)
		s := []byte(base64.StdEncoding.EncodeToString(ed25519.Sign(private, b)))
		if _, err := ValidCatalog(b, s, public); err == nil {
			t.Fatalf("accepted invalid %s", str)
		}
	}
	if _, err := ValidCatalog(payload, []byte("invalid"), public); err == nil {
		t.Fatal("bad sig accepted")
	}
}
