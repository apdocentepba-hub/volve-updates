# VOLVÉ 0.28.7 — Piloto del canal firmado para actualizar el motor DNS

**Estado: código de desarrollo, NO publicar como versión estable ni instalar en equipos protegidos.**

Fuente: copia de seguridad de VOLVÉ 0.28.5 con un primer módulo adicional de actualización del motor. La instalación estable del usuario es VOLVÉ 0.28.6.

## Implementado

- Paquete `motorupdate/` independiente del actualizador del Centro (`releaseupdate/`).
- Canal futuro `releases/motor-stable.json` separado de `releases/stable.json`.
- Manifiesto firmado Ed25519 con `component=dns-engine`, versión propia del motor, versión mínima del Centro, URL restringida, SHA-256 y tamaño.
- Descarga y preparación en un directorio temporal versionado, sin tocar el DNS local.
- Revalidación del paquete preparado y rechazo de paquetes modificados, de otro componente o de otra procedencia.
- Interfaz simulable `SwitchDriver` con precarga, captura previa, instalación versionada, conmutación, comprobación y reversión. **No existe aún controlador real de Windows; no puede reemplazar el motor residente.**
- Comando `--check-motor-updates` de solo consulta.
- Opción avanzada `Consultar motor (piloto)` en el Centro, sin efecto sobre motor DNS.

## Pruebas

- `go test ./...`: aprobado en Linux.
- `go test -race ./motorupdate ./releaseupdate`: aprobado.
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build .`: compilación de prueba aprobada.
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet ./motorupdate ./releaseupdate`: aprobado.

No se ha ejecutado una actualización real del motor DNS ni una prueba con el watchdog de Windows durante un cambio de versión. El flujo automático de actualización del motor sigue **pendiente**.

## Próximos criterios de aceptación

1. Identificar de manera verificable el motor 0270 actualmente instalado, tarea SYSTEM y hash del binario antes del cambio. No inferir versión solo por el nombre del archivo.
2. Implementar controlador Windows que preserve exactamente los respaldos DNS, la configuración de adaptadores, el script de emergencia y el watchdog actual.
3. Crear binario nuevo versionado **sin sobrescribir** el ejecutable activo.
4. Cambiar la tarea SYSTEM de forma transaccional, detectar fallo de motor y revertir a la versión anterior, incluso con reinicio.
5. Probar fallas simuladas, corte del servicio, bloqueo DNS IPv4/IPv6 y conectividad general, usando una máquina Windows aislada.
6. Firmar y publicar un paquete de motor con una clave privada **fuera del repositorio**. No publicar `motor-stable.json` hasta pasar la integración.
7. Distribuir primero como piloto y solo después habilitar el botón de instalación en el Centro. La actualización del Centro 0.28.6 sigue intacta.

Importante: la firma Ed25519 verifica paquetes del canal del motor, no sustituye la firma Authenticode de Windows.
