//go:build windows

package main

import (
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"
	"volve-browser-protection/releaseupdate"
)

const stableManifestURL = "https://raw.githubusercontent.com/apdocentepba-hub/volve-updates/main/releases/stable.json"
const updaterPublicKey = "6pa2qoWNv+J7u0ulDXvqlBd7qEeDzPBdxmU6NpqTGHk="

func checkAndStageUpdate() (string, error) {
	public, e := base64.StdEncoding.DecodeString(updaterPublicKey)
	if e != nil {
		return "", e
	}
	ctx, cancel := context.WithTimeout(context.Background(), 115*time.Second)
	defer cancel()
	m, p, s, e := releaseupdate.FetchSigned(ctx, releaseupdate.DefaultClient(), stableManifestURL, ed25519.PublicKey(public))
	if e != nil {
		if errors.Is(e, releaseupdate.ErrNotPublished) {
			return "VOLVÉ " + version + "\n\nTodavía no hay una nueva versión publicada en el canal oficial.\n\n" +
				"Tu protección actual sigue funcionando. No se descargó ni instaló ningún programa.\n" +
				"El canal firmado se habilitará cuando publiquemos una actualización verificada.", nil
		}
		return "NO SE PUDO COMPROBAR LA ACTUALIZACIÓN\n\n" +
			"La conexión o el canal firmado no pudieron verificarse. No se descargó ni ejecutó nada.\n\nDetalle técnico: " + e.Error(), nil
	}
	cmp, e := releaseupdate.CompareVersions(version, m.Version)
	if e != nil {
		return "", e
	}
	if cmp >= 0 {
		return fmt.Sprintf("VOLVÉ %s está al día según el canal firmado (última publicada: %s).\nNo se modificó la protección.", version, m.Version), nil
	}
	cache, e := os.UserCacheDir()
	if e != nil {
		return "", e
	}
	target, e := releaseupdate.Stage(ctx, releaseupdate.DefaultClient(), m, p, s, ed25519.PublicKey(public), filepath.Join(cache, "VOLVE", "updates"))
	if e != nil {
		return "ACTUALIZACIÓN RECHAZADA: " + e.Error() + "\nNo se cambió el equipo.", nil
	}
	return "ACTUALIZACIÓN DESCARGADA Y VERIFICADA.\nVersión actual: " + version + " | Nueva: " + m.Version + "\n\n" +
		"Instalador preparado: " + target + "\n\nLa firma Ed25519 del manifiesto y el SHA-256 del EXE coinciden.\n" +
		"Desde el Centro de protección podés instalar el panel con permiso administrativo.\n" +
		"NO modifica el motor DNS automáticamente.\nNotas: " + strings.TrimSpace(m.Notes) + "\nVOLVE_STAGE_READY=" + target, nil
}
