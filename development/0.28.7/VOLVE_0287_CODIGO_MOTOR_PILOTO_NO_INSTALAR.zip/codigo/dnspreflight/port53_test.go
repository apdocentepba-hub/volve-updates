package dnspreflight

import (
	"os"
	"path/filepath"
	"testing"
)

// This test uses real loopback UDP and TCP port 53 if available in CI.
// If occupied by another process, it skips instead of harming other services.
func TestRealPort53IfAvailable(t *testing.T) {
	if ok, why := checkPort53(); !ok {
		t.Skipf("local resolver already uses port 53: %s", why)
	}
	base := t.TempDir()
	if e := os.Mkdir(filepath.Join(base, "feeds"), 0700); e != nil {
		t.Fatal(e)
	}
	if e := os.WriteFile(filepath.Join(base, "feeds", "hagezi_gambling_full.txt"), []byte("demo123.gambling-test.example\n"), 0600); e != nil {
		t.Fatal(e)
	}
	r, e := VerifyOnPort53(base, 1)
	if e != nil {
		t.Fatal(e)
	}
	if !r.Port53IPv4 || !r.IPv4 || !r.TCP {
		t.Fatalf("port53 not verified: %+v", r)
	}
	if ok, why := checkPort53(); !ok {
		t.Fatalf("port 53 not released: %s", why)
	}
}
