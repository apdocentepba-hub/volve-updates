package dnspreflight

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestVerifyRealDNSLoopback(t *testing.T) {
	base := t.TempDir()
	p := filepath.Join(base, "feeds")
	if e := os.Mkdir(p, 0700); e != nil {
		t.Fatal(e)
	}
	data := "alpha.gambling-test.example\nbeta.gambling-test.example\n"
	if e := os.WriteFile(filepath.Join(p, "hagezi_gambling_full.txt"), []byte(data), 0600); e != nil {
		t.Fatal(e)
	}
	r, e := Verify(base, 2)
	if e != nil {
		t.Fatal(e)
	}
	if r.FullDomains != 2 || !r.IPv4 || !r.TCP || !strings.Contains(r.String(), "APROBADA") {
		t.Fatalf("not verified: %+v", r)
	}
}
func TestRejectMissingAndPartialFull(t *testing.T) {
	base := t.TempDir()
	if _, e := Verify(base, 400000); e == nil {
		t.Fatal("missing feed accepted")
	}
	if e := os.Mkdir(filepath.Join(base, "feeds"), 0700); e != nil {
		t.Fatal(e)
	}
	if e := os.WriteFile(filepath.Join(base, "feeds", "hagezi_gambling_full.txt"), []byte("one.example.com\n"), 0600); e != nil {
		t.Fatal(e)
	}
	if _, e := Verify(base, 400000); e == nil {
		t.Fatal("small feed accepted")
	}
}

// Exercises the actual production threshold and DNS sockets, not a count-only mock.
func TestLargeFeedAtProductionThreshold(t *testing.T) {
	if testing.Short() {
		t.Skip("large feed")
	}
	base := t.TempDir()
	folder := filepath.Join(base, "feeds")
	if e := os.Mkdir(folder, 0700); e != nil {
		t.Fatal(e)
	}
	f, e := os.Create(filepath.Join(folder, "hagezi_gambling_full.txt"))
	if e != nil {
		t.Fatal(e)
	}
	b := bufio.NewWriterSize(f, 1<<20)
	for i := 0; i < 400100; i++ {
		fmt.Fprintf(b, "site%d.gambling-example.test\n", i)
	}
	if e := b.Flush(); e != nil {
		t.Fatal(e)
	}
	if e := f.Close(); e != nil {
		t.Fatal(e)
	}
	r, e := Verify(base, 400000)
	if e != nil {
		t.Fatal(e)
	}
	if r.FullDomains != 400100 || r.TotalRules < 400000 || !r.IPv4 || !r.TCP {
		t.Fatalf("incorrect large catalog test %+v", r)
	}
}
