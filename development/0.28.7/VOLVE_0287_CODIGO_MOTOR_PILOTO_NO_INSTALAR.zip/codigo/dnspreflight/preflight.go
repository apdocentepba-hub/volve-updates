package dnspreflight

// Offline end-to-end DNS preflight. It uses real cached feed data, but only
// ephemeral loopback listeners and a synthetic upstream (never network adapters).
// This is NOT Windows DNS activation and must not be presented as such.
import (
	"context"
	"encoding/binary"
	"fmt"
	"io"
	"net"
	"os"
	"path/filepath"
	"strings"
	"time"

	"volve-browser-protection/blocker"
	"volve-browser-protection/dnsproxy"
)

type Result struct {
	FullDomains   int
	TotalRules    int
	BlockedHost   string
	IPv4          bool
	IPv6          bool
	TCP           bool
	Port53IPv4    bool
	Port53Warning string
	IPv6Warning   string
}

func (r Result) String() string {
	text := fmt.Sprintf("PRUEBA DNS LOCAL: APROBADA\nHaGeZi Full leído del disco: %d dominios\nReglas reales cargadas en motor: %d\nBloqueo NXDOMAIN de %s: OK\nDominio permitido y respuesta DNS por UDP IPv4: OK\nConsulta bloqueada por TCP IPv4: OK\n", r.FullDomains, r.TotalRules, r.BlockedHost)
	if r.Port53IPv4 {
		text += "Puerto 53 local IPv4: disponible al momento de la prueba (no reservado).\n"
	} else {
		text += "Puerto 53 local IPv4: no disponible: " + r.Port53Warning + "\n"
	}
	if r.IPv6 {
		text += "UDP IPv6 (::1) bloqueado y permitido: OK\n"
	} else {
		text += "IPv6 no comprobado: " + r.IPv6Warning + "\n"
	}
	return text + "\nIMPORTANTE: prueba temporal en loopback. NO se cambió DNS de Windows.\nNO demuestra bloqueo en navegadores, VPN ni otras aplicaciones."
}

var feedNames = []string{"hagezi_gambling_full", "hagezi_gambling_medium", "stevenblack_gambling", "arkynx_gambling"}

func readFeed(path string, max int) ([]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	return blocker.Parse(io.LimitReader(f, 60<<20), max)
}

func Verify(base string, minFull int) (Result, error) {
	return verifyAtPort(base, minFull, 0)
}

// VerifyOnPort53 starts the SAME complete real DNS engine on loopback port 53
// ONLY for the duration of the test. It neither changes an OS resolver setting
// nor owns port 53 persistently. It refuses to displace existing listeners.
func VerifyOnPort53(base string, minFull int) (Result, error) {
	return verifyAtPort(base, minFull, 53)
}

func verifyAtPort(base string, minFull int, forcedPort int) (Result, error) {
	var r Result
	if minFull < 1 || minFull > 950000 {
		return r, fmt.Errorf("invalid minimum")
	}
	// Require the REAL full feed, not a possibly stale status counter.
	fullPath := filepath.Join(base, "feeds", "hagezi_gambling_full.txt")
	full, err := readFeed(fullPath, 950000)
	if err != nil {
		return r, fmt.Errorf("falta archivo HaGeZi Full válido: %w", err)
	}
	r.FullDomains = len(full)
	if len(full) < minFull {
		return r, fmt.Errorf("HaGeZi Full incompleto en disco: %d; mínimo requerido: %d", len(full), minFull)
	}
	data := append([]string(nil), full...)
	for _, name := range feedNames[1:] {
		path := filepath.Join(base, "feeds", name+".txt")
		other, e := readFeed(path, 950000)
		if e == nil {
			data = append(data, other...)
		}
	}
	data = append(data, "bet.ar", "stake.com")
	engine := blocker.New(data, true)
	r.TotalRules = engine.Len()
	for _, s := range full {
		if yes, _ := engine.Match(s); yes && s != "stake.com" && !strings.HasSuffix(s, "bet.ar") {
			r.BlockedHost = s
			break
		}
	}
	if r.BlockedHost == "" {
		return r, fmt.Errorf("no se halló un dominio de la lista Full que el motor bloquee")
	}
	// Synthetic upstream is bound to loopback, so even "allowed" DNS requests
	// are not sent to Internet. The A answer is an RFC 5737 TEST-NET address.
	upstream, err := net.ListenPacket("udp4", "127.0.0.1:0")
	if err != nil {
		return r, fmt.Errorf("upstream de prueba: %w", err)
	}
	defer upstream.Close()
	go func() {
		buf := make([]byte, 4096)
		for {
			n, peer, e := upstream.ReadFrom(buf)
			if e != nil {
				return
			}
			if n < 18 {
				continue
			}
			q := append([]byte(nil), buf[:n]...)
			// A valid synthetic success response with one answer.
			q[2], q[3] = 0x81, 0x80
			binary.BigEndian.PutUint16(q[6:8], 1)
			binary.BigEndian.PutUint16(q[8:10], 0)
			binary.BigEndian.PutUint16(q[10:12], 0)
			q = append(q, 0xc0, 0x0c, 0, 1, 0, 1, 0, 0, 0, 60, 0, 4, 203, 0, 113, 7)
			_, _ = upstream.WriteTo(q, peer)
		}
	}()
	// Probe each listener on temporary ports. Port 53 is deliberately NOT used.
	if err := probeOneAt("127.0.0.1", engine, upstream.LocalAddr().String(), r.BlockedHost, true, forcedPort); err != nil {
		return r, err
	}
	r.IPv4 = true
	r.TCP = true
	if forcedPort == 53 {
		r.Port53IPv4 = true
	} else {
		r.Port53IPv4, r.Port53Warning = checkPort53()
	}
	if err := probeOneAt("::1", engine, upstream.LocalAddr().String(), r.BlockedHost, false, forcedPort); err == nil {
		r.IPv6 = true
	} else {
		r.IPv6Warning = err.Error()
	}
	// This is a temporary test motor; verify no orphan listener remains.
	// Never claim the local DNS port was restored solely from context cancel.
	if forcedPort == 53 {
		if free, reason := checkPort53(); !free {
			return r, fmt.Errorf("el puerto 53 no se liberó al cerrar la prueba: %s", reason)
		}
	}
	return r, nil
}

// Port-53 readiness checks bind only to loopback and immediately release. They
// neither terminate another DNS process nor change network configuration.
func checkPort53() (bool, string) {
	udp, err := net.ListenPacket("udp4", "127.0.0.1:53")
	if err != nil {
		return false, "UDP: " + err.Error()
	}
	defer udp.Close()
	tcp, err := net.Listen("tcp4", "127.0.0.1:53")
	if err != nil {
		return false, "TCP: " + err.Error()
	}
	defer tcp.Close()
	return true, ""
}

func makeQuestion(host string) []byte {
	q := []byte{0x41, 0x56, 0x01, 0x00, 0, 1, 0, 0, 0, 0, 0, 0}
	for _, p := range strings.Split(host, ".") {
		q = append(q, byte(len(p)))
		q = append(q, []byte(p)...)
	}
	return append(q, 0, 0, 1, 0, 1)
}

func testTCP(addr, host string) error {
	c, e := net.DialTimeout("tcp", addr, 2*time.Second)
	if e != nil {
		return e
	}
	defer c.Close()
	_ = c.SetDeadline(time.Now().Add(3 * time.Second))
	q := makeQuestion(host)
	packet := make([]byte, len(q)+2)
	binary.BigEndian.PutUint16(packet[:2], uint16(len(q)))
	copy(packet[2:], q)
	if _, e = c.Write(packet); e != nil {
		return e
	}
	if _, e = io.ReadFull(c, packet[:2]); e != nil {
		return e
	}
	size := int(binary.BigEndian.Uint16(packet[:2]))
	if size < 12 || size > 4096 {
		return fmt.Errorf("respuesta TCP invalida: %d", size)
	}
	b := make([]byte, size)
	if _, e = io.ReadFull(c, b); e != nil {
		return e
	}
	if b[0] != q[0] || b[1] != q[1] || b[3]&15 != 3 {
		return fmt.Errorf("motor no bloqueó por TCP (rcode=%d)", b[3]&15)
	}
	return nil
}

func probeOne(host string, rules *blocker.Engine, upstream, blocked string, testTCP4 bool) error {
	return probeOneAt(host, rules, upstream, blocked, testTCP4, 0)
}

func probeOneAt(host string, rules *blocker.Engine, upstream, blocked string, testTCP4 bool, forcedPort int) error {
	probe, err := net.ListenPacket("udp", net.JoinHostPort(host, "0"))
	if err != nil {
		return fmt.Errorf("listener %s: %w", host, err)
	}
	port := probe.LocalAddr().(*net.UDPAddr).Port
	probe.Close()
	if forcedPort != 0 {
		port = forcedPort
	}
	ctx, cancel := context.WithCancel(context.Background())
	server := dnsproxy.New(rules, []string{upstream})
	done := make(chan error, 1)
	go func() { done <- server.Run(ctx, host, port) }()
	select {
	case <-server.Ready():
	case e := <-done:
		cancel()
		return fmt.Errorf("DNS %s no inició: %v", host, e)
	case <-time.After(3 * time.Second):
		cancel()
		return fmt.Errorf("DNS %s demoró al iniciar", host)
	}
	address := net.JoinHostPort(host, fmt.Sprint(port))
	err = dnsproxy.Probe(address, blocked, "example.org")
	if err == nil && testTCP4 {
		err = testTCP(address, blocked)
	}
	cancel()
	select {
	case stopErr := <-done:
		if err == nil && stopErr != nil {
			err = stopErr
		}
	case <-time.After(3 * time.Second):
		if err == nil {
			err = fmt.Errorf("DNS %s no cerró limpiamente", host)
		}
	}
	if err != nil {
		return fmt.Errorf("prueba loopback %s: %w", host, err)
	}
	return nil
}
