//go:build windows

package main

import (
	"context"
	"fmt"
	"math/rand"
	"strings"
	"sync"
	"time"
	"volve-browser-protection/dnsproxy"
)

// sampleLiveDNS queries 100 names selected from the ACTIVE blocked-domain
// engine, not a static curated list. It only uses loopback; no browser opens.
func sampleLiveDNS() (string, error) {
	eng, err := fullEngine()
	if err != nil {
		return "", fmt.Errorf("no se pudo abrir la lista Full instalada: %w", err)
	}
	list := eng.Sorted()
	if len(list) < 400000 {
		return "", fmt.Errorf("catálogo pequeño: %d", len(list))
	}
	const total = 100
	selection := rand.New(rand.NewSource(time.Now().UnixNano())).Perm(len(list))[:total]
	ctx, cancel := context.WithTimeout(context.Background(), 40*time.Second)
	defer cancel()
	type job struct{ domain, server string }
	type record struct {
		domain string
		rcode  byte
		err    error
	}
	queue := make(chan job)
	results := make(chan record, total)
	var wg sync.WaitGroup
	for i := 0; i < 12; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := range queue {
				r, e := dnsproxy.QueryRCode(ctx, j.server, j.domain)
				results <- record{domain: j.domain, rcode: r, err: e}
			}
		}()
	}
	go func() {
		for i, pos := range selection {
			target := "127.0.0.1:53"
			if i%2 == 1 {
				target = "[::1]:53"
			}
			queue <- job{list[pos], target}
		}
		close(queue)
		wg.Wait()
		close(results)
	}()
	ok, failures := 0, 0
	var samples []string
	for result := range results {
		if result.err == nil && result.rcode == 3 {
			ok++
		} else {
			failures++
			if len(samples) < 8 {
				if result.err != nil {
					samples = append(samples, result.domain+": sin respuesta válida")
				} else {
					samples = append(samples, fmt.Sprintf("%s: rcode=%d", result.domain, result.rcode))
				}
			}
		}
	}
	var b strings.Builder
	fmt.Fprintf(&b, "VOLVÉ — PRUEBA EN VIVO (DNS LOCAL)\nMotor: muestra de %d entre %d dominios bloqueados.\nConsultas: 50 por IPv4 y 50 por IPv6.\nRespuestas NXDOMAIN: %d / 100\nSin respuesta NXDOMAIN: %d\n", total, len(list), ok, failures)
	if len(samples) > 0 {
		fmt.Fprintln(&b, "Algunos fallos:")
		for _, v := range samples {
			fmt.Fprintln(&b, " •", v)
		}
	}
	b.WriteString("\nNOTA: NXDOMAIN es compatible con bloqueo, pero también puede corresponder a dominios inexistentes. No implica resistencia a VPN o DNS alternativo.\n")
	if ctx.Err() != nil {
		return b.String(), fmt.Errorf("la prueba excedió 40 segundos: %w", ctx.Err())
	}
	if failures > 0 {
		return b.String(), fmt.Errorf("%d consultas no devolvieron NXDOMAIN", failures)
	}
	return b.String(), nil
}
