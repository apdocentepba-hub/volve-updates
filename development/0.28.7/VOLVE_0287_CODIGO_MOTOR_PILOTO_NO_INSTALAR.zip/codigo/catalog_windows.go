//go:build windows

package main

import (
	"crypto/sha256"
	"embed"
	"encoding/hex"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

//go:embed assets/VOLVE_Motor_0210.exe
var embeddedMotor embed.FS

const catalogTaskLegacy = "VOLVE-CATALOGO-0210"
const catalogTaskNew = "VOLVE-CATALOGO-0230"
const motorName = "VOLVE_Motor_0210.exe"

func motorLocation() (string, error) {
	s, e := statePath()
	if e != nil {
		return "", e
	}
	return filepath.Join(filepath.Dir(s), motorName), nil
}

// Query a specific task. Preserve existing tasks whose ownership is unclear.
func taskQuery(name string) ([]byte, bool, error) {
	c := hiddenCommand("schtasks.exe", "/Query", "/TN", name, "/XML")
	b, e := c.CombinedOutput()
	if e == nil {
		return b, true, nil
	}
	// Preserve the previous conservative behavior for missing-task detection.
	q := hiddenCommand("schtasks.exe", "/Query", "/TN", name)
	data, qe := q.CombinedOutput()
	if qe != nil {
		if taskMissingText(string(data)) {
			return nil, false, nil
		}
		return nil, false, fmt.Errorf("no puedo comprobar si existe %s: %s: %w", name, strings.TrimSpace(string(data)), qe)
	}
	return nil, false, fmt.Errorf("no pude leer XML de la tarea %s: %s: %w", name, strings.TrimSpace(string(b)), e)
}
func taskMissingText(s string) bool {
	s = strings.ToLower(s)
	for _, part := range []string{"cannot find", "cannot locate", "not found", "does not exist", "unable to find", "no se encuentra", "no existe", "no ha podido encontrar", "no puede encontrar", "no se encontró", "el sistema no puede encontrar"} {
		if strings.Contains(s, part) {
			return true
		}
	}
	return false
}
func verifyCatalogTask(xml []byte, exe string) error { return verifyTaskXML(xml, exe) }

// If a legacy task cannot be proven to belong to this installation, leave it
// completely alone and create a separately named VOLVÉ 0.23 task instead.
// Never replace a foreign task with /F.
func chooseCatalogTask(exe string) (name string, exists bool, err error) {
	fresh, yes, e := taskQuery(catalogTaskNew)
	if e != nil {
		return "", false, e
	}
	if yes {
		if e = verifyCatalogTask(fresh, exe); e != nil {
			return "", false, fmt.Errorf("la tarea propia %s existe pero no coincide: %w", catalogTaskNew, e)
		}
		return catalogTaskNew, true, nil
	}
	prior, oldYes, e := taskQuery(catalogTaskLegacy)
	if e != nil {
		return "", false, e
	}
	if oldYes && verifyCatalogTask(prior, exe) == nil {
		return catalogTaskLegacy, true, nil
	}
	// Unknown/foreign legacy task is untouched.
	return catalogTaskNew, false, nil
}
func installCatalogMotor() error {
	exe, e := motorLocation()
	if e != nil {
		return e
	}
	raw, e := embeddedMotor.ReadFile("assets/" + motorName)
	if e != nil {
		return e
	}
	dir := filepath.Dir(exe)
	if e = os.MkdirAll(dir, 0700); e != nil {
		return e
	}
	task, exists, e := chooseCatalogTask(exe)
	if e != nil {
		return e
	}
	old, e := os.ReadFile(exe)
	if e == nil && sha256.Sum256(old) != sha256.Sum256(raw) {
		return errors.New("motor anterior distinto: no sustituir binario asociado a tareas activas; necesita migración supervisada")
	} else if e != nil && !errors.Is(e, os.ErrNotExist) {
		return e
	}
	if errors.Is(e, os.ErrNotExist) {
		f, er := os.CreateTemp(dir, ".volve-motor-*.tmp")
		if er != nil {
			return er
		}
		tmp := f.Name()
		defer os.Remove(tmp)
		if _, er = f.Write(raw); er != nil {
			f.Close()
			return er
		}
		if er = f.Sync(); er != nil {
			f.Close()
			return er
		}
		if er = f.Close(); er != nil {
			return er
		}
		if er = os.Rename(tmp, exe); er != nil {
			return er
		}
	}
	check, e := os.ReadFile(exe)
	if e != nil {
		return e
	}
	if sha256.Sum256(check) != sha256.Sum256(raw) {
		return errors.New("motor corrupto al verificar")
	}
	if !exists {
		action := strconv.Quote(exe) + " --refresh"
		cmd := hiddenCommand("schtasks.exe", "/Create", "/TN", task, "/SC", "HOURLY", "/MO", "1", "/RU", "SYSTEM", "/RL", "HIGHEST", "/TR", action)
		if out, er := cmd.CombinedOutput(); er != nil {
			return fmt.Errorf("no pude crear tarea %s: %s: %w", task, strings.TrimSpace(string(out)), er)
		}
	}
	xml, yes, e := taskQuery(task)
	if e != nil {
		return e
	}
	if !yes {
		return errors.New("Windows no registró la tarea de catálogo")
	}
	if e = verifyCatalogTask(xml, exe); e != nil {
		return fmt.Errorf("la tarea programada no superó verificación: %w", e)
	}
	if out, er := hiddenCommand("schtasks.exe", "/Run", "/TN", task).CombinedOutput(); er != nil {
		// Do not report successful refresh if scheduler refused to start it.
		return fmt.Errorf("tarea creada pero no pudo iniciarse: %s (%w)", strings.TrimSpace(string(out)), er)
	}
	return nil
}
func removeCatalogMotor() error {
	exe, e := motorLocation()
	if e != nil {
		return e
	}
	// Never delete any task whose XML does not match our expected signed intent.
	for _, task := range []string{catalogTaskNew, catalogTaskLegacy} {
		xml, exists, er := taskQuery(task)
		if er != nil {
			return er
		}
		if !exists || verifyCatalogTask(xml, exe) != nil {
			continue
		}
		cmd := hiddenCommand("schtasks.exe", "/Delete", "/TN", task, "/F")
		if out, er := cmd.CombinedOutput(); er != nil {
			return fmt.Errorf("no pude retirar tarea %s: %s: %w", task, string(out), er)
		}
	}
	// If a task of unknown ownership still references a binary with this path,
	// leaving the binary in place is safer than orphaning that task.
	xml, yes, e := taskQuery(catalogTaskLegacy)
	if e != nil {
		return e
	}
	if yes && verifyCatalogTask(xml, exe) != nil {
		return errors.New("permanece una tarea heredada no reconocida; no se elimina el ejecutable del motor")
	}
	if _, e = os.Stat(exe); e == nil {
		return os.Remove(exe)
	} else if errors.Is(e, os.ErrNotExist) {
		return nil
	} else {
		return e
	}
}
func catalogTaskStatusText() string {
	// Consulta desde la GUI sin elevar: schtasks puede rechazar una tarea SYSTEM
	// aunque esté correctamente instalada. No presentar ese permiso como fallo.
	if !isAdmin() {
		return "Tarea horaria: no verificable sin administrador. Elegí NO para diagnóstico elevado.\n"
	}
	exe, e := motorLocation()
	if e != nil {
		return "Tarea del catálogo: no comprobable.\n"
	}
	n, yes, e := chooseCatalogTask(exe)
	if e != nil {
		return "Tarea del catálogo: ERROR: " + e.Error() + "\n"
	}
	if yes {
		return "Actualización horaria: tarea " + n + " verificada.\n"
	}
	return "Actualización horaria: ninguna tarea propia reconocida.\n"
}
func catalogStatusText() string {
	p, e := statePath()
	if e != nil {
		return "Catálogo masivo: ubicación no disponible.\n"
	}
	b, e := os.ReadFile(filepath.Join(filepath.Dir(p), "catalog", "estado.json"))
	if e != nil {
		return "Catálogo masivo: sin informe de descarga. NO comprobado.\n"
	}
	return formatCatalogReport(b)
}
func embeddedMotorSHA() string {
	b, e := embeddedMotor.ReadFile("assets/" + motorName)
	if e != nil {
		return ""
	}
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:])
}
