package main

import (
	"errors"
	"strings"
	"testing"
)

func TestParseHealthMarker(t *testing.T) {
	tests := []struct {
		name     string
		out, err []byte
		cmdErr   error
		ok       bool
	}{
		{"ok", []byte("VOLVE_DNS_ADAPTER_OK\r\n"), nil, nil, true},
		{"mismatch", []byte("VOLVE_DNS_ADAPTER_MISMATCH\n"), nil, nil, true},
		{"missing", []byte("VOLVE_DNS_ADAPTER_NOT_FOUND"), nil, nil, true},
		{"bom", append([]byte{0xef, 0xbb, 0xbf}, []byte("VOLVE_DNS_ADAPTER_OK\n")...), nil, nil, true},
		{"utf16", []byte{0xff, 0xfe, 'V', 0, 'O', 0, 'L', 0, 'V', 0, 'E', 0, '_', 0, 'D', 0, 'N', 0, 'S', 0, '_', 0, 'A', 0, 'D', 0, 'A', 0, 'P', 0, 'T', 0, 'E', 0, 'R', 0, '_', 0, 'O', 0, 'K', 0}, nil, nil, true},
		{"stray_stdout", []byte("warning\nVOLVE_DNS_ADAPTER_OK"), nil, nil, false},
		{"stderr_clixml", []byte("VOLVE_DNS_ADAPTER_OK"), []byte("#< CLIXML"), nil, false},
		{"error", []byte("VOLVE_DNS_ADAPTER_OK"), nil, errors.New("exit status 8"), false},
		{"blank", nil, nil, nil, false},
		{"invalid", []byte{0xff}, nil, nil, false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s, e := parseHealthMarker(tt.out, tt.err, tt.cmdErr)
			if (e == nil) != tt.ok {
				t.Fatalf("status=%q error=%v", s, e)
			}
		})
	}
}
func TestPowerShellProgressOnly(t *testing.T) {
	valid := []byte(`#< CLIXML
<Objs Version="1.1.0.1" xmlns="http://schemas.microsoft.com/powershell/2004/04"><Obj S="progress" RefId="0"><MS><I64 N="SourceId">1</I64><PR N="Record"><AV>Preparing modules</AV></PR></MS></Obj></Objs>`)
	if !onlyPowerShellProgress(valid) {
		t.Fatal("harmless progress must be recognizable")
	}
	if _, err := parseHealthMarker([]byte("VOLVE_DNS_ADAPTER_OK"), valid, nil); err != nil {
		t.Fatal(err)
	}
	for _, v := range []string{
		`#< CLIXML
<Objs><Obj S="error"><S>Critical</S></Obj></Objs>`,
		`#< CLIXML
<Objs><S S="Error">critical</S></Objs>`,
		`warning`,
		`#< CLIXML
<Objs><Obj S="progress"></Obj></Objs> trailing`,
	} {
		v = strings.ReplaceAll(v, `\n`, "\n")
		if onlyPowerShellProgress([]byte(v)) {
			t.Fatalf("accepted nonprogress stderr: %q", v)
		}
	}
}

func TestExplainTaskReason(t *testing.T) {
	for _, s := range []string{"argumentos distintos", "otro ejecutable", "no pertenece a SYSTEM", "acciones ajenas"} {
		if v := explainTaskReason(errors.New(s)); v == "" || strings.Contains(v, "NO VERIFICABLE") {
			t.Fatalf("bad reason %q", v)
		}
	}
}
