package releaseupdate

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"testing"
)

func TestSignedUpdateEndToEndWithoutExecutingFile(t *testing.T) {
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	app := []byte("MZ: sample binary content for unit test only")
	sum := sha256.Sum256(app)
	m := Manifest{Schema: 1, Version: "0.28.4", Published: "2026-10-29T00:00:00Z", Notes: "Panel only", URL: "https://github.com/apdocentepba-hub/volve-updates/releases/download/v0.28.4/VOLVE.exe", SHA256: hex.EncodeToString(sum[:]), Size: int64(len(app))}
	body, err := json.Marshal(m)
	if err != nil {
		t.Fatal(err)
	}
	signature := []byte(base64.StdEncoding.EncodeToString(ed25519.Sign(priv, body)))
	const channel = "https://raw.githubusercontent.com/apdocentepba-hub/volve-updates/main/releases/stable.json"
	client := &http.Client{Transport: roundTripFunc(func(r *http.Request) (*http.Response, error) {
		var data []byte
		switch r.URL.String() {
		case channel:
			data = body
		case channel + ".sig":
			data = signature
		case m.URL:
			data = app
		default:
			return nil, fmt.Errorf("unexpected URL: %s", r.URL)
		}
		return &http.Response{StatusCode: 200, ContentLength: int64(len(data)), Header: http.Header{}, Body: io.NopCloser(strings.NewReader(string(data))), Request: r}, nil
	})}
	verified, p, s, err := FetchSigned(context.Background(), client, channel, pub)
	if err != nil {
		t.Fatal(err)
	}
	if verified.Version != "0.28.4" {
		t.Fatal("wrong version")
	}
	path, err := Stage(context.Background(), client, verified, p, s, pub, t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	got, err := VerifyStaged(path, pub)
	if err != nil {
		t.Fatal(err)
	}
	if got != m {
		t.Fatal("re-read manifest differs")
	}
}
