package releaseupdate

import (
	"context"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// Signed Manifest V1. The signature authenticates the EXACT downloaded bytes,
// before parsing JSON. The key must be embedded in the client, never fetched
// alongside the untrusted payload. No fallback to unsigned releases.
type Manifest struct {
	Schema    int    `json:"schema"`
	Version   string `json:"version"`
	Published string `json:"published"`
	Notes     string `json:"notes"`
	URL       string `json:"url"`
	SHA256    string `json:"sha256"`
	Size      int64  `json:"size"`
}

var ErrNotPublished = errors.New("canal de versiones todavía no publicado")

const MaxExeBytes int64 = 200 << 20
const MaxManifestBytes int64 = 16 << 10

var versionRe = regexp.MustCompile(`^\d+\.\d+\.\d+$`)

func CompareVersions(a, b string) (int, error) {
	if !versionRe.MatchString(a) || !versionRe.MatchString(b) {
		return 0, errors.New("versión inválida")
	}
	aa := strings.Split(a, ".")
	bb := strings.Split(b, ".")
	for i := 0; i < 3; i++ {
		a1, e := strconv.ParseUint(aa[i], 10, 32)
		if e != nil {
			return 0, e
		}
		b1, e := strconv.ParseUint(bb[i], 10, 32)
		if e != nil {
			return 0, e
		}
		if a1 < b1 {
			return -1, nil
		}
		if a1 > b1 {
			return 1, nil
		}
	}
	return 0, nil
}
func VerifyManifest(payload, signature []byte, public ed25519.PublicKey) (Manifest, error) {
	var m Manifest
	if len(public) != ed25519.PublicKeySize || len(payload) == 0 || len(payload) > int(MaxManifestBytes) {
		return m, errors.New("manifiesto/clave inválidos")
	}
	sig, e := base64.StdEncoding.DecodeString(strings.TrimSpace(string(signature)))
	if e != nil || !ed25519.Verify(public, payload, sig) {
		return m, errors.New("firma de la actualización inválida")
	}
	dec := json.NewDecoder(strings.NewReader(string(payload)))
	dec.DisallowUnknownFields()
	if e = dec.Decode(&m); e != nil {
		return m, fmt.Errorf("JSON de actualización inválido: %w", e)
	}
	var trailing any
	if dec.Decode(&trailing) != io.EOF {
		return m, errors.New("datos sobrantes en manifiesto")
	}
	if m.Schema != 1 || !versionRe.MatchString(m.Version) || m.Size <= 0 || m.Size > MaxExeBytes || len(m.Notes) > 2000 || len(m.Published) > 60 {
		return m, errors.New("datos de manifiesto fuera de límites")
	}
	if len(m.SHA256) != 64 {
		return m, errors.New("huella SHA-256 ausente")
	}
	if _, e = hex.DecodeString(m.SHA256); e != nil {
		return m, errors.New("huella inválida")
	}
	u, e := url.Parse(m.URL)
	if e != nil {
		return m, e
	}
	if u.Scheme != "https" || u.Host != "github.com" || !strings.HasPrefix(u.EscapedPath(), "/apdocentepba-hub/volve-updates/releases/download/") || !strings.HasSuffix(strings.ToLower(u.Path), ".exe") || u.User != nil || u.Fragment != "" || u.RawQuery != "" {
		return m, errors.New("origen de actualización no autorizado")
	}
	return m, nil
}
func FetchSigned(ctx context.Context, httpClient *http.Client, manifestURL string, key ed25519.PublicKey) (Manifest, []byte, []byte, error) {
	var zero Manifest
	if manifestURL != "https://raw.githubusercontent.com/apdocentepba-hub/volve-updates/main/releases/stable.json" {
		return zero, nil, nil, errors.New("canal de actualización no autorizado")
	}
	fetch := func(uri string, cap int64) ([]byte, error) {
		req, e := http.NewRequestWithContext(ctx, "GET", uri, nil)
		if e != nil {
			return nil, e
		}
		resp, e := httpClient.Do(req)
		if e != nil {
			return nil, e
		}
		defer resp.Body.Close()
		if resp.StatusCode != 200 {
			if resp.StatusCode == http.StatusNotFound {
				return nil, ErrNotPublished
			}
			return nil, fmt.Errorf("HTTP %d en canal de actualizaciones", resp.StatusCode)
		}
		b, e := io.ReadAll(io.LimitReader(resp.Body, cap+1))
		if e != nil {
			return nil, e
		}
		if int64(len(b)) > cap {
			return nil, errors.New("respuesta excesiva")
		}
		return b, nil
	}
	data, e := fetch(manifestURL, MaxManifestBytes)
	if e != nil {
		return zero, nil, nil, e
	}
	sig, e := fetch(manifestURL+".sig", 4096)
	if e != nil {
		return zero, nil, nil, e
	}
	m, e := VerifyManifest(data, sig, key)
	return m, data, sig, e
}
func Stage(ctx context.Context, client *http.Client, m Manifest, payload, sig []byte, key ed25519.PublicKey, dir string) (string, error) {
	// Re-verify independently, including AFTER the file is downloaded.
	verified, e := VerifyManifest(payload, sig, key)
	if e != nil || verified != m {
		return "", errors.New("manifiesto cambió o perdió la firma")
	}
	if e = os.MkdirAll(dir, 0700); e != nil {
		return "", e
	}
	request, e := http.NewRequestWithContext(ctx, "GET", m.URL, nil)
	if e != nil {
		return "", e
	}
	resp, e := client.Do(request)
	if e != nil {
		return "", e
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return "", fmt.Errorf("HTTP %d descargando instalador", resp.StatusCode)
	}
	if resp.ContentLength > m.Size {
		return "", errors.New("tamaño del binario no coincide")
	}
	f, e := os.CreateTemp(dir, ".volve-update-*.exe")
	if e != nil {
		return "", e
	}
	defer os.Remove(f.Name())
	h := sha256.New()
	n, e := io.Copy(io.MultiWriter(f, h), io.LimitReader(resp.Body, m.Size+1))
	if e != nil {
		f.Close()
		return "", e
	}
	if n != m.Size || !strings.EqualFold(hex.EncodeToString(h.Sum(nil)), m.SHA256) {
		f.Close()
		return "", errors.New("descarga incompleta o SHA-256 incorrecto")
	}
	if e = f.Sync(); e != nil {
		f.Close()
		return "", e
	}
	if e = f.Close(); e != nil {
		return "", e
	}
	name := "VOLVE_Update_" + strings.ReplaceAll(m.Version, ".", "_") + ".exe"
	target := filepath.Join(dir, name)
	if e = os.Rename(f.Name(), target); e != nil {
		return "", e
	}
	if e = os.WriteFile(target+".json", payload, 0600); e != nil {
		return "", e
	}
	if e = os.WriteFile(target+".sig", sig, 0600); e != nil {
		return "", e
	}
	return target, nil
}
func DefaultClient() *http.Client {
	return &http.Client{Timeout: 90 * time.Second, CheckRedirect: func(req *http.Request, via []*http.Request) error {
		if len(via) > 5 || req.URL.Scheme != "https" {
			return errors.New("redirección no autorizada")
		}
		return nil
	}}
}
