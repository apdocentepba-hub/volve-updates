package releaseupdate

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"io"
	"net/http"
	"strings"
	"testing"
)

func TestVersion(t *testing.T) {
	for _, tt := range []struct {
		a, b string
		want int
	}{{"0.27.5", "0.28.0", -1}, {"0.28.0", "0.28.0", 0}, {"1.0.0", "0.99.99", 1}} {
		got, e := CompareVersions(tt.a, tt.b)
		if e != nil || got != tt.want {
			t.Fatal(got, e)
		}
	}
}
func TestSignedAndTampered(t *testing.T) {
	pub, priv, _ := ed25519.GenerateKey(rand.Reader)
	blob := []byte("secure-binary")
	sha := sha256.Sum256(blob)
	m := Manifest{Schema: 1, Version: "0.28.0", URL: "https://github.com/apdocentepba-hub/volve-updates/releases/download/v0.28.0/VOLVE.exe", SHA256: hex.EncodeToString(sha[:]), Size: int64(len(blob))}
	p, _ := json.Marshal(m)
	sig := []byte(base64.StdEncoding.EncodeToString(ed25519.Sign(priv, p)))
	if _, e := VerifyManifest(p, sig, pub); e != nil {
		t.Fatal(e)
	}
	p[10] ^= 1
	if _, e := VerifyManifest(p, sig, pub); e == nil {
		t.Fatal("tampering accepted")
	}
}
func TestWrongOrigin(t *testing.T) {
	pub, priv, _ := ed25519.GenerateKey(rand.Reader)
	m := Manifest{Schema: 1, Version: "1.0.0", URL: "https://evil.test/file.exe", SHA256: strings.Repeat("a", 64), Size: 123}
	p, _ := json.Marshal(m)
	sig := []byte(base64.StdEncoding.EncodeToString(ed25519.Sign(priv, p)))
	if _, e := VerifyManifest(p, sig, pub); e == nil {
		t.Fatal("bad origin accepted")
	}
}
func TestStageRejectsWrongHash(t *testing.T) {
	pub, priv, _ := ed25519.GenerateKey(rand.Reader)
	m := Manifest{Schema: 1, Version: "0.28.0", URL: "https://github.com/apdocentepba-hub/volve-updates/releases/download/v0.28.0/VOLVE.exe", SHA256: strings.Repeat("a", 64), Size: 5}
	p, _ := json.Marshal(m)
	sig := []byte(base64.StdEncoding.EncodeToString(ed25519.Sign(priv, p)))
	fake := roundTripFunc(func(r *http.Request) (*http.Response, error) {
		return &http.Response{StatusCode: 200, Header: make(http.Header), Body: io.NopCloser(strings.NewReader("wrong")), ContentLength: 5}, nil
	})
	client := &http.Client{Transport: fake}
	path, e := Stage(context.Background(), client, m, p, sig, pub, t.TempDir())
	if e == nil || path != "" {
		t.Fatal("accepted wrong SHA-256", path, e)
	}
}

type roundTripFunc func(*http.Request) (*http.Response, error)

func (f roundTripFunc) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }
