package releaseupdate

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func installedFile(t *testing.T, dir, version string) string {
	t.Helper()
	name := "VOLVE_Centro_Proteccion_" + strings.ReplaceAll(version, ".", "_") + ".exe"
	path := filepath.Join(dir, name)
	if err := os.WriteFile(path, []byte("MZ"), 0600); err != nil {
		t.Fatal(err)
	}
	return path
}
func TestNewestPanelPreventsStaleDowngrade(t *testing.T) {
	d := t.TempDir()
	installedFile(t, d, "0.27.5")
	installedFile(t, d, "0.28.5")
	highest, err := HighestInstalledPanel(d)
	if err != nil || highest != "0.28.5" {
		t.Fatalf("highest %q err %v", highest, err)
	}
	if err := EnsureNoInstalledDowngrade(d, "0.28.4"); err == nil {
		t.Fatal("stale panel must not downgrade")
	}
	if err := EnsureNoInstalledDowngrade(d, "0.28.5"); err != nil {
		t.Fatal(err)
	}
	if err := EnsureNoInstalledDowngrade(d, "0.28.6"); err != nil {
		t.Fatal(err)
	}
}
func TestUnrelatedFilesNotConsideredPanels(t *testing.T) {
	d := t.TempDir()
	for _, name := range []string{"VOLVE_DNS_Server.exe", "VOLVE_Centro_Proteccion_0_28_9.exe.bak", "other.exe"} {
		if err := os.WriteFile(filepath.Join(d, name), []byte("a"), 0600); err != nil {
			t.Fatal(err)
		}
	}
	version, err := HighestInstalledPanel(d)
	if err != nil || version != "" {
		t.Fatalf("unexpected: %q %v", version, err)
	}
}
func TestMisleadingPanelDirectoryRejected(t *testing.T) {
	d := t.TempDir()
	if err := os.Mkdir(filepath.Join(d, "VOLVE_Centro_Proteccion_0_99_0.exe"), 0700); err != nil {
		t.Fatal(err)
	}
	if _, err := HighestInstalledPanel(d); err == nil {
		t.Fatal("should reject non-file")
	}
}
func TestEmptyPanelRejected(t *testing.T) {
	d := t.TempDir()
	if err := os.WriteFile(filepath.Join(d, "VOLVE_Centro_Proteccion_0_28_8.exe"), nil, 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := HighestInstalledPanel(d); err == nil {
		t.Fatal("should reject empty")
	}
}
func TestUninstalledStateAndRelativePath(t *testing.T) {
	d := t.TempDir()
	if got, err := HighestInstalledPanel(d); err != nil || got != "" {
		t.Fatalf("%q %v", got, err)
	}
	if err := EnsureNoInstalledDowngrade(d, "0.28.5"); err != nil {
		t.Fatal(err)
	}
	if _, err := HighestInstalledPanel("relative"); err == nil {
		t.Fatal("relative path accepted")
	}
}
