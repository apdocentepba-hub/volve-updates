package releaseupdate

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
)

// VerifyStaged verifies the release's detached signature and the downloaded
// EXE's exact size and digest. It never executes a staged file.
func VerifyStaged(path string, public ed25519.PublicKey) (Manifest, error) {
	var empty Manifest
	if strings.ToLower(filepath.Ext(path)) != ".exe" {
		return empty, errors.New("archivo de actualización no es EXE")
	}
	manifestBytes, err := os.ReadFile(path + ".json")
	if err != nil {
		return empty, fmt.Errorf("no existe manifiesto de actualización: %w", err)
	}
	signature, err := os.ReadFile(path + ".sig")
	if err != nil {
		return empty, fmt.Errorf("no existe firma del manifiesto: %w", err)
	}
	m, err := VerifyManifest(manifestBytes, signature, public)
	if err != nil {
		return empty, err
	}
	if filepath.Base(path) != "VOLVE_Update_"+strings.ReplaceAll(m.Version, ".", "_")+".exe" {
		return empty, errors.New("nombre de instalador no coincide con la versión firmada")
	}
	f, err := os.Open(path)
	if err != nil {
		return empty, err
	}
	defer f.Close()
	stat, err := f.Stat()
	if err != nil {
		return empty, err
	}
	if !stat.Mode().IsRegular() || stat.Size() != m.Size {
		return empty, errors.New("tamaño del instalador no coincide")
	}
	h := sha256.New()
	n, err := io.Copy(h, io.LimitReader(f, m.Size+1))
	if err != nil {
		return empty, err
	}
	if n != m.Size || !strings.EqualFold(hex.EncodeToString(h.Sum(nil)), m.SHA256) {
		return empty, errors.New("SHA-256 no coincide con manifiesto firmado")
	}
	return m, nil
}
