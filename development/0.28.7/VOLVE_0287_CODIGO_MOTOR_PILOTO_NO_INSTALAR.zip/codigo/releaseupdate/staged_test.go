package releaseupdate

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

func TestVerifyStagedRejectsTampering(t *testing.T) {
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	exe := []byte("this is a test PE stub")
	sum := sha256.Sum256(exe)
	path := filepath.Join(t.TempDir(), "VOLVE_Update_0_28_4.exe")
	m := Manifest{Schema: 1, Version: "0.28.4", URL: "https://github.com/apdocentepba-hub/volve-updates/releases/download/v0.28.4/VOLVE.exe", SHA256: hex.EncodeToString(sum[:]), Size: int64(len(exe))}
	b, _ := json.Marshal(m)
	if err = os.WriteFile(path, exe, 0600); err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(path+".json", b, 0600); err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(path+".sig", []byte(base64.StdEncoding.EncodeToString(ed25519.Sign(priv, b))), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err = VerifyStaged(path, pub); err != nil {
		t.Fatal("valid package rejected", err)
	}
	if err = os.WriteFile(path, []byte("fake content"), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err = VerifyStaged(path, pub); err == nil {
		t.Fatal("tampering accepted")
	}
	if err = os.WriteFile(path, exe, 0600); err != nil {
		t.Fatal(err)
	}
	b[0] ^= 1
	if err = os.WriteFile(path+".json", b, 0600); err != nil {
		t.Fatal(err)
	}
	if _, err = VerifyStaged(path, pub); err == nil {
		t.Fatal("modified signed manifest accepted")
	}
}
