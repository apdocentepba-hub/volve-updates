package releaseupdate

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
)

// HighestInstalledPanel inspects only VOLVÉ's own versioned panel binaries.
// A stale panel must not redirect shortcuts to a release older than an
// already-installed one, even if the stale process considers it an upgrade.
// Symlinks and directories matching the managed naming convention are errors,
// not candidates for trust or silent replacement.
func HighestInstalledPanel(dir string) (string, error) {
	if !filepath.IsAbs(dir) {
		return "", errors.New("directorio de instalación no absoluto")
	}
	items, err := os.ReadDir(dir)
	if errors.Is(err, os.ErrNotExist) {
		return "", nil
	}
	if err != nil {
		return "", err
	}
	pattern := regexp.MustCompile(`^VOLVE_Centro_Proteccion_([0-9]+)_([0-9]+)_([0-9]+)\.exe$`)
	maxVersion := ""
	for _, item := range items {
		m := pattern.FindStringSubmatch(item.Name())
		if m == nil {
			continue
		}
		if !item.Type().IsRegular() {
			return "", fmt.Errorf("panel instalado no es archivo regular: %q", item.Name())
		}
		info, e := item.Info()
		if e != nil {
			return "", e
		}
		if info.Size() < 2 {
			return "", fmt.Errorf("panel instalado vacío: %q", item.Name())
		}
		v := strings.Join(m[1:], ".")
		// Comparisons are checked to avoid integer overflow and ambiguous names.
		if _, e = CompareVersions(v, "0.0.0"); e != nil {
			return "", fmt.Errorf("versión instalada inválida %q: %w", v, e)
		}
		if maxVersion == "" {
			maxVersion = v
			continue
		}
		cmp, e := CompareVersions(maxVersion, v)
		if e != nil {
			return "", e
		}
		if cmp < 0 {
			maxVersion = v
		}
	}
	return maxVersion, nil
}

// EnsureNoInstalledDowngrade rejects any candidate older than the newest
// installed version. Equal candidates may only be re-linked after the caller
// confirms that the signed hash matches the existing binary exactly.
func EnsureNoInstalledDowngrade(dir, candidate string) error {
	newest, err := HighestInstalledPanel(dir)
	if err != nil {
		return err
	}
	if newest == "" {
		return nil
	}
	cmp, err := CompareVersions(candidate, newest)
	if err != nil {
		return err
	}
	if cmp < 0 {
		return fmt.Errorf("versión %s rechazada: ya existe un panel %s más reciente", candidate, newest)
	}
	return nil
}
