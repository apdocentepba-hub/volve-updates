package releaseupdate

import (
	"context"
	"crypto/ed25519"
	"errors"
	"net/http"
	"testing"
)

type stubRoundTripper func(*http.Request) (*http.Response, error)

func (fn stubRoundTripper) RoundTrip(r *http.Request) (*http.Response, error) { return fn(r) }

func TestMissingReleaseChannelIsNotPublished(t *testing.T) {
	client := &http.Client{Transport: stubRoundTripper(func(r *http.Request) (*http.Response, error) {
		if r.URL.Scheme != "https" {
			t.Fatal("non HTTPS request")
		}
		return &http.Response{StatusCode: http.StatusNotFound, Body: http.NoBody, Header: http.Header{}, Request: r}, nil
	})}
	_, _, _, err := FetchSigned(context.Background(), client, "https://raw.githubusercontent.com/apdocentepba-hub/volve-updates/main/releases/stable.json", make(ed25519.PublicKey, 32))
	if !errors.Is(err, ErrNotPublished) {
		t.Fatalf("want ErrNotPublished, got %v", err)
	}
}
