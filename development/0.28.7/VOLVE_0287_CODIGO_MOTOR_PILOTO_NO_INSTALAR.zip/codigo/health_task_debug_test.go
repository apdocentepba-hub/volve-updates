//go:build windows

package main

import "testing"

func TestPrintableTaskArg(t *testing.T) {
	if got := printableTaskArg("--test\nmore"); got != "--test more" {
		t.Fatal(got)
	}
}
