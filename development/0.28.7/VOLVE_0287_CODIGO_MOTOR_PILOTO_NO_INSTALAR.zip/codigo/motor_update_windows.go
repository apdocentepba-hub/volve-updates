//go:build windows

package main

import (
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"errors"
	"fmt"
	"os"
	"strings"
	"time"

	"volve-browser-protection/motorupdate"
)

// This command is a pilot: it checks the independent signed engine channel
// without modifying the persistent DNS worker, rescue journal or Windows tasks.
func checkMotorUpdatePilot() (string, error) {
	key, e := base64.StdEncoding.DecodeString(updaterPublicKey)
	if e != nil {
		return "", e
	}
	ctx, cancel := context.WithTimeout(context.Background(), 25*time.Second)
	defer cancel()
	m, _, _, e := motorupdate.FetchSigned(ctx, motorupdate.DefaultClient(), motorupdate.ChannelURL, ed25519.PublicKey(key))
	if errors.Is(e, motorupdate.ErrNotPublished) {
		return "VOLVÉ | MOTOR DNS — CANAL EN PREPARACIÓN\n\nEl Centro está operativo y el motor DNS existente NO se modificó.\nTodavía no hay un paquete firmado del motor publicado.\nLa comprobación no cambia DNS, tareas, listas ni permisos.", nil
	}
	if e != nil {
		return "No se pudo verificar el canal del motor: " + e.Error() + "\nNo se modificó Windows.", nil
	}
	// The legacy executable is named 0270 but its verified installed *version*
	// is not recorded separately. Do not infer a trusted version from its name.
	engine, er := servicePath()
	if er != nil {
		return "", er
	}
	if _, er = os.Stat(engine); er != nil {
		return "Hay un paquete firmado del motor, pero no se verificó la instalación heredada. No se modificó nada.", nil
	}
	return fmt.Sprintf("VOLVÉ | PAQUETE DE MOTOR FIRMADO\nNueva versión anunciada: %s\nRequiere Centro: %s\nNotas: %s\n\nEl motor residente está presente, pero todavía falta verificar su identidad y validar el cambio de tarea con reversión independiente.\nPor seguridad, esta versión solo consulta el canal; NO instala ni reemplaza el motor activo.", m.Version, m.MinPanelVersion, strings.TrimSpace(m.Notes)), nil
}

func motorPilotPanel(w uintptr) {
	panelTextGuard.Lock()
	if panelBusy {
		panelTextGuard.Unlock()
		msg("Ya hay una comprobación en curso.", MB_ICONINFORMATION)
		return
	}
	panelBusy = true
	panelRequest++
	req := panelRequest
	panelTextGuard.Unlock()
	if advancedVisible {
		toggleAdvanced()
	}
	setText(panelTextHwnd, "VOLVÉ | MOTOR DNS — PRUEBA DE CANAL\r\n\r\nComprobando únicamente la firma del canal del motor.\r\nNo modifica el servicio DNS ni sus tareas de rescate.")
	go func() {
		result := panelToolBounded("--check-motor-updates", 35*time.Second)
		panelTextGuard.Lock()
		panelBusy = false
		if req == panelRequest {
			panelText = result
			procPost.Call(w, wmAppDataReady, 0, 0)
		}
		panelTextGuard.Unlock()
	}()
}
