//go:build windows

package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"os"
	"path/filepath"
)

// No network interface or DNS server is changed in this version. The Windows
// resolver's hosts file adds system-wide coverage for clients using that resolver.
func windowsHostsPath() (string, error) {
	root := os.Getenv("SystemRoot")
	if root == "" || !filepath.IsAbs(root) {
		return "", errors.New("SystemRoot no disponible")
	}
	return filepath.Join(root, "System32", "drivers", "etc", "hosts"), nil
}
func readHosts() (string, []byte, error) {
	p, e := windowsHostsPath()
	if e != nil {
		return "", nil, e
	}
	b, e := os.ReadFile(p)
	if errors.Is(e, os.ErrNotExist) {
		return "", nil, fmt.Errorf("no se encontró hosts en %s; por seguridad no se creará: %w", p, e)
	}
	if e != nil {
		return "", nil, e
	}
	if e = validateHostsBytes(b); e != nil {
		return "", nil, e
	}
	return p, b, nil
}
func replaceHosts(p string, old, desired []byte) error {
	// Recheck immediately before touching the file to avoid overwriting edits.
	current, e := os.ReadFile(p)
	if e != nil {
		return e
	}
	if !bytes.Equal(current, old) {
		return errors.New("hosts cambió durante la operación; no se sobrescribe")
	}
	dir := filepath.Dir(p)
	f, e := os.CreateTemp(dir, "VOLVE-hosts-")
	if e != nil {
		return fmt.Errorf("Windows rechazó la escritura protegida de hosts: %w", e)
	}
	defer os.Remove(f.Name())
	if st, e := os.Stat(p); e == nil {
		if e = f.Chmod(st.Mode().Perm()); e != nil {
			f.Close()
			return e
		}
	}
	if _, e = f.Write(desired); e != nil {
		f.Close()
		return e
	}
	if e = f.Sync(); e != nil {
		f.Close()
		return e
	}
	if e = f.Close(); e != nil {
		return e
	}
	// os.Rename is an atomic replace when supported by Windows permissions.
	if e = os.Rename(f.Name(), p); e != nil {
		return fmt.Errorf("no se pudo reemplazar hosts atómicamente: %w", e)
	}
	confirm, e := os.ReadFile(p)
	if e != nil || !bytes.Equal(confirm, desired) {
		return errors.New("no se pudo verificar hosts después de instalar; revisar respaldo VOLVE")
	}
	return nil
}
func backupHosts(original []byte) error {
	state, e := statePath()
	if e != nil {
		return e
	}
	if e = os.MkdirAll(filepath.Dir(state), 0700); e != nil {
		return e
	}
	backup := filepath.Join(filepath.Dir(state), "hosts.before-0200.bak")
	f, e := os.OpenFile(backup, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if errors.Is(e, os.ErrExist) {
		// Never overwrite backups from earlier attempts.
		return nil
	}
	if e != nil {
		return e
	}
	if _, e = f.Write(original); e != nil {
		f.Close()
		os.Remove(backup)
		return e
	}
	if e = f.Sync(); e != nil {
		f.Close()
		return e
	}
	return f.Close()
}
func installHosts() error {
	p, current, e := readHosts()
	if e != nil {
		return e
	}
	desired, changed, e := addHostsContent(current)
	if e != nil {
		return e
	}
	if !changed {
		return nil
	}
	if e = backupHosts(current); e != nil {
		return e
	}
	return replaceHosts(p, current, desired)
}
func restoreHosts() error {
	p, current, e := readHosts()
	if e != nil {
		return e
	}
	desired, changed, e := removeHostsContent(current)
	if e != nil {
		return e
	}
	if !changed {
		return nil
	}
	return replaceHosts(p, current, desired)
}
func verifyHosts() (string, error) {
	_, b, e := readHosts()
	if e != nil {
		return "ERROR", e
	}
	start, _, e := markerRange(b)
	if e != nil {
		return "ALTERADO", e
	}
	if start < 0 {
		return "INACTIVO", nil
	}
	hash := sha256.Sum256(b)
	return "ACTIVO (SHA-256 hosts: " + hex.EncodeToString(hash[:8]) + ")", nil
}
