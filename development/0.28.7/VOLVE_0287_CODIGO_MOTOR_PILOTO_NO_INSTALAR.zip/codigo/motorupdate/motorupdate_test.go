package motorupdate

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

type handler func(*http.Request) (*http.Response, error)

func (fn handler) RoundTrip(r *http.Request) (*http.Response, error) { return fn(r) }
func testKey(t *testing.T) (ed25519.PublicKey, ed25519.PrivateKey) {
	t.Helper()
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	return pub, priv
}
func signedManifest(t *testing.T, payload []byte, binary []byte, private ed25519.PrivateKey, modify func(*Manifest)) ([]byte, []byte, Manifest) {
	t.Helper()
	sum := sha256.Sum256(binary)
	m := Manifest{Schema: 1, Component: "dns-engine", Version: "0.29.0", MinPanelVersion: "0.28.7", URL: "https://github.com/apdocentepba-hub/volve-updates/releases/download/v0.29.0/VOLVE_DNS_Motor_0_29_0.exe", SHA256: hex.EncodeToString(sum[:]), Size: int64(len(binary)), Notes: "motor con reversión"}
	if modify != nil {
		modify(&m)
	}
	raw, err := json.Marshal(m)
	if err != nil {
		t.Fatal(err)
	}
	if payload != nil {
		raw = payload
	}
	sig := []byte(base64.StdEncoding.EncodeToString(ed25519.Sign(private, raw)))
	return raw, sig, m
}
func TestSignedManifestRejectsTampering(t *testing.T) {
	pub, priv := testKey(t)
	exe := []byte("MZfake-test-only")
	raw, sig, m := signedManifest(t, nil, exe, priv, nil)
	verified, err := VerifyManifest(raw, sig, pub)
	if err != nil || verified != m {
		t.Fatalf("valid signature: %v", err)
	}
	modified := bytes.Replace(raw, []byte("0.29.0"), []byte("0.30.0"), 1)
	if _, err = VerifyManifest(modified, sig, pub); err == nil {
		t.Fatal("accepted changed signed payload")
	}
	wrong, _ := testKey(t)
	if _, err = VerifyManifest(raw, sig, wrong); err == nil {
		t.Fatal("accepted wrong signer")
	}
}
func TestManifestValidationRejectsCrossComponentOrUnsafeURL(t *testing.T) {
	pub, priv := testKey(t)
	cases := []struct {
		name   string
		change func(*Manifest)
	}{
		{"panel substitution", func(m *Manifest) { m.Component = "control-center" }},
		{"http", func(m *Manifest) {
			m.URL = "http://github.com/apdocentepba-hub/volve-updates/releases/download/v0.29.0/VOLVE_DNS_Motor_0_29_0.exe"
		}},
		{"different owner", func(m *Manifest) {
			m.URL = "https://github.com/stranger/volve-updates/releases/download/v0.29.0/VOLVE_DNS_Motor_0_29_0.exe"
		}},
		{"wrong file", func(m *Manifest) {
			m.URL = "https://github.com/apdocentepba-hub/volve-updates/releases/download/v0.29.0/VOLVE_Centro_Proteccion_0_29_0.exe"
		}},
		{"wrong release tag", func(m *Manifest) {
			m.URL = "https://github.com/apdocentepba-hub/volve-updates/releases/download/v0.29.1/VOLVE_DNS_Motor_0_29_0.exe"
		}},
		{"query", func(m *Manifest) { m.URL += "?download=1" }},
		{"oversized", func(m *Manifest) { m.Size = MaxEngineBytes + 1 }},
		{"bad sha", func(m *Manifest) { m.SHA256 = "abc" }},
		{"wrong version", func(m *Manifest) { m.Version = "0.29" }},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			raw, sig, _ := signedManifest(t, nil, []byte("MZ"), priv, tc.change)
			if _, err := VerifyManifest(raw, sig, pub); err == nil {
				t.Fatal("accepted invalid manifest")
			}
		})
	}
}
func TestStageAndVerifyNoSystemMutations(t *testing.T) {
	pub, priv := testKey(t)
	payload := []byte("MZtest-engine-not-executable")
	raw, sig, m := signedManifest(t, nil, payload, priv, nil)
	client := &http.Client{Transport: handler(func(r *http.Request) (*http.Response, error) {
		return &http.Response{StatusCode: 200, Body: io.NopCloser(bytes.NewReader(payload)), ContentLength: int64(len(payload)), Header: make(http.Header)}, nil
	})}
	root := t.TempDir()
	file, err := Stage(context.Background(), client, m, raw, sig, pub, root)
	if err != nil {
		t.Fatal(err)
	}
	verified, err := VerifyStaged(file, pub)
	if err != nil || verified != m {
		t.Fatalf("staged check failed: %v", err)
	}
	if !strings.Contains(file, "motor-0.29.0") {
		t.Fatal("stage not versioned")
	}
	if _, err := Stage(context.Background(), client, m, raw, sig, pub, root); err == nil {
		t.Fatal("overwrote versioned motor")
	}
	if err := os.WriteFile(file, []byte("broken"), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := VerifyStaged(file, pub); err == nil {
		t.Fatal("accepted altered binary")
	}
	if _, err := os.Stat(filepath.Join(root, "motor-0.29.0")); err != nil {
		t.Fatal(err)
	}
}
func TestStageRejectsCorruptedDownload(t *testing.T) {
	pub, priv := testKey(t)
	raw, sig, m := signedManifest(t, nil, []byte("MZgood"), priv, nil)
	client := &http.Client{Transport: handler(func(r *http.Request) (*http.Response, error) {
		return &http.Response{StatusCode: 200, Body: io.NopCloser(strings.NewReader("MZevil")), ContentLength: 6, Header: make(http.Header)}, nil
	})}
	root := t.TempDir()
	_, err := Stage(context.Background(), client, m, raw, sig, pub, root)
	if err == nil {
		t.Fatal("accepted bad digest")
	}
	if _, err = os.Stat(filepath.Join(root, "motor-0.29.0")); !os.IsNotExist(err) {
		t.Fatalf("published bad stage: %v", err)
	}
}
func TestFetchMissingChannel(t *testing.T) {
	pub, _ := testKey(t)
	client := &http.Client{Transport: handler(func(r *http.Request) (*http.Response, error) {
		return &http.Response{StatusCode: 404, Body: io.NopCloser(strings.NewReader("")), Header: make(http.Header)}, nil
	})}
	_, _, _, err := FetchSigned(context.Background(), client, ChannelURL, pub)
	if !errors.Is(err, ErrNotPublished) {
		t.Fatalf("want not published, got %v", err)
	}
	_, _, _, err = FetchSigned(context.Background(), client, "http://evil.example/motor", pub)
	if err == nil {
		t.Fatal("accepted unsafe channel")
	}
}
func TestEligibility(t *testing.T) {
	_, priv := testKey(t)
	_, _, m := signedManifest(t, nil, []byte("MZ"), priv, nil)
	ok, err := IsEligible("0.27.0", "0.28.7", m)
	if err != nil || !ok {
		t.Fatalf("eligible: %v", err)
	}
	ok, err = IsEligible("0.29.0", "0.28.7", m)
	if err != nil || ok {
		t.Fatal("allow same version")
	}
	if _, err = IsEligible("0.27.0", "0.28.6", m); err == nil {
		t.Fatal("allowed old panel")
	}
	if _, err = IsEligible("0.30.0", "0.28.7", m); err != nil {
		t.Fatal(err)
	}
}

type fakeDriver struct {
	steps       []string
	fail        string
	rollbackBad bool
	probeBad    bool
	recovered   bool
}

func (d *fakeDriver) step(s string) error {
	d.steps = append(d.steps, s)
	if d.fail == s {
		return errors.New(s + " failure")
	}
	return nil
}
func (d *fakeDriver) Preflight(_ context.Context, _ Manifest) error { return d.step("preflight") }
func (d *fakeDriver) Snapshot(context.Context) error                { return d.step("snapshot") }
func (d *fakeDriver) InstallVersionedCandidate(context.Context, string) error {
	return d.step("install")
}
func (d *fakeDriver) Switch(context.Context) error { return d.step("switch") }
func (d *fakeDriver) Probe(context.Context) error {
	d.steps = append(d.steps, "probe")
	if d.probeBad && !d.recovered {
		return errors.New("DNS probe down")
	}
	return nil
}
func (d *fakeDriver) Restore(context.Context) error {
	d.steps = append(d.steps, "restore")
	if d.rollbackBad {
		return errors.New("restore down")
	}
	d.recovered = true
	return nil
}
func stagedTestFile(t *testing.T) (string, ed25519.PublicKey) {
	t.Helper()
	pub, priv := testKey(t)
	binary := []byte("MZ-fake-motor-for-test")
	raw, sig, m := signedManifest(t, nil, binary, priv, nil)
	p := filepath.Join(t.TempDir(), stagedFilename(m))
	for _, v := range []struct {
		suffix string
		bytes  []byte
	}{{"", binary}, {".json", raw}, {".sig", sig}} {
		if err := os.WriteFile(p+v.suffix, v.bytes, 0600); err != nil {
			t.Fatal(err)
		}
	}
	return p, pub
}
func TestUpgradeSimulationSuccessAndRollback(t *testing.T) {
	p, key := stagedTestFile(t)
	for _, tt := range []struct {
		name, fail  string
		wantRestore bool
	}{{"ok", "", false}, {"switch fail", "switch", true}, {"install fail", "install", true}} {
		t.Run(tt.name, func(t *testing.T) {
			d := &fakeDriver{fail: tt.fail}
			err := ApplyWithRollback(context.Background(), p, key, "0.27.0", "0.28.7", d)
			if tt.fail == "" && err != nil {
				t.Fatal(err)
			}
			if tt.fail != "" && (err == nil || d.recovered != tt.wantRestore) {
				t.Fatalf("rollback not executed: %v %#v", err, d.steps)
			}
		})
	}
	d := &fakeDriver{probeBad: true}
	err := ApplyWithRollback(context.Background(), p, key, "0.27.0", "0.28.7", d)
	if err == nil || !d.recovered {
		t.Fatalf("failed health should restore: %v", err)
	}
	d = &fakeDriver{fail: "switch", rollbackBad: true}
	err = ApplyWithRollback(context.Background(), p, key, "0.27.0", "0.28.7", d)
	if err == nil || !strings.Contains(err.Error(), "CRÍTICO") {
		t.Fatalf("must report failed recovery: %v", err)
	}
}
func TestNoSideEffectsBeforeVerification(t *testing.T) {
	p, key := stagedTestFile(t)
	if e := os.WriteFile(p, []byte("wrong"), 0600); e != nil {
		t.Fatal(e)
	}
	d := &fakeDriver{}
	if err := ApplyWithRollback(context.Background(), p, key, "0.27.0", "0.28.7", d); err == nil {
		t.Fatal("accepted corrupt stage")
	}
	if len(d.steps) > 0 {
		t.Fatal("did system work before signature/hash validation")
	}
}
