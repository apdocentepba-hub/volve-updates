package motorupdate

import (
	"context"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

func stagedFilename(m Manifest) string {
	return "VOLVE_DNS_Motor_" + strings.ReplaceAll(m.Version, ".", "_") + ".exe"
}

// Stage downloads a signed, component-scoped engine into a *new versioned
// directory*. It never executes it, writes ProgramData, or changes DNS/tasks.
func Stage(ctx context.Context, client *http.Client, m Manifest, raw, sig []byte, key ed25519.PublicKey, root string) (string, error) {
	verified, e := VerifyManifest(raw, sig, key)
	if e != nil || verified != m {
		return "", errors.New("manifiesto del motor no coincide con la firma")
	}
	if e = os.MkdirAll(root, 0700); e != nil {
		return "", e
	}
	targetDir := filepath.Join(root, "motor-"+m.Version)
	if _, e = os.Lstat(targetDir); e == nil {
		return "", errors.New("versión ya preparada: no sobrescribir")
	} else if !errors.Is(e, os.ErrNotExist) {
		return "", e
	}
	tempDir, e := os.MkdirTemp(root, ".motor-download-")
	if e != nil {
		return "", e
	}
	defer os.RemoveAll(tempDir)
	req, e := http.NewRequestWithContext(ctx, http.MethodGet, m.URL, nil)
	if e != nil {
		return "", e
	}
	res, e := client.Do(req)
	if e != nil {
		return "", e
	}
	defer res.Body.Close()
	if res.StatusCode != 200 {
		return "", fmt.Errorf("HTTP %d descargando motor", res.StatusCode)
	}
	if res.ContentLength > m.Size {
		return "", errors.New("motor supera tamaño firmado")
	}
	filename := filepath.Join(tempDir, stagedFilename(m))
	f, e := os.OpenFile(filename, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return "", e
	}
	h := sha256.New()
	n, e := io.Copy(io.MultiWriter(f, h), io.LimitReader(res.Body, m.Size+1))
	if e != nil {
		f.Close()
		return "", e
	}
	if n != m.Size || hex.EncodeToString(h.Sum(nil)) != m.SHA256 {
		f.Close()
		return "", errors.New("tamaño o hash SHA-256 de motor incorrecto")
	}
	if e = f.Sync(); e != nil {
		f.Close()
		return "", e
	}
	if e = f.Close(); e != nil {
		return "", e
	}
	if e = os.WriteFile(filename+".json", raw, 0600); e != nil {
		return "", e
	}
	if e = os.WriteFile(filename+".sig", sig, 0600); e != nil {
		return "", e
	}
	if e = os.Rename(tempDir, targetDir); e != nil {
		return "", e
	}
	return filepath.Join(targetDir, stagedFilename(m)), nil
}

func VerifyStaged(path string, key ed25519.PublicKey) (Manifest, error) {
	raw, e := os.ReadFile(path + ".json")
	if e != nil {
		return Manifest{}, e
	}
	sig, e := os.ReadFile(path + ".sig")
	if e != nil {
		return Manifest{}, e
	}
	m, e := VerifyManifest(raw, sig, key)
	if e != nil {
		return Manifest{}, e
	}
	if filepath.Base(path) != stagedFilename(m) {
		return Manifest{}, errors.New("archivo no coincide con versión firmada")
	}
	f, e := os.Open(path)
	if e != nil {
		return Manifest{}, e
	}
	defer f.Close()
	stat, e := f.Stat()
	if e != nil {
		return Manifest{}, e
	}
	if !stat.Mode().IsRegular() || stat.Size() != m.Size {
		return Manifest{}, errors.New("motor preparado tiene tamaño inesperado")
	}
	h := sha256.New()
	n, e := io.Copy(h, io.LimitReader(f, m.Size+1))
	if e != nil {
		return Manifest{}, e
	}
	if n != m.Size || hex.EncodeToString(h.Sum(nil)) != m.SHA256 {
		return Manifest{}, errors.New("motor preparado fue modificado")
	}
	return m, nil
}
