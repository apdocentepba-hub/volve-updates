// Package motorupdate implements a non-destructive, signed delivery channel for
// the VOLVÉ DNS engine. It DOES NOT install or switch a live DNS service.
package motorupdate

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"time"
)

const ChannelURL = "https://raw.githubusercontent.com/apdocentepba-hub/volve-updates/main/releases/motor-stable.json"
const releasePrefix = "/apdocentepba-hub/volve-updates/releases/download/"
const MaxManifestBytes = 16 << 10
const MaxEngineBytes int64 = 80 << 20

var ErrNotPublished = errors.New("actualizaciones del motor todavía no publicadas")
var versionRe = regexp.MustCompile(`^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$`)
var hexRe = regexp.MustCompile(`^[0-9a-f]{64}$`)

type Manifest struct {
	Schema          int    `json:"schema"`
	Component       string `json:"component"`
	Version         string `json:"version"`
	MinPanelVersion string `json:"min_panel_version"`
	URL             string `json:"url"`
	SHA256          string `json:"sha256"`
	Size            int64  `json:"size"`
	Notes           string `json:"notes"`
}

func compareVersions(a, b string) (int, error) {
	if !versionRe.MatchString(a) || !versionRe.MatchString(b) {
		return 0, errors.New("versión inválida")
	}
	parts := func(v string) ([]uint64, error) {
		var n []uint64
		for _, p := range strings.Split(v, ".") {
			u, e := strconv.ParseUint(p, 10, 32)
			if e != nil {
				return nil, e
			}
			n = append(n, u)
		}
		return n, nil
	}
	aa, e := parts(a)
	if e != nil {
		return 0, e
	}
	bb, e := parts(b)
	if e != nil {
		return 0, e
	}
	for i := range aa {
		if aa[i] < bb[i] {
			return -1, nil
		}
		if aa[i] > bb[i] {
			return 1, nil
		}
	}
	return 0, nil
}

func Validate(m Manifest) error {
	if m.Schema != 1 || m.Component != "dns-engine" || !versionRe.MatchString(m.Version) || !versionRe.MatchString(m.MinPanelVersion) {
		return errors.New("componente, esquema o versión no reconocidos")
	}
	if m.Size <= 0 || m.Size > MaxEngineBytes || !hexRe.MatchString(m.SHA256) || len(m.Notes) > 2000 {
		return errors.New("tamaño, huella o notas fuera de límites")
	}
	u, e := url.Parse(m.URL)
	if e != nil {
		return e
	}
	if u.Scheme != "https" || u.Host != "github.com" || u.User != nil || u.RawQuery != "" || u.Fragment != "" || u.EscapedPath() != u.Path {
		return errors.New("origen de paquete del motor no autorizado")
	}
	expectedPrefix := releasePrefix + "v" + m.Version + "/"
	expectedName := "VOLVE_DNS_Motor_" + strings.ReplaceAll(m.Version, ".", "_") + ".exe"
	if u.Path != expectedPrefix+expectedName {
		return errors.New("versión o nombre de paquete no coinciden")
	}
	if _, e = hex.DecodeString(m.SHA256); e != nil {
		return errors.New("huella inválida")
	}
	return nil
}

func VerifyManifest(raw, detachedSignature []byte, key ed25519.PublicKey) (Manifest, error) {
	var m Manifest
	if len(key) != ed25519.PublicKeySize || len(raw) == 0 || len(raw) > MaxManifestBytes || len(detachedSignature) > 4096 {
		return m, errors.New("tamaño de manifiesto/firma/clave no válido")
	}
	sig, e := base64.StdEncoding.DecodeString(strings.TrimSpace(string(detachedSignature)))
	if e != nil || len(sig) != ed25519.SignatureSize || !ed25519.Verify(key, raw, sig) {
		return m, errors.New("firma Ed25519 del motor inválida")
	}
	d := json.NewDecoder(bytes.NewReader(raw))
	d.DisallowUnknownFields()
	if e = d.Decode(&m); e != nil {
		return Manifest{}, fmt.Errorf("JSON inválido: %w", e)
	}
	var extra any
	if d.Decode(&extra) != io.EOF {
		return Manifest{}, errors.New("manifiesto contiene datos sobrantes")
	}
	if e = Validate(m); e != nil {
		return Manifest{}, e
	}
	return m, nil
}

func DefaultClient() *http.Client {
	return &http.Client{Timeout: 90 * time.Second, CheckRedirect: func(req *http.Request, via []*http.Request) error {
		if len(via) >= 5 || req.URL.Scheme != "https" {
			return errors.New("redirección de descarga no autorizada")
		}
		return nil
	}}
}

func FetchSigned(ctx context.Context, client *http.Client, channel string, key ed25519.PublicKey) (Manifest, []byte, []byte, error) {
	if channel != ChannelURL {
		return Manifest{}, nil, nil, errors.New("canal del motor no autorizado")
	}
	fetch := func(uri string, limit int64) ([]byte, error) {
		req, e := http.NewRequestWithContext(ctx, http.MethodGet, uri, nil)
		if e != nil {
			return nil, e
		}
		res, e := client.Do(req)
		if e != nil {
			return nil, e
		}
		defer res.Body.Close()
		if res.StatusCode == http.StatusNotFound {
			return nil, ErrNotPublished
		}
		if res.StatusCode != 200 {
			return nil, fmt.Errorf("HTTP %d consultando canal del motor", res.StatusCode)
		}
		out, e := io.ReadAll(io.LimitReader(res.Body, limit+1))
		if e != nil {
			return nil, e
		}
		if int64(len(out)) > limit {
			return nil, errors.New("respuesta de canal excesiva")
		}
		return out, nil
	}
	raw, e := fetch(channel, MaxManifestBytes)
	if e != nil {
		return Manifest{}, nil, nil, e
	}
	signature, e := fetch(channel+".sig", 4096)
	if e != nil {
		return Manifest{}, nil, nil, e
	}
	m, e := VerifyManifest(raw, signature, key)
	return m, raw, signature, e
}

// IsEligible rejects downgrades and incompatible frontends without any system changes.
func IsEligible(installedEngineVersion, panelVersion string, m Manifest) (bool, error) {
	if e := Validate(m); e != nil {
		return false, e
	}
	p, e := compareVersions(panelVersion, m.MinPanelVersion)
	if e != nil {
		return false, e
	}
	if p < 0 {
		return false, errors.New("el Centro debe actualizarse antes que el motor")
	}
	c, e := compareVersions(installedEngineVersion, m.Version)
	if e != nil {
		return false, e
	}
	return c < 0, nil
}
