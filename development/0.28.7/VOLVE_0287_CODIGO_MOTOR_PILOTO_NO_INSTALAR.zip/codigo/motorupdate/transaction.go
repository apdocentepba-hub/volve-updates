package motorupdate

import (
	"context"
	"crypto/ed25519"
	"errors"
	"fmt"
)

// This is an *abstract* failback contract, not a live Windows implementation.
// A concrete Windows driver must independently prove task ownership, keep the
// original DNS rescue scripts/journal untouched, and use versioned binaries.
// No caller may mark an update committed until Probe succeeds.
type SwitchDriver interface {
	Preflight(context.Context, Manifest) error
	Snapshot(context.Context) error
	InstallVersionedCandidate(context.Context, string) error
	Switch(context.Context) error
	Probe(context.Context) error
	Restore(context.Context) error
}

// ApplyWithRollback is exercised only with simulated drivers in this pilot.
// A live driver is deliberately absent, to prevent accidental updates to the
// active DNS service before independent Windows failback has been validated.
func ApplyWithRollback(ctx context.Context, candidate string, key ed25519.PublicKey, installedEngineVersion, panelVersion string, driver SwitchDriver) error {
	if candidate == "" || driver == nil {
		return errors.New("candidato o controlador ausente")
	}
	m, e := VerifyStaged(candidate, key)
	if e != nil {
		return fmt.Errorf("candidato no auténtico: %w", e)
	}
	eligible, e := IsEligible(installedEngineVersion, panelVersion, m)
	if e != nil {
		return e
	}
	if !eligible {
		return errors.New("el motor instalado no es anterior al candidato")
	}
	if e := driver.Preflight(ctx, m); e != nil {
		return fmt.Errorf("revisión inicial falló: %w", e)
	}
	if e := driver.Snapshot(ctx); e != nil {
		return fmt.Errorf("respaldo de la configuración falló: %w", e)
	}
	if e := driver.InstallVersionedCandidate(ctx, candidate); e != nil {
		return restoreAndVerify(ctx, driver, fmt.Errorf("no se instaló motor versionado: %w", e))
	}
	if e := driver.Switch(ctx); e != nil {
		return restoreAndVerify(ctx, driver, e)
	}
	if e := driver.Probe(ctx); e != nil {
		return restoreAndVerify(ctx, driver, fmt.Errorf("nuevo motor sin respuesta: %w", e))
	}
	return nil
}

func restoreAndVerify(ctx context.Context, d SwitchDriver, cause error) error {
	restoreErr := d.Restore(ctx)
	if restoreErr != nil {
		return errors.Join(cause, fmt.Errorf("CRÍTICO: recuperación de motor falló: %w", restoreErr))
	}
	if e := d.Probe(ctx); e != nil {
		return errors.Join(cause, fmt.Errorf("CRÍTICO: recuperación no verificable: %w", e))
	}
	return fmt.Errorf("actualización revertida, motor anterior recuperado: %w", cause)
}
