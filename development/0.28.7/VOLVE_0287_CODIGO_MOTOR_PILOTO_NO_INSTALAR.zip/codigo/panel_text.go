package main

import "strings"

// Windows multiline EDIT controls require CRLF for reliable line breaks.
func panelCRLF(s string) string {
	return strings.ReplaceAll(strings.ReplaceAll(s, "\r\n", "\n"), "\n", "\r\n")
}
