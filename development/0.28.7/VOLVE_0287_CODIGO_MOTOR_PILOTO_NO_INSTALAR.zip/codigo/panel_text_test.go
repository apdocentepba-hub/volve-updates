package main

import "testing"

func TestPanelCRLF(t *testing.T) {
	got := panelCRLF("línea 1\nlínea 2\r\nlínea 3")
	want := "línea 1\r\nlínea 2\r\nlínea 3"
	if got != want {
		t.Fatalf("got %q, want %q", got, want)
	}
	if panelCRLF(got) != want {
		t.Fatalf("not idempotent")
	}
}
