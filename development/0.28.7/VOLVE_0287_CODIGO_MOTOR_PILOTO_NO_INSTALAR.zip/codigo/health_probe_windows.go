//go:build windows

package main

import (
	"bytes"
	"context"
	"os/exec"
	"syscall"
	"time"
)

// Execute ONLY the fixed read-only health script with stdout and stderr isolated.
// The ordinary runPS remains untouched for the existing DNS engine.
func queryAdapterMarker(script string) (string, error) {
	raw := syscall.StringToUTF16(script)
	b := make([]byte, 0, len(raw)*2)
	for _, v := range raw[:len(raw)-1] {
		b = append(b, byte(v), byte(v>>8))
	}
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, "powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-EncodedCommand", base64Of(b))
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: createNoWindow}
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err := cmd.Run()
	if ctx.Err() != nil {
		return "", ctx.Err()
	}
	return parseHealthMarker(stdout.Bytes(), stderr.Bytes(), err)
}
