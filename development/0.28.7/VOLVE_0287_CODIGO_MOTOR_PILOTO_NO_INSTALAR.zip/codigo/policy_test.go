package main

import (
	"strings"
	"testing"
)

func TestPolicyEntries(t *testing.T) {
	a, e := policyEntries()
	if e != nil {
		t.Fatal(e)
	}
	if len(a) != len(domains)*4 {
		t.Fatalf("expected %d got %d", len(domains)*4, len(a))
	}
	var chrome, firefox bool
	for _, x := range a {
		if strings.Contains(x.Key, "Chrome") && x.Value == "bet.ar" {
			chrome = true
		}
		if strings.Contains(x.Key, "Firefox") && x.Value == "*://*.bet.ar/*" {
			firefox = true
		}
	}
	if !chrome || !firefox {
		t.Fatal("required wildcard coverage missing")
	}
}
