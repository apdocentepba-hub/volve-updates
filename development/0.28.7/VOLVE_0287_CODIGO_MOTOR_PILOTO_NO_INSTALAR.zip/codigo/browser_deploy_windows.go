//go:build windows

package main

import (
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"errors"
	"fmt"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"time"
	"volve-browser-protection/browseraddons"
)

const chromeUpdateURL = "https://clients2.google.com/service/update2/crx"
const edgeUpdateURL = "https://edge.microsoft.com/extensionwebstorebase/v1/crx"

func browserCatalog() (browseraddons.Catalog, error) {
	var c browseraddons.Catalog
	pk, err := base64.StdEncoding.DecodeString(updaterPublicKey)
	if err != nil {
		return c, err
	}
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()
	return browseraddons.Fetch(ctx, ed25519.PublicKey(pk))
}

func browserAvailable(name string) bool {
	name = strings.ToLower(name)
	for _, p := range preferredBrowsers() {
		if strings.Contains(strings.ToLower(filepath.Base(p)), name) {
			return true
		}
	}
	return false
}

func browserStatus() string {
	c, err := browserCatalog()
	if errors.Is(err, browseraddons.ErrNotPublished) {
		return "La integración ya está preparada dentro de VOLVÉ, pero la extensión aún NO está publicada en Chrome Web Store, Edge Add-ons ni Firefox Add-ons.\n\n" +
			"No se pueden instalar extensiones locales silenciosamente en Chrome. Cuando estén publicadas, este mismo botón podrá registrar las de Chrome y Edge y abrir Firefox para tu confirmación.\n\n" +
			"Todavía NO cambié el Registro de Windows ni los navegadores. El bloqueo DNS sigue funcionando."
	}
	if err != nil {
		return "No se pudo verificar el canal firmado de complementos: " + err.Error() + "\nNo hubo cambios."
	}
	installed := []string{}
	if browserAvailable("chrome.exe") && c.ChromeID != "" {
		installed = append(installed, "Chrome")
	}
	if browserAvailable("msedge.exe") && c.EdgeID != "" {
		installed = append(installed, "Edge")
	}
	if browserAvailable("firefox.exe") && c.FirefoxURL != "" {
		installed = append(installed, "Firefox")
	}
	return fmt.Sprintf("Complementos publicados y firma verificada.\nNavegadores detectados: %s\n\nPulsa INTEGRAR en Herramientas avanzadas para autorizar la preparación. Chrome, Edge y Firefox pueden requerir confirmación propia.", strings.Join(installed, ", "))
}

// registerExternal does not set policies or force installation: it only registers
// a browser-store ID. Chrome/Edge require user to enable the extension on next start.
// The registry key is created only if it does not already exist, or if the
// existing update_url matches our pinned official store source.
func registerExternal(root, id, updateURL string) error {
	key := root + `\` + id
	out, err := reg("query", key, "/v", "update_url")
	if err == nil {
		if !strings.Contains(strings.ToLower(out), strings.ToLower(updateURL)) {
			return fmt.Errorf("ya existe una configuración diferente en %s: no se modifica", key)
		}
		return nil
	}
	// Refuse to modify any key that already exists if we cannot read the value.
	if _, checkErr := reg("query", key); checkErr == nil {
		return fmt.Errorf("clave existente sin update_url verificable: %s", key)
	}
	o, err := reg("add", key, "/v", "update_url", "/t", "REG_SZ", "/d", updateURL, "/f")
	if err != nil {
		return fmt.Errorf("no se pudo registrar el complemento %s: %v %s", key, err, o)
	}
	return nil
}

func installBrowserAddons() (string, error) {
	if !isAdmin() {
		return "", errors.New("se requieren permisos de administrador")
	}
	c, err := browserCatalog()
	if errors.Is(err, browseraddons.ErrNotPublished) {
		return "Todavía no hay complementos publicados y firmados. No se ha modificado ningún navegador.", nil
	}
	if err != nil {
		return "", err
	}
	found := false
	messages := []string{}
	if browserAvailable("chrome.exe") && c.ChromeID != "" {
		found = true
		e := registerExternal(`HKLM\SOFTWARE\WOW6432Node\Google\Chrome\Extensions`, c.ChromeID, chromeUpdateURL)
		if e != nil {
			messages = append(messages, "Chrome: "+e.Error())
		} else {
			messages = append(messages, "Chrome: extensión registrada; al abrir Chrome debés aceptarla o habilitarla")
		}
	}
	if browserAvailable("msedge.exe") && c.EdgeID != "" {
		found = true
		e := registerExternal(`HKLM\SOFTWARE\WOW6432Node\Microsoft\Edge\Extensions`, c.EdgeID, edgeUpdateURL)
		if e != nil {
			messages = append(messages, "Edge: "+e.Error())
		} else {
			messages = append(messages, "Edge: extensión registrada; Edge puede pedir que la habilites")
		}
	}
	if browserAvailable("firefox.exe") && c.FirefoxURL != "" {
		found = true
		// Firefox installation uses its own approved signed add-on flow.
		// Don't force installation or alter policies.json on personal PCs.
		firefox := ""
		for _, exe := range preferredBrowsers() {
			if strings.EqualFold(filepath.Base(exe), "firefox.exe") {
				firefox = exe
				break
			}
		}
		cmd := exec.Command(firefox, "-new-tab", c.FirefoxURL)
		cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
		if err := cmd.Start(); err != nil {
			messages = append(messages, "Firefox: no se pudo abrir el enlace oficial: "+err.Error())
		} else {
			messages = append(messages, "Firefox: tienda oficial abierta para autorizar la extensión")
		}
	}
	if !found {
		messages = append(messages, "No se detectaron navegadores compatibles con complementos publicados.")
	}
	return strings.Join(messages, "\n") + "\n\nEl motor DNS instalado no se ha modificado.", nil
}

func browserAddonsOptin(w uintptr) {
	c, err := browserCatalog()
	if errors.Is(err, browseraddons.ErrNotPublished) {
		msg("VOLVÉ todavía NO tiene complementos publicados en las tiendas.\n\nEl instalador ya incluye el flujo oficial, pero no hay una extensión instalable ni se cambiará Windows.\n\nNo hace falta descargar ZIP.", MB_ICONINFORMATION)
		return
	}
	if err != nil {
		msg("No se pudo verificar el canal firmado: "+err.Error(), MB_ICONERROR)
		return
	}
	_ = c
	if msg("¿Preparar los complementos de VOLVÉ en los navegadores instalados?\n\nVOLVÉ los registrará desde sus tiendas oficiales. Chrome, Edge y Firefox podrán pedirte que los habilites.\n\nNO se fuerza la instalación ni se modifica el motor DNS.", MB_YESNOCANCEL|MB_ICONQUESTION) != 6 {
		return
	}
	if !isAdmin() {
		if err := requireAdmin("--install-browser-addons"); err != nil && !errors.Is(err, errSpawned) {
			msg(err.Error(), MB_ICONERROR)
		}
		return
	}
	result, err := installBrowserAddons()
	if err != nil {
		msg(err.Error(), MB_ICONERROR)
	} else {
		msg(result, MB_ICONINFORMATION)
	}
}

// No copy of the unpacked extension is required by the end user. The bundled
// add-on pilot remains source code only until the store has approved it.

// Called within an already-elevated fresh installation; never requests a
// second UAC. The browser remains the final authority over extension consent.
func offerBrowserAddonsDuringInstall() {
	_, err := browserCatalog()
	if errors.Is(err, browseraddons.ErrNotPublished) {
		return
	}
	if err != nil {
		msg("La integración de navegadores no está disponible: "+err.Error()+". El filtro DNS permanece activo.", MB_ICONINFORMATION)
		return
	}
	if msg("¿Querés preparar también el mensaje de ayuda en los navegadores instalados?\n\nSe usarán las tiendas oficiales. El navegador podrá pedir que confirmes su extensión.\nNo se modifica tu DNS.", MB_YESNOCANCEL|MB_ICONQUESTION) != 6 {
		return
	}
	result, err := installBrowserAddons()
	if err != nil {
		msg("Complementos no preparados: "+err.Error(), MB_ICONERROR)
	} else {
		msg(result, MB_ICONINFORMATION)
	}
}
