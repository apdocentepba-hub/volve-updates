package main

import (
	"errors"
	"fmt"
	"os"
	"testing"
)

func TestProtectedJournalRead(t *testing.T) {
	tests := []struct {
		name string
		err  error
		want bool
	}{
		{"direct_permission", os.ErrPermission, true},
		{"wrapped_permission", fmt.Errorf("open rescue journal: %w", os.ErrPermission), true},
		{"path_permission", &os.PathError{Op: "open", Path: "rescue.json", Err: os.ErrPermission}, true},
		{"missing", os.ErrNotExist, false},
		{"unknown", errors.New("broken filesystem"), false},
		{"no_error", nil, false},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			if got := protectedJournalRead(tc.err); got != tc.want {
				t.Fatalf("protectedJournalRead(%v)=%v want %v", tc.err, got, tc.want)
			}
		})
	}
}
