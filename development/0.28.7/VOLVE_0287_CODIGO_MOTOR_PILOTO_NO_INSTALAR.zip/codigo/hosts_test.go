package main

import (
	"bytes"
	"strings"
	"testing"
)

func TestHostsAddRemovePreservesOthers(t *testing.T) {
	for _, orig := range [][]byte{[]byte("# original\r\n127.0.0.1 localhost\r\n"), []byte("127.0.0.1 localhost"), []byte("# otros\n127.0.0.1 localhost\n")} {
		v, changed, err := addHostsContent(orig)
		if err != nil || !changed {
			t.Fatalf("add: %v %v", changed, err)
		}
		if !bytes.Contains(v, []byte("0.0.0.0 stake.com")) || !bytes.Contains(v, []byte(":: www.stake.com")) {
			t.Fatal("missing domains")
		}
		repeat, ch, e := addHostsContent(v)
		if e != nil || ch || !bytes.Equal(repeat, v) {
			t.Fatalf("duplicate: %v %v", ch, e)
		}
		clean, yes, e := removeHostsContent(v)
		if e != nil || !yes {
			t.Fatalf("remove: %v", e)
		}
		expected := orig
		if len(orig) > 0 && orig[len(orig)-1] != '\n' {
			expected = append(append([]byte(nil), orig...), '\n')
		}
		if !bytes.Equal(clean, expected) {
			t.Fatalf("didn't preserve existing content: %q != %q", clean, expected)
		}
	}
}
func TestHostsPreservesNewOtherEntries(t *testing.T) {
	v, _, _ := addHostsContent([]byte("old\n"))
	v = append(v, []byte("127.0.0.1 new.example\n")...)
	out, ok, e := removeHostsContent(v)
	if e != nil || !ok || string(out) != "old\n127.0.0.1 new.example\n" {
		t.Fatalf("did not preserve other changes: %q %v", out, e)
	}
}
func TestHostsTamperFailsClosed(t *testing.T) {
	v, _, _ := addHostsContent([]byte("# original\n"))
	v = bytes.Replace(v, []byte("stake.com"), []byte("stake.coM"), 1)
	if _, _, e := removeHostsContent(v); e == nil {
		t.Fatal("tampering allowed")
	}
	if _, _, e := addHostsContent(v); e == nil {
		t.Fatal("tampering allowed at add")
	}
	for _, base := range [][]byte{[]byte("# VOLVE-BEGIN 0.20.0 sha256=x"), []byte("# VOLVE-END 0.20.0"), []byte{0xff, 0xfe, 0}} {
		if _, _, err := addHostsContent(base); err == nil {
			t.Errorf("accepted malformed %q", base)
		}
	}
}
func TestHostsNoWildcardAndFinite(t *testing.T) {
	v, e := hostsData()
	if e != nil {
		t.Fatal(e)
	}
	if strings.Contains(string(v), "*.") {
		t.Fatal("hosts cannot support wildcard")
	}
	if lines := strings.Count(string(v), "\n"); lines < 100 || lines > 1000 {
		t.Fatalf("unexpected %d lines", lines)
	}
}
