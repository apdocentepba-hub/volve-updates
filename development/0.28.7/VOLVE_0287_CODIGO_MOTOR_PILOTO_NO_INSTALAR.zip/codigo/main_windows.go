//go:build windows

package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"unsafe"
	"volve-browser-protection/dnspreflight"
	"volve-browser-protection/dnsrollout"
)

const stateDirName = "VOLVE-Browser-Filter"
const title = "VOLVÉ 0.28.7 - Centro de protección"
const MB_YESNOCANCEL = 0x3
const MB_ICONQUESTION = 0x20
const MB_ICONINFORMATION = 0x40
const MB_ICONERROR = 0x10

var shell = syscall.NewLazyDLL("shell32.dll")
var user = syscall.NewLazyDLL("user32.dll")

func msg(s string, style uintptr) int {
	p, _ := syscall.UTF16PtrFromString(s)
	t, _ := syscall.UTF16PtrFromString(title)
	ret, _, _ := user.NewProc("MessageBoxW").Call(0, uintptr(unsafe.Pointer(p)), uintptr(unsafe.Pointer(t)), style)
	return int(ret)
}
func isAdmin() bool { r, _, _ := shell.NewProc("IsUserAnAdmin").Call(); return r != 0 }
func requireAdmin(extra string) error {
	if isAdmin() {
		return nil
	}
	self, e := os.Executable()
	if e != nil {
		return e
	}
	verb, _ := syscall.UTF16PtrFromString("runas")
	path, _ := syscall.UTF16PtrFromString(self)
	args, _ := syscall.UTF16PtrFromString(extra)
	r, _, err := shell.NewProc("ShellExecuteW").Call(0, uintptr(unsafe.Pointer(verb)), uintptr(unsafe.Pointer(path)), uintptr(unsafe.Pointer(args)), 0, 1)
	if r <= 32 {
		return fmt.Errorf("se rechazó elevación UAC: %v", err)
	}
	return errSpawned
}

var errSpawned = errors.New("secondary elevated process launched")

func statePath() (string, error) {
	base := os.Getenv("ProgramData")
	if base == "" || !filepath.IsAbs(base) {
		return "", errors.New("ProgramData no disponible")
	}
	return filepath.Join(base, stateDirName, "estado.json"), nil
}
func loadState() (receipt, error) {
	var r receipt
	p, e := statePath()
	if e != nil {
		return r, e
	}
	b, e := os.ReadFile(p)
	if e != nil {
		return r, e
	}
	if len(b) > 100000 {
		return r, errors.New("registro de bloqueo excesivo")
	}
	if e = json.Unmarshal(b, &r); e != nil {
		return r, e
	}
	if (r.Version != version && r.Version != "0.19.0" && r.Version != "0.20.0" && r.Version != "0.21.0" && r.Version != "0.22.0" && r.Version != "0.23.0" && r.Version != "0.23.1" && r.Version != "0.23.2" && r.Version != "0.24.0" && r.Version != "0.24.1" && r.Version != "0.25.0" && r.Version != "0.26.0" && r.Version != "0.26.1" && r.Version != "0.26.2" && r.Version != "0.26.3" && r.Version != "0.26.4" && r.Version != "0.27.0" && r.Version != "0.27.2" && r.Version != "0.27.3" && r.Version != "0.27.5" && r.Version != "0.28.0" && r.Version != "0.28.1" && r.Version != "0.28.3" && r.Version != "0.28.4") || len(r.Entries) > 1000 || (r.Status != "pending" && r.Status != "active" && r.Status != "restoring") {
		return r, errors.New("estado desconocido: no se modificará")
	}
	for _, v := range r.Entries {
		if !allowedKey(v.Key) || !validValue(v.Value) || !validSlot(v.Name) {
			return r, errors.New("estado contiene política desconocida: no se modificará")
		}
	}
	return r, nil
}
func validValue(v string) bool {
	all, _ := policyEntries()
	for _, e := range all {
		if e.Value == v {
			return true
		}
	}
	return false
}
func allowedKey(k string) bool {
	return k == `HKLM\SOFTWARE\Policies\Google\Chrome\URLBlocklist` || k == `HKLM\SOFTWARE\Policies\Microsoft\Edge\URLBlocklist` || k == `HKLM\SOFTWARE\Policies\Mozilla\Firefox\WebsiteFilter\Block`
}
func validSlot(v string) bool { n, e := strconv.Atoi(v); return e == nil && n >= 1 && n <= 1000 }
func saveState(r receipt) error {
	p, e := statePath()
	if e != nil {
		return e
	}
	if e = os.MkdirAll(filepath.Dir(p), 0700); e != nil {
		return e
	}
	b, e := json.MarshalIndent(r, "", "  ")
	if e != nil {
		return e
	}
	f, e := os.CreateTemp(filepath.Dir(p), ".estado-")
	if e != nil {
		return e
	}
	defer os.Remove(f.Name())
	if _, e = f.Write(b); e != nil {
		f.Close()
		return e
	}
	if e = f.Sync(); e != nil {
		f.Close()
		return e
	}
	if e = f.Close(); e != nil {
		return e
	}
	return os.Rename(f.Name(), p)
}

func reg(args ...string) (string, error) {
	c := hiddenCommand("reg.exe", args...)
	o, e := c.CombinedOutput()
	if len(o) > 256000 {
		return "", errors.New("respuesta Registro demasiado grande")
	}
	return string(o), e
}
func usedSlots(k string) (map[int]bool, error) {
	out, e := reg("query", k)
	if e != nil {
		lower := strings.ToLower(out)
		// On a fresh PC the policy path normally does not exist.
		if strings.Contains(lower, "unable to find") || strings.Contains(lower, "no ha podido encontrar") || strings.Contains(lower, "no se encuentra") || strings.Contains(lower, "not found") || strings.Contains(lower, "no se encontró") {
			return map[int]bool{}, nil
		}
		return nil, fmt.Errorf("no pude leer %s: %s", k, strings.TrimSpace(out))
	}
	used := map[int]bool{}
	for _, line := range strings.Split(out, "\n") {
		parts := strings.Fields(line)
		if len(parts) > 1 && strings.HasPrefix(strings.ToUpper(parts[1]), "REG_") {
			n, err := strconv.Atoi(parts[0])
			if err == nil && n > 0 {
				used[n] = true
			}
		}
	}
	return used, nil
}
func getRegValue(k, name string) (string, bool, error) {
	out, e := reg("query", k, "/v", name)
	if e != nil {
		lower := strings.ToLower(out)
		if strings.Contains(lower, "unable to find") || strings.Contains(lower, "no ha podido encontrar") || strings.Contains(lower, "no se encuentra") || strings.Contains(lower, "not found") || strings.Contains(lower, "no se encontró") {
			return "", false, nil
		}
		return "", false, fmt.Errorf("no pude comprobar si existe la política %s/%s: %s", k, name, strings.TrimSpace(out))
	}
	for _, line := range strings.Split(out, "\n") {
		fields := strings.Fields(line)
		if len(fields) >= 3 && fields[0] == name && fields[1] == "REG_SZ" {
			return strings.Join(fields[2:], " "), true, nil
		}
	}
	return "", false, fmt.Errorf("unexpected registry value format for %s", name)
}
func addValue(e entry) error {
	out, err := reg("add", e.Key, "/v", e.Name, "/t", "REG_SZ", "/d", e.Value, "/f")
	if err != nil {
		return fmt.Errorf("no se pudo escribir %s (%s): %w", e.Key, strings.TrimSpace(out), err)
	}
	return nil
}
func delValue(e entry) error {
	val, ok, err := getRegValue(e.Key, e.Name)
	if err != nil {
		return err
	}
	if !ok {
		return nil
	}
	if val != e.Value {
		return fmt.Errorf("no borrar: %s\\%s fue modificado por otro administrador", e.Key, e.Name)
	}
	out, err := reg("delete", e.Key, "/v", e.Name, "/f")
	if err != nil {
		return fmt.Errorf("no pude borrar %s: %w (%s)", e.Key, err, strings.TrimSpace(out))
	}
	return nil
}

// A failed 0.22.0 install left the receipt in pending after browser policies
// and hosts were applied. Repair without allocating duplicate slots or
// overwriting a third party's registry values.
func resumeInterrupted(r receipt) error {
	for _, v := range r.Entries {
		value, exists, er := getRegValue(v.Key, v.Name)
		if er != nil {
			return er
		}
		if exists && value != v.Value {
			return fmt.Errorf("la regla %s/%s cambió, no se sobrescribe", v.Key, v.Name)
		}
		if !exists {
			if er = addValue(v); er != nil {
				return fmt.Errorf("no se pudo completar política registrada %s/%s: %w", v.Key, v.Name, er)
			}
			v2, exists2, er := getRegValue(v.Key, v.Name)
			if er != nil || !exists2 || v2 != v.Value {
				return fmt.Errorf("la regla reparada %s/%s no se verifica: %v", v.Key, v.Name, er)
			}
		}
	}
	if err := installHosts(); err != nil {
		return fmt.Errorf("no se pudo reanudar hosts: %w", err)
	}
	if err := installCatalogMotor(); err != nil {
		return fmt.Errorf("no se pudo reanudar catálogo: %w", err)
	}
	if err := applyDoH(); err != nil {
		return fmt.Errorf("no se pudo completar DoH: %w", err)
	}
	r.Version = version
	r.Status = "active"
	return saveState(r)
}

func install() error {
	if !isAdmin() {
		return errors.New("se requieren permisos de administrador")
	}
	if r, e := loadState(); e == nil {
		if r.Status == "pending" {
			// Applicable to the 0.22.0 failure shown in Windows screenshots.
			return resumeInterrupted(r)
		}
		if r.Status == "active" && (r.Version == "0.22.0" || r.Version == "0.23.0" || r.Version == "0.23.1" || r.Version == "0.23.2" || r.Version == "0.24.0" || r.Version == "0.24.1" || r.Version == "0.25.0" || r.Version == "0.26.0" || r.Version == "0.26.1" || r.Version == "0.26.2" || r.Version == "0.26.3" || r.Version == "0.26.4") {
			if err := installCatalogMotor(); err != nil {
				return fmt.Errorf("falló comprobación del catálogo heredado: %w", err)
			}
			if err := applyDoH(); err != nil {
				return err
			}
			r.Version = version
			return saveState(r)
		}
		if r.Status == "active" && r.Version == "0.21.0" {
			if err := installCatalogMotor(); err != nil {
				return fmt.Errorf("el actualizador original falló: %w", err)
			}
			if err := applyDoH(); err != nil {
				return fmt.Errorf("no se pudieron reforzar políticas de DNS seguro: %w", err)
			}
			r.Version = version
			return saveState(r)
		}
		if r.Status == "active" && r.Version == "0.20.0" {
			if err := installCatalogMotor(); err != nil {
				return fmt.Errorf("no se pudo actualizar el motor del catálogo: %w", err)
			}
			if err := applyDoH(); err != nil {
				return fmt.Errorf("falló política DoH: %w", err)
			}
			r.Version = version
			return saveState(r)
		}
		if r.Status == "active" && r.Version == "0.19.0" {
			// Upgrade in place without deleting or duplicating the existing browser policies.
			r.Status, r.Version = "pending", version
			if er := saveState(r); er != nil {
				return er
			}
			if er := installHosts(); er != nil {
				return fmt.Errorf("no se pudo ampliar a bloqueo del sistema: %w; ejecutá --uninstall para restaurar", er)
			}
			r.Status = "active"
			if er := installCatalogMotor(); er != nil {
				return fmt.Errorf("protección de navegadores y hosts actualizada, pero falló actualización del catálogo: %w", er)
			}
			if er := applyDoH(); er != nil {
				return fmt.Errorf("falló política DoH: %w", er)
			}
			return saveState(r)
		}
		if r.Status == "active" && r.Version == version {
			if err := installCatalogMotor(); err != nil {
				return err
			}
			return applyDoH()
		}
		if r.Status == "active" {
			return errors.New("VOLVÉ ya está activo. Usá --inspect para comprobar la protección.")
		}
		return errors.New("hay una operación incompleta. Usá --uninstall para recuperar antes de instalar")
	} else if !errors.Is(e, os.ErrNotExist) {
		return fmt.Errorf("estado ilegible; no se sobrescribe: %w", e)
	}
	requests, e := policyEntries()
	if e != nil {
		return e
	}
	occupied := map[string]map[int]bool{}
	for _, entry := range requests {
		if _, ok := occupied[entry.Key]; !ok {
			slots, e := usedSlots(entry.Key)
			if e != nil {
				return e
			}
			occupied[entry.Key] = slots
		}
	}
	var prepared []entry
	for _, e := range requests {
		n := 0
		for i := 1; i <= 1000; i++ {
			if !occupied[e.Key][i] {
				n = i
				occupied[e.Key][i] = true
				break
			}
		}
		if n == 0 {
			return fmt.Errorf("no hay espacio para reglas en %s", e.Key)
		}
		e.Name = strconv.Itoa(n)
		prepared = append(prepared, e)
	}
	// Preserve enough data to safely restore even after an interrupted install.
	r := receipt{Version: version, Status: "pending", Entries: prepared}
	if e = saveState(r); e != nil {
		return e
	}
	for _, e := range prepared {
		// Recheck before every write: never overwrite another administrator's policy.
		existing, ok, er := getRegValue(e.Key, e.Name)
		if er != nil {
			return er
		}
		if ok {
			return fmt.Errorf("colisión en Registro %s\\%s (%s): restaurá las reglas VOLVÉ", e.Key, e.Name, existing)
		}
		if er = addValue(e); er != nil {
			return fmt.Errorf("instalación parcial: %w. Abrí de nuevo y elegí Restaurar", er)
		}
		written, found, er := getRegValue(e.Key, e.Name)
		if er != nil || !found || written != e.Value {
			return fmt.Errorf("no se pudo verificar la nueva regla %s/%s: %v. Elegí Restaurar", e.Key, e.Name, er)
		}
	}
	// Apply a conservative OS-wide resolver layer, after recording all browser changes.
	if e = installHosts(); e != nil {
		return fmt.Errorf("las políticas de navegadores se aplicaron, pero falló hosts: %w. Usá --uninstall para restaurar", e)
	}
	if e = installCatalogMotor(); e != nil {
		return fmt.Errorf("políticas y hosts aplicados, pero falló la instalación del motor de catálogo: %w", e)
	}
	if e = applyDoH(); e != nil {
		return fmt.Errorf("las reglas se aplicaron, pero falló refuerzo DoH: %w; ejecutá --uninstall para restaurar", e)
	}
	r.Status = "active"
	if e = saveState(r); e != nil {
		return fmt.Errorf("reglas aplicadas, pero no se pudo registrar estado final: %w", e)
	}
	return nil
}
func uninstall() error {
	if active, e := journalExists(); e != nil {
		return e
	} else if active {
		return errors.New("restaurá primero el DNS automático mediante el BAT de emergencia o botón RECUPERAR DNS")
	}
	if !isAdmin() {
		return errors.New("se requieren permisos de administrador")
	}
	r, e := loadState()
	if errors.Is(e, os.ErrNotExist) {
		return errors.New("no hay una instalación VOLVÉ registrada")
	}
	if e != nil {
		return e
	}
	r.Status = "restoring"
	if e = saveState(r); e != nil {
		return e
	}
	if err := restoreDoH(); err != nil {
		return fmt.Errorf("no se pudieron restaurar políticas DoH: %w", err)
	}
	if r.Version == version || r.Version == "0.21.0" {
		if err := removeCatalogMotor(); err != nil {
			return fmt.Errorf("restauración detenida, tarea de catálogo aún presente: %w", err)
		}
	}
	var failures []string
	if r.Version == version || r.Version == "0.21.0" || r.Version == "0.20.0" {
		if er := restoreHosts(); er != nil {
			// If hosts was edited, do not remove browser protection and claim success.
			return fmt.Errorf("no se pudo restaurar hosts: %w", er)
		}
	}
	for i := len(r.Entries) - 1; i >= 0; i-- {
		if er := delValue(r.Entries[i]); er != nil {
			failures = append(failures, er.Error())
		}
	}
	if len(failures) > 0 {
		return errors.New("restauración incompleta; se conservaron los datos de recuperación: " + strings.Join(failures, "; "))
	}
	p, e := statePath()
	if e != nil {
		return e
	}
	if e = os.Remove(p); e != nil {
		return e
	}
	_ = os.Remove(filepath.Join(filepath.Dir(p), "hosts.before-0200.bak"))
	_ = os.Remove(filepath.Dir(p))
	return nil
}
func inspect() (string, error) {
	r, e := loadState()
	if e != nil {
		return "SIN INSTALAR", e
	}
	ok := 0
	problems := []string{}
	// Read each browser policy key only ONCE. The previous panel spawned
	// 160 individual reg.exe processes on every refresh.
	policyKeys := map[string]bool{}
	for _, v := range r.Entries {
		policyKeys[v.Key] = true
	}
	policyValues := make(map[string]map[string]string, len(policyKeys))
	for key := range policyKeys {
		out, queryErr := reg("query", key)
		if queryErr == nil {
			policyValues[key] = parseRegStringValues(out)
		} else if isRegMissing(out) {
			policyValues[key] = map[string]string{}
		} else {
			problems = append(problems, "No se pudo consultar "+key+": "+strings.TrimSpace(out))
		}
	}
	for _, v := range r.Entries {
		if values, exists := policyValues[v.Key]; exists && values[v.Name] == v.Value {
			ok++
		} else {
			problems = append(problems, v.Key+"/"+v.Name)
		}
	}
	status := fmt.Sprintf("Estado: %s\nReglas registradas: %d\nReglas comprobadas: %d\n", r.Status, len(r.Entries), ok)
	if len(problems) > 0 {
		sort.Strings(problems)
		status += "Hay reglas faltantes o modificadas.\n"
	}
	hostState, hostErr := verifyHosts()
	status += "\nBloqueo del sistema (hosts): " + hostState + "\n"
	if hostErr != nil {
		status += "Error en hosts: " + hostErr.Error() + "\n"
	}
	status += catalogStatusText()
	status += catalogTaskStatusText()
	status += dohStatusText()
	status += "Bloqueo complementario: políticas Chrome, Edge y Firefox.\n"
	status += dnsStatus()
	status += "VPN, DoH y aplicaciones con DNS propio pueden eludir el filtrado.\n"
	return status, nil
}
func main() {
	if len(os.Args) == 2 && os.Args[1] == "--install-browser-addons" {
		if !isAdmin() {
			if e := requireAdmin("--install-browser-addons"); e != nil && !errors.Is(e, errSpawned) {
				msg("No se concedió permiso: "+e.Error(), MB_ICONERROR)
			}
			return
		}
		result, e := installBrowserAddons()
		if e != nil {
			msg("Complementos no preparados: "+e.Error(), MB_ICONERROR)
		} else {
			msg(result, MB_ICONINFORMATION)
		}
		return
	}
	if len(os.Args) == 2 && os.Args[1] == "--browser-addons-status" {
		fmt.Println(browserStatus())
		return
	}

	if len(os.Args) == 2 && os.Args[1] == "--check-motor-updates" {
		report, err := checkMotorUpdatePilot()
		if err != nil {
			fmt.Println("ACTUALIZADOR DE MOTOR NO DISPONIBLE:", err)
			os.Exit(1)
		}
		fmt.Println(report)
		return
	}
	if len(os.Args) == 2 && os.Args[1] == "--check-app-updates" {
		result, err := checkAndStageUpdate()
		if err != nil {
			fmt.Println("ACTUALIZACIÓN NO REALIZADA:", err)
			os.Exit(1)
		}
		fmt.Println(result)
		return
	}
	if len(os.Args) == 3 && os.Args[1] == "--apply-staged-panel-update" {
		if !isAdmin() {
			msg("Esta actualización requiere permiso administrativo. No se realizaron cambios.", MB_ICONERROR)
			return
		}
		if e := installVerifiedStagedPanel(os.Args[2]); e != nil {
			msg("No se completó la actualización del Centro de protección: "+e.Error(), MB_ICONERROR)
		} else {
			msg("Centro de protección actualizado y acceso directo preparado.\n\nCerrá este panel y abrí VOLVÉ desde el escritorio o menú Inicio.\nEl motor DNS no se modificó.", MB_ICONINFORMATION)
		}
		return
	}
	if len(os.Args) == 2 && os.Args[1] == "--install-panel-only" {
		if !isAdmin() {
			e := requireAdmin("--install-panel-only")
			if errors.Is(e, errSpawned) {
				return
			}
			msg("No se autorizó instalar el nuevo panel: "+e.Error(), MB_ICONERROR)
			return
		}
		if e := installPanelShortcut(); e != nil {
			msg("No se instaló el panel: "+e.Error(), MB_ICONERROR)
		} else {
			msg("Centro de protección actualizado. El motor DNS y sus reglas NO cambiaron.", MB_ICONINFORMATION)
		}
		return
	}

	if len(os.Args) == 2 && os.Args[1] == "--dns-service" {
		if e := runDNSService(); e != nil {
			fmt.Fprintln(os.Stderr, "VOLVE DNS service failed:", e)
			os.Exit(1)
		}
		return
	}
	if len(os.Args) == 2 && (os.Args[1] == "--install-all" || os.Args[1] == "--dns-activate" || os.Args[1] == "--dns-restore") {
		mode := os.Args[1]
		if !isAdmin() {
			e := requireAdmin(mode)
			if errors.Is(e, errSpawned) {
				return
			}
			msg("Se requiere administrador: "+e.Error(), MB_ICONERROR)
			return
		}
		if mode == "--dns-restore" {
			if e := restoreDNS(); e != nil {
				msg("RESTABLECIMIENTO NO CONFIRMADO: "+e.Error(), MB_ICONERROR)
			} else {
				msg("DNS automático restablecido y comprobado.", MB_ICONINFORMATION)
			}
			return
		}
		if mode == "--install-all" {
			if e := install(); e != nil {
				msg("Instalación base incompleta: "+e.Error(), MB_ICONERROR)
				return
			}
			if e := installPanelShortcut(); e != nil {
				msg("No pude instalar el panel: "+e.Error(), MB_ICONERROR)
				return
			}
		}
		if e := activateDNS(); e != nil {
			msg("DNS NO ACTIVADO O REVERTIDO: "+e.Error()+"\n\nUsá el BAT de rescate si observás problemas de Internet.", MB_ICONERROR)
		} else {
			msg("Motor DNS activado. Consultas locales verificadas. Conservar BAT de rescate.\n\nNo se garantiza bloqueo frente a VPN o DNS propio.", MB_ICONINFORMATION)
			if mode == "--install-all" {
				offerBrowserAddonsDuringInstall()
			}
		}
		return
	}
	if len(os.Args) == 2 && os.Args[1] == "--repair-rescue-task" {
		if !isAdmin() {
			e := requireAdmin("--repair-rescue-task")
			if errors.Is(e, errSpawned) {
				return
			}
			msg("No se concedió administrador: "+e.Error(), MB_ICONERROR)
			return
		}
		result, e := repairRescueTask()
		if e != nil {
			msg("RESCATE NO REPARADO: "+e.Error(), MB_ICONERROR)
		} else {
			msg(result, MB_ICONINFORMATION)
		}
		return
	}
	if len(os.Args) == 2 && os.Args[1] == "--dns-recovery-rehearsal" {
		programData := os.Getenv("ProgramData")
		if programData == "" || !filepath.IsAbs(programData) {
			fmt.Println("ENSAYO NO APROBADO: ProgramData no disponible. No se modificó Windows.")
			os.Exit(2)
		}
		// This command performs only read-only adapter inventory, an ephemeral
		// loopback:53 motor test, and a rollback against a simulated adapter.
		report, err := dnsrollout.Rehearse(filepath.Join(programData, stateDirName, "catalog"), 400000)
		fmt.Println(report)
		if err != nil {
			os.Exit(1)
		}
		return
	}
	if len(os.Args) == 2 && os.Args[1] == "--dns-preflight" {
		programData := os.Getenv("ProgramData")
		if programData == "" || !filepath.IsAbs(programData) {
			fmt.Println("PRUEBA DNS NO EJECUTADA: ProgramData no disponible. No se modificó DNS de Windows.")
			os.Exit(2)
		}
		r, err := dnspreflight.Verify(filepath.Join(programData, stateDirName, "catalog"), 400000)
		if err != nil {
			fmt.Println("PRUEBA DNS NO APROBADA: " + err.Error() + "\nNo se modificó DNS de Windows.")
			os.Exit(1)
		}
		fmt.Println(r.String())
		return
	}
	if len(os.Args) == 2 && os.Args[1] == "--sample-100" {
		r, e := sampleLiveDNS()
		fmt.Print(r)
		if e != nil {
			fmt.Println("PRUEBA INCOMPLETA:", e)
			os.Exit(1)
		}
		return
	}
	// Elevated diagnostic uses a second, read-only panel. It inherits the
	// administrator token solely for reading the SYSTEM-protected rescue journal.
	// No permissions are loosened and no installation or DNS mutation occurs.
	if len(os.Args) == 2 && os.Args[1] == "--healthcheck-admin" {
		if !isAdmin() {
			e := requireAdmin("--healthcheck-admin")
			if errors.Is(e, errSpawned) {
				return
			}
			msg("No se pudo autorizar el diagnóstico administrativo: "+e.Error(), MB_ICONERROR)
			return
		}
		healthOnlyPanel = true
		showPanel()
		return
	}
	if len(os.Args) == 2 && os.Args[1] == "--healthcheck" {
		s, e := reportProtectionHealth()
		fmt.Print(s)
		if e != nil {
			fmt.Println("DIAGNÓSTICO INCOMPLETO:", e)
			os.Exit(1)
		}
		return
	}
	if len(os.Args) == 2 && os.Args[1] == "--panel-report" {
		// Restricted internal status channel used by the graphical panel.
		// Never mutates policy, DNS, tasks or hosts.
		fmt.Print(panelStatus())
		return
	}
	if len(os.Args) == 2 && os.Args[1] == "--inspect" {
		s, e := inspect()
		_ = json.NewEncoder(os.Stdout).Encode(map[string]any{"version": version, "state": s, "error": fmt.Sprint(e)})
		if e != nil {
			os.Exit(1)
		}
		return
	}
	if len(os.Args) == 2 && (os.Args[1] == "--doctor" || os.Args[1] == "--doctor-admin") {
		if os.Args[1] == "--doctor-admin" && !isAdmin() {
			e := requireAdmin("--doctor-admin")
			if errors.Is(e, errSpawned) {
				return
			}
			msg("No se pudo abrir el diagnóstico elevado: "+e.Error(), MB_ICONERROR)
			return
		}
		s, e := inspect()
		if e != nil {
			s += "\nAtención: " + e.Error()
		}
		msg(s, MB_ICONINFORMATION)
		return
	}
	if len(os.Args) == 2 && os.Args[1] == "--selftest" {
		p, e := policyEntries()
		if e != nil || len(p) != len(domains)*4 || len(dohSpecs()) != 4 {
			os.Exit(1)
		}
		return
	}
	if len(os.Args) == 2 && (os.Args[1] == "--install" || os.Args[1] == "--uninstall") {
		mode := os.Args[1]
		if !isAdmin() {
			e := requireAdmin(mode)
			if errors.Is(e, errSpawned) {
				return
			}
			msg("No se pudo solicitar permiso:\n"+e.Error(), MB_ICONERROR)
			os.Exit(1)
		}
		var e error
		if mode == "--install" {
			e = install()
		} else {
			e = uninstall()
		}
		if e != nil {
			msg("ERROR:\n"+e.Error(), MB_ICONERROR)
			os.Exit(1)
		}
		if mode == "--install" {
			if panelErr := installPanelShortcut(); panelErr != nil {
				msg("La protección se aplicó, pero no pude crear el acceso directo al panel: "+panelErr.Error()+"\nPodés seguir abriendo el EXE descargado para usar el panel.", MB_ICONERROR)
			}
			msg("VOLVÉ aplicó o verificó las reglas propias. La tarea horaria fue registrada/comprobada y se solicitó una ejecución.\n\n"+catalogStatusText()+"\nPara saber si el DNS protege realmente la red, abrí Diagnóstico admin y verificá la sección «DNS real».", MB_ICONINFORMATION)
		} else {
			msg("Se restauraron las reglas y entradas hosts de VOLVÉ, conservando las ajenas.", MB_ICONINFORMATION)
		}
		return
	}
	if len(os.Args) == 2 && os.Args[1] == "--refresh-catalog" {
		if !isAdmin() {
			e := requireAdmin("--refresh-catalog")
			if errors.Is(e, errSpawned) {
				return
			}
			msg("No se pudo solicitar permiso de administrador: "+e.Error(), MB_ICONERROR)
			return
		}
		exe, e := motorLocation()
		if e == nil {
			if _, er := os.Stat(exe); er != nil {
				e = er
			}
		}
		if e != nil {
			msg("El actualizador de catálogo no está instalado: "+e.Error(), MB_ICONERROR)
			return
		}
		out, e := hiddenCommand(exe, "--refresh").CombinedOutput()
		if e != nil {
			msg("No se pudo actualizar el catálogo: "+e.Error()+"\n"+string(out), MB_ICONERROR)
		} else {
			msg("Tarea de actualización ejecutada. El motor residente comprueba los cambios del catálogo periódicamente.\n\n"+catalogStatusText()+"\n"+dnsStatus()+"\nPara una verificación real pulsá Comprobar protección REAL desde el panel.", MB_ICONINFORMATION)
		}
		return
	}
	if len(os.Args) != 1 && !(len(os.Args) == 2 && os.Args[1] == "--panel") {
		msg("Opciones disponibles: --install-all / --dns-restore / --dns-activate / --panel / --install / --doctor-admin / --refresh-catalog / --inspect / --selftest / --uninstall", MB_ICONINFORMATION)
		return
	}
	showPanel()
}
