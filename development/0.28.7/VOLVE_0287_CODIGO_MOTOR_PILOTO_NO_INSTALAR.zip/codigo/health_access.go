package main

import (
	"errors"
	"os"
)

// protectedJournalRead is true only for a permissions error, including errors
// wrapped in *PathError. Never change an ACL or infer the DNS protection state.
func protectedJournalRead(err error) bool {
	return errors.Is(err, os.ErrPermission)
}
