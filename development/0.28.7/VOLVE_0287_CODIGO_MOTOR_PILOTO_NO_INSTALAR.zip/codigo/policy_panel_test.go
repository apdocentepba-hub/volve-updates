package main

import "testing"

func TestParseRegStringValues(t *testing.T) {
	raw := "\r\nHKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Google\\Chrome\\URLBlocklist\r\n    1    REG_SZ    stake.com\r\n    2    REG_SZ    *://example.com/*\r\n   \r\n"
	got := parseRegStringValues(raw)
	if len(got) != 2 || got["1"] != "stake.com" || got["2"] != "*://example.com/*" {
		t.Fatalf("incorrect policy parsing: %#v", got)
	}
}
func TestParseRegStringValuesMissingAndUnknown(t *testing.T) {
	got := parseRegStringValues("ERROR: The system was unable to find the specified registry key or value.\n 5 REG_DWORD 0x1")
	if len(got) != 0 {
		t.Fatalf("must reject non-string values: %#v", got)
	}
}
