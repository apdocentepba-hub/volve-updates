package main

import (
	"strings"
	"testing"
)

func TestPartialCatalogNeverReportsFull(t *testing.T) {
	examples := []string{
		`{"catalog_domains":64251,"last_check":"2026-10-28T23:41:06Z","warnings":[]}`,
		`{"catalog_domains":64251,"last_check":"2026-10-28T23:41:06Z","warnings":[],"sources":[{"id":"hagezi_gambling_full","domains":0}]}`,
		`{"catalog_domains":615861,"sources":[{"id":"hagezi_gambling_full","domains":10000}]}`,
	}
	for _, e := range examples {
		got := formatCatalogReport([]byte(e))
		if !strings.Contains(got, "incompleto/no acreditado") {
			t.Fatalf("partial accepted: %s", got)
		}
	}
}
func TestCatalogCountDoesNotImplyActiveDNS(t *testing.T) {
	got := formatCatalogReport([]byte(`{"catalog_domains":616000,"sources":[{"id":"hagezi_gambling_full","domains":615861}],"warnings":[]}`))
	if !strings.Contains(got, "no demuestra por sí sola") {
		t.Fatal(got)
	}
}
func TestRejectBadCatalogReport(t *testing.T) {
	for _, b := range []string{"", "not json", `{"catalog_domains":-1}`} {
		if !strings.Contains(formatCatalogReport([]byte(b)), "no confirmado") && !strings.Contains(formatCatalogReport([]byte(b)), "NO asumir") {
			t.Fatal(b)
		}
	}
}
