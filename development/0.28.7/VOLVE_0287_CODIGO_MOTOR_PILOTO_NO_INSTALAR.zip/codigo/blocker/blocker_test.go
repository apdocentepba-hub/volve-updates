package blocker

import (
	"strings"
	"testing"
)

func TestWildcardAndSafelist(t *testing.T) {
	e := New([]string{"betwarrior.bet.ar", "stake.com", "citycenteronline.bet.ar", "google.com"}, true)
	blocked := []string{"bet.ar", "pba.stake.bet.ar", "anything.newcasino.bet.ar", "x.y.betwarrior.bet.ar", "play.stake.com", "m.citycenteronline.bet.ar"}
	for _, d := range blocked {
		if ok, _ := e.Match(d); !ok {
			t.Errorf("NOT blocked: %s", d)
		}
	}
	allowed := []string{"www.google.com", "jugadoresanonimos.org.ar", "salud.gob.ar", "example.org", "bet.ar.fake.com", "stake.com.fake.org", "casino.edu.ar"}
	for _, d := range allowed {
		if ok, _ := e.Match(d); ok {
			t.Errorf("FALSE POSITIVE: %s", d)
		}
	}
}
func TestParseFeed(t *testing.T) {
	src := "# header\n0.0.0.0 a.casino.com b.casino.com\n||casino.bet.ar^\n*.casino-bet.co\naddress=/casino.win/0.0.0.0\nnot a rule!!!\n"
	a, e := Parse(strings.NewReader(src), 10)
	if e != nil {
		t.Fatal(e)
	}
	if len(a) != 5 {
		t.Fatalf("want 5 domains got %d: %v", len(a), a)
	}
}
func TestRejectOversize(t *testing.T) {
	_, e := Parse(strings.NewReader("a.com\nb.com\nc.com\n"), 2)
	if e == nil {
		t.Fatal("oversize feed accepted")
	}
}
func TestNameValidation(t *testing.T) {
	for _, d := range []string{"https://casino.com/path", "-bad.com", "a..com", "google.com:443", " casino.com "} {
		if d == " casino.com " {
			if Normalize(d) != "casino.com" {
				t.Fatal("trim")
			}
		} else if Normalize(d) != "" {
			t.Fatal(d)
		}
	}
}
