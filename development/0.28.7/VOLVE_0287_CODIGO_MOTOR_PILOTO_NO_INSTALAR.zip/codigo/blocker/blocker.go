package blocker

import (
	"bufio"
	"fmt"
	"io"
	"sort"
	"strings"
)

// Engine supports exact names and entire DNS suffixes (including new subdomains).
// Its immutable map can be exchanged atomically by the caller after an update.
type Engine struct {
	suffixes map[string]struct{}
	safe     map[string]struct{}
}

// These are shared suffixes, not individual betting operators. A compromised
// feed must never block an entire country or a public registration zone.
var sharedRegistrationZones = map[string]struct{}{
	"com.ar": {}, "org.ar": {}, "net.ar": {}, "com.br": {},
	"com.mx": {}, "com.au": {}, "net.au": {}, "co.uk": {},
	"co.jp": {}, "co.nz": {}, "co.za": {}, "co.in": {},
	"com.tr": {}, "com.ua": {}, "co.kr": {},
}

var defaultSafelist = []string{
	"gob.ar", "gov.ar", "edu.ar", "who.int", "gamblersanonymous.org",
	"jugadoresanonimos.org.ar", "google.com", "microsoft.com",
	"github.com", "mozilla.org", "cloudflare.com", "example.org",
}

func Normalize(host string) string {
	host = strings.TrimSuffix(strings.ToLower(strings.TrimSpace(host)), ".")
	if len(host) < 4 || len(host) > 253 || !strings.Contains(host, ".") {
		return ""
	}
	for _, part := range strings.Split(host, ".") {
		if len(part) == 0 || len(part) > 63 || part[0] == '-' || part[len(part)-1] == '-' {
			return ""
		}
		for _, r := range part {
			if r < 'a' || r > 'z' {
				if r < '0' || r > '9' {
					if r != '-' {
						return ""
					}
				}
			}
		}
	}
	return host
}

func suffixContains(set map[string]struct{}, host string) (string, bool) {
	for s := host; s != ""; {
		if _, ok := set[s]; ok {
			return s, true
		}
		p := strings.IndexByte(s, '.')
		if p < 0 {
			break
		}
		s = s[p+1:]
	}
	return "", false
}

func New(domains []string, globalBetAR bool) *Engine {
	e := &Engine{suffixes: make(map[string]struct{}, len(domains)+1), safe: make(map[string]struct{}, len(defaultSafelist))}
	for _, d := range defaultSafelist {
		e.safe[d] = struct{}{}
	}
	for _, d := range domains {
		if d = Normalize(d); d != "" {
			if _, tooBroad := sharedRegistrationZones[d]; tooBroad {
				continue
			}
			if _, protected := suffixContains(e.safe, d); !protected {
				e.suffixes[d] = struct{}{}
			}
		}
	}
	if globalBetAR {
		e.suffixes["bet.ar"] = struct{}{}
	}
	return e
}

func (e *Engine) Match(host string) (blocked bool, matched string) {
	host = Normalize(host)
	if host == "" {
		return false, ""
	}
	if _, safe := suffixContains(e.safe, host); safe {
		return false, ""
	}
	matched, blocked = suffixContains(e.suffixes, host)
	return
}
func (e *Engine) Len() int { return len(e.suffixes) }
func (e *Engine) Sorted() []string {
	s := make([]string, 0, len(e.suffixes))
	for k := range e.suffixes {
		s = append(s, k)
	}
	sort.Strings(s)
	return s
}

// Parse understands hosts, plain domain, HaGeZi wildcard-domain, and Adblock entries.
// Broad unrelated blocklist syntaxes are deliberately rejected.
func Parse(r io.Reader, max int) ([]string, error) {
	if max < 1 || max > 1100000 {
		return nil, fmt.Errorf("invalid feed entry limit")
	}
	scan := bufio.NewScanner(r)
	scan.Buffer(make([]byte, 64*1024), 8*1024*1024)
	seen := make(map[string]struct{})
	for scan.Scan() {
		line := strings.TrimSpace(scan.Text())
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "!") {
			continue
		}
		if n := strings.IndexByte(line, '#'); n >= 0 {
			line = strings.TrimSpace(line[:n])
		}
		if strings.HasPrefix(line, "||") {
			line = strings.TrimPrefix(line, "||")
			if pos := strings.IndexAny(line, "^/$"); pos >= 0 {
				line = line[:pos]
			}
		} else if strings.HasPrefix(line, "*.") {
			line = strings.TrimPrefix(line, "*.")
		} else if strings.HasPrefix(line, "* ") {
			line = strings.TrimSpace(strings.TrimPrefix(line, "* "))
		} else if strings.HasPrefix(line, "address=/") {
			// DNSMasq address=/domain.tld/0.0.0.0
			fields := strings.Split(line, "/")
			if len(fields) >= 3 {
				line = fields[1]
			}
		} else if strings.ContainsAny(line, " \t") {
			fields := strings.Fields(line)
			if len(fields) < 2 {
				continue
			}
			if fields[0] != "0.0.0.0" && fields[0] != "127.0.0.1" && fields[0] != "::1" {
				continue
			}
			for _, f := range fields[1:] {
				if d := Normalize(f); d != "" {
					seen[d] = struct{}{}
				}
			}
			if len(seen) > max {
				return nil, fmt.Errorf("feed exceeds %d domains", max)
			}
			continue
		}
		if d := Normalize(line); d != "" {
			seen[d] = struct{}{}
		}
		if len(seen) > max {
			return nil, fmt.Errorf("feed exceeds %d domains", max)
		}
	}
	if e := scan.Err(); e != nil {
		return nil, e
	}
	result := make([]string, 0, len(seen))
	for d := range seen {
		result = append(result, d)
	}
	sort.Strings(result)
	return result, nil
}
