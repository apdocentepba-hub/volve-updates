package blocker

import "testing"

// Regression test for the gambling operators observed to bypass v0.5.x.
func TestRealisticArgentineCoverage(t *testing.T) {
	engine := New([]string{"stake.com"}, true)
	blocked := []string{
		"citycenteronline.bet.ar", "casinobuenosairesonline.bet.ar",
		"deportespba.bplay.bet.ar", "pba.sports.bet.ar", "pba.stake.bet.ar", "mza.sports.bet.ar",
		"pba.betsson.bet.ar", "increible-nuevo-operador.bet.ar", "a.b.casino.bet.ar",
	}
	for _, name := range blocked {
		if ok, rule := engine.Match(name); !ok || rule != "bet.ar" {
			t.Errorf("%s not blocked via bet.ar: %v,%s", name, ok, rule)
		}
	}
	allowed := []string{"ministeriodesalud.gob.ar", "www.google.com", "gamblersanonymous.org", "example.org", "notbet.ar.example.org", "abet.ar"}
	for _, name := range allowed {
		if ok, rule := engine.Match(name); ok {
			t.Errorf("false positive %s by %s", name, rule)
		}
	}
}

func TestRejectOverbroadPublicZones(t *testing.T) {
	engine := New([]string{"com.ar", "co.uk", "com.au", "casino.com.ar"}, true)
	if got, _ := engine.Match("www.tienda.com.ar"); got {
		t.Fatal("blocked unrelated com.ar domain")
	}
	if got, _ := engine.Match("www.example.co.uk"); got {
		t.Fatal("blocked unrelated co.uk domain")
	}
	if got, _ := engine.Match("casino.com.ar"); !got {
		t.Fatal("failed to block individual gambling domain")
	}
}
