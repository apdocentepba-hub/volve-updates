//go:build windows

package main

import (
	"syscall"
	"unsafe"
)

// VOLVÉ native visual system. This is a deliberately small Win32/GDI layer:
// no WebView runtime, network permissions, or elevated UI privileges needed.
const (
	bsOwnerDraw  = 0x0000000B
	dtCenter     = 0x00000001
	dtVCenter    = 0x00000004
	dtSingleLine = 0x00000020
	dtLeft       = 0x00000000
	dtWordBreak  = 0x00000010
	odsSelected  = 0x00000001
	odsDisabled  = 0x00000004
	odsFocus     = 0x00000010
)

type skinRect struct{ Left, Top, Right, Bottom int32 }
type drawItemStruct struct {
	CtlType, CtlID, ItemID, ItemAction, ItemState uint32
	HwndItem, Hdc                                 uintptr
	RcItem                                        skinRect
	ItemData                                      uintptr
}
type skinPaintStruct struct {
	Hdc       uintptr
	Erase     int32
	Paint     skinRect
	Restore   int32
	IncUpdate int32
	Reserved  [32]byte
}

func colorRef(r, g, b uint8) uintptr { return uintptr(r) | (uintptr(g) << 8) | (uintptr(b) << 16) }

var (
	skinBodyFont    uintptr
	skinButtonFont  uintptr
	skinSectionFont uintptr
	skinHeroFont    uintptr
)

func styledButton(w uintptr, label string, x, y, width, height, id int32) uintptr {
	h := widget(w, "BUTTON", label, wsVisible|wsChild|wsTabStop|bsOwnerDraw, x, y, width, height, id)
	return h
}

func skinFill(dc uintptr, r skinRect, col uintptr) {
	b, _, _ := dllGDI.NewProc("CreateSolidBrush").Call(col)
	user.NewProc("FillRect").Call(dc, uintptr(unsafe.Pointer(&r)), b)
	dllGDI.NewProc("DeleteObject").Call(b)
}
func skinRound(dc uintptr, r skinRect, rad int32, fill, border uintptr) {
	b, _, _ := dllGDI.NewProc("CreateSolidBrush").Call(fill)
	p, _, _ := dllGDI.NewProc("CreatePen").Call(0, 1, border)
	oldb, _, _ := dllGDI.NewProc("SelectObject").Call(dc, b)
	oldp, _, _ := dllGDI.NewProc("SelectObject").Call(dc, p)
	dllGDI.NewProc("RoundRect").Call(dc, uintptr(r.Left), uintptr(r.Top), uintptr(r.Right), uintptr(r.Bottom), uintptr(rad), uintptr(rad))
	dllGDI.NewProc("SelectObject").Call(dc, oldb)
	dllGDI.NewProc("SelectObject").Call(dc, oldp)
	dllGDI.NewProc("DeleteObject").Call(b)
	dllGDI.NewProc("DeleteObject").Call(p)
}
func skinText(dc uintptr, content string, r skinRect, font, fg uintptr, flags uintptr) {
	if font == 0 {
		font, _, _ = dllGDI.NewProc("GetStockObject").Call(17)
	}
	old, _, _ := dllGDI.NewProc("SelectObject").Call(dc, font)
	dllGDI.NewProc("SetBkMode").Call(dc, 1)
	dllGDI.NewProc("SetTextColor").Call(dc, fg)
	p := utf16p(content)
	user.NewProc("DrawTextW").Call(dc, uintptr(unsafe.Pointer(p)), ^uintptr(0), uintptr(unsafe.Pointer(&r)), flags)
	dllGDI.NewProc("SelectObject").Call(dc, old)
}
func drawPanelChrome(w uintptr) {
	var ps skinPaintStruct
	dc, _, _ := user.NewProc("BeginPaint").Call(w, uintptr(unsafe.Pointer(&ps)))
	if dc == 0 {
		return
	}
	defer user.NewProc("EndPaint").Call(w, uintptr(unsafe.Pointer(&ps)))
	var client skinRect
	user.NewProc("GetClientRect").Call(w, uintptr(unsafe.Pointer(&client)))
	skinFill(dc, client, colorRef(243, 248, 249))
	// Progressive horizontal bands give a subtle teal/deep-blue hero.
	for i := int32(0); i < 14; i++ {
		fraction := float64(i) / 13
		r := uint8(12 + 14*fraction)
		g := uint8(47 + 21*fraction)
		b := uint8(62 + 13*fraction)
		skinFill(dc, skinRect{0, i * 10, client.Right, (i+1)*10 + 1}, colorRef(r, g, b))
	}
	if skinHeroFont == 0 {
		skinHeroFont = makeFont(-37, 750)
		skinSectionFont = makeFont(-17, 700)
		skinBodyFont = makeFont(-16, 400)
		skinButtonFont = makeFont(-16, 650)
	}
	// Logo badge and title. Native vector UI; no embedded stock icons.
	skinRound(dc, skinRect{31, 24, 89, 82}, 26, colorRef(4, 167, 141), colorRef(4, 167, 141))
	skinText(dc, "V", skinRect{31, 31, 89, 77}, skinHeroFont, colorRef(255, 255, 255), dtCenter|dtVCenter|dtSingleLine)
	skinText(dc, "VOLVÉ", skinRect{103, 18, 550, 73}, skinHeroFont, colorRef(255, 255, 255), dtLeft|dtVCenter|dtSingleLine)
	skinText(dc, "UN PASO A LA VEZ", skinRect{104, 73, 520, 101}, skinSectionFont, colorRef(171, 233, 217), dtLeft|dtVCenter|dtSingleLine)
	skinText(dc, "Un espacio de cuidado digital, sin juicios ni presiones.", skinRect{33, 109, 760, 135}, skinBodyFont, colorRef(218, 242, 240), dtLeft|dtVCenter|dtSingleLine)
	skinRound(dc, skinRect{658, 34, 875, 75}, 24, colorRef(31, 88, 95), colorRef(61, 116, 120))
	skinText(dc, "CENTRO  ·  v"+version, skinRect{662, 36, 870, 72}, skinBodyFont, colorRef(228, 254, 248), dtCenter|dtVCenter|dtSingleLine)
	// Compact main surface with spacious touch targets.
	skinRound(dc, skinRect{22, 149, 887, 304}, 22, colorRef(255, 255, 255), colorRef(222, 232, 234))
	skinText(dc, "ACCESOS PRINCIPALES", skinRect{34, 146, 350, 165}, skinSectionFont, colorRef(35, 82, 85), dtLeft|dtVCenter|dtSingleLine)
	skinRound(dc, skinRect{22, 308, 887, 605}, 18, colorRef(255, 255, 255), colorRef(222, 232, 234))
	name := "ESTADO DE TU PROTECCIÓN"
	if advancedVisible {
		name = "HERRAMIENTAS AVANZADAS  ·  USAR CON PRECAUCIÓN"
	}
	skinText(dc, name, skinRect{33, 310, 865, 337}, skinSectionFont, colorRef(35, 82, 85), dtLeft|dtVCenter|dtSingleLine)
	skinText(dc, "Los bloqueos ayudan a sostener una decisión. Conservá tu rescate de emergencia.", skinRect{32, 602, 740, 627}, skinBodyFont, colorRef(70, 104, 108), dtLeft|dtVCenter|dtSingleLine)
}
func drawPanelButton(lp uintptr) {
	if lp == 0 {
		return
	}
	var item drawItemStruct
	// Read the native DRAWITEMSTRUCT without converting arbitrary uintptr to a Go pointer.
	syscall.NewLazyDLL("ntdll.dll").NewProc("RtlMoveMemory").Call(uintptr(unsafe.Pointer(&item)), lp, unsafe.Sizeof(item))
	dc := item.Hdc
	r := item.RcItem
	// Owner-drawn Win32 BUTTONs still retain standard keyboard navigation.
	var fill = colorRef(244, 249, 248)
	var border = colorRef(202, 225, 221)
	var textCol = colorRef(19, 69, 77)
	switch item.CtlID {
	case idRefresh:
		fill = colorRef(18, 65, 80)
		border = fill
		textCol = colorRef(255, 255, 255)
	case idHelp:
		fill = colorRef(0, 147, 117)
		border = fill
		textCol = colorRef(255, 255, 255)
	case idHealth:
		fill = colorRef(224, 247, 240)
		border = colorRef(155, 218, 199)
	case idUpdates:
		fill = colorRef(235, 244, 252)
		border = colorRef(182, 212, 232)
	case idAdvanced:
		fill = colorRef(248, 250, 252)
		border = colorRef(204, 215, 222)
	case idClose:
		fill = colorRef(230, 237, 239)
		border = colorRef(205, 218, 221)
	case idInstallAll, idRestoreDNS:
		fill = colorRef(255, 239, 226)
		border = colorRef(232, 187, 148)
	}
	if item.ItemState&odsSelected != 0 {
		// Applied on press only; never changes the underlying security action.
		fill = colorRef(194, 218, 218)
		textCol = colorRef(13, 49, 60)
	}
	if item.ItemState&odsDisabled != 0 {
		textCol = colorRef(142, 150, 157)
	}
	r.Left += 2
	r.Right -= 2
	r.Top += 2
	r.Bottom -= 2
	skinRound(dc, r, 17, fill, border)
	if skinButtonFont == 0 {
		skinButtonFont = makeFont(-16, 650)
	}
	skinText(dc, buttonText(item.HwndItem), r, skinButtonFont, textCol, dtCenter|dtVCenter|dtSingleLine)
	if item.ItemState&odsFocus != 0 {
		focus := r
		focus.Left += 6
		focus.Top += 5
		focus.Right -= 6
		focus.Bottom -= 5
		user.NewProc("DrawFocusRect").Call(dc, uintptr(unsafe.Pointer(&focus)))
	}
}
func buttonText(w uintptr) string {
	// Fixed buffer, local window only. Avoid owner-draw labels depending on an external service.
	buf := make([]uint16, 200)
	count, _, _ := user.NewProc("GetWindowTextW").Call(w, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
	if count == 0 {
		return ""
	}
	return syscall.UTF16ToString(buf)
}
