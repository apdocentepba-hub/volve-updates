//go:build ignore

// Offline publisher utility. NEVER ship a private key inside client binaries,
// public repositories, installers, or update ZIPs.
// Usage: go run tools/sign_manifest.go SECRET_KEY_BASE64_FILE stable.json
//
package main

import (
	"crypto/ed25519"
	"encoding/base64"
	"fmt"
	"os"
	"strings"
)

func main() {
	if len(os.Args) != 3 {
		fmt.Fprintln(os.Stderr, "uso: go run tools/sign_manifest.go CLAVE_PRIVADA.txt releases/stable.json")
		os.Exit(2)
	}
	keyText, e := os.ReadFile(os.Args[1])
	if e != nil {
		panic(e)
	}
	lines := strings.Split(strings.TrimSpace(string(keyText)), "\n")
	raw, e := base64.StdEncoding.DecodeString(strings.TrimSpace(lines[len(lines)-1]))
	if e != nil || len(raw) != ed25519.SeedSize {
		panic("clave privada inválida")
	}
	payload, e := os.ReadFile(os.Args[2])
	if e != nil {
		panic(e)
	}
	private := ed25519.NewKeyFromSeed(raw)
	sig := base64.StdEncoding.EncodeToString(ed25519.Sign(private, payload))
	if e := os.WriteFile(os.Args[2]+".sig", []byte(sig+"\n"), 0600); e != nil {
		panic(e)
	}
	fmt.Println("Manifiesto firmado. NO subir clave privada. Subir stable.json y stable.json.sig juntos al canal permitido.")
}
