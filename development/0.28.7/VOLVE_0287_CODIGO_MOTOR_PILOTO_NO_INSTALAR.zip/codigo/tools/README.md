# Publicar una actualización de VOLVÉ (proceso de firma)

1. Compilar y probar una versión Windows x64 **en una VM Windows**.
2. Firmar el ejecutable con un certificado Authenticode de editor confiable (pendiente obtener certificado; no confundir con firma del manifiesto).
3. Subir EXE a un release HTTPS de `apdocentepba-hub/volve-updates`.
4. Crear `releases/stable.json` con `schema:1`, `version`, `published`, `notes`, `url`, `sha256` y `size`. El URL debe apuntar al EXE en `https://github.com/apdocentepba-hub/volve-updates/releases/download/...`.
5. **EN MÁQUINA DE FIRMA SIN ACCESO PÚBLICO**: `go run tools/sign_manifest.go CLAVE_PRIVADA.txt releases/stable.json`.
6. Publicar `stable.json` y `stable.json.sig` en la rama main.
7. El cliente acepta únicamente manifiestos firmados Ed25519 con su clave pública incorporada y luego verifica byte por byte el SHA-256 y el tamaño del EXE. Si falla, no ofrece el archivo.

**Estado actual 0.28.0:** el canal de publicaciones todavía no contiene releases firmadas. Por lo tanto, el botón «Actualizar VOLVÉ» puede indicar que no existe un manifiesto confiable publicado. La descarga/verificación está implementada; instalar automáticamente y reponer el motor residente NO está activado.

La clave privada de publicación no está incluida en el paquete fuente ni en el EXE y no debe subirse a GitHub, Drive compartido ni soporte técnico.
