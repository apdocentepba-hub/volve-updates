#!/usr/bin/env python3
"""Prepare an *unsigned* VOLVÉ release manifest for offline signing.

1. Publish the tested EXE to the official GitHub Releases URL.
2. Run this script with the exact published version and local EXE.
3. Sign exact stable.json bytes offline with tools/sign_manifest.go.
4. Publish stable.json and stable.json.sig together only after tests.
No secrets are needed or written by this preparation tool.
"""
import argparse
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument("--exe", type=Path, required=True)
p.add_argument("--version", required=True)
p.add_argument("--out", type=Path, required=True)
p.add_argument("--notes", default="Actualización del Centro de protección, sin modificar DNS.")
a = p.parse_args()
if not re.fullmatch(r"\d+\.\d+\.\d+", a.version):
    p.error("Versión inválida")
if a.exe.suffix.lower() != ".exe" or not a.exe.is_file():
    p.error("EXE faltante")
if len(a.notes) > 2000:
    p.error("Notas demasiado extensas")
asset = "VOLVE_"+a.version.replace(".","_")+ "_CENTRO.exe"
url = f"https://github.com/apdocentepba-hub/volve-updates/releases/download/v{a.version}/{asset}"
h = hashlib.sha256()
size=0
with a.exe.open("rb") as f:
    while block := f.read(1024*1024):
        h.update(block)
        size += len(block)
if not 0 < size <= 200*1024*1024:
    p.error("Archivo vacío o demasiado grande")
manifest = {"schema":1,"version":a.version,
    "published":datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    "notes":a.notes, "url":url,"sha256":h.hexdigest(),"size":size}
a.out.parent.mkdir(parents=True,exist_ok=True)
a.out.write_bytes((json.dumps(manifest,separators=(',',':'),ensure_ascii=False)+'\n').encode('utf-8'))
print(f"Manifest SIN FIRMAR creado: {a.out}\nSHA256: {h.hexdigest()}\nURL prevista: {url}\nNo publicar sin la firma Ed25519 válida y el EXE cargado al Release.")
