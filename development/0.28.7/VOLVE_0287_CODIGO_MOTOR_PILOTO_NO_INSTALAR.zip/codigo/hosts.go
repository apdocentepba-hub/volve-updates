package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"sort"
	"strings"
)

const hostsBegin = "# VOLVE-BEGIN 0.20.0 sha256="
const hostsEnd = "# VOLVE-END 0.20.0"

// hostsData generates an exact, auditable, finite list of hostnames. The hosts
// file has NO wildcard support; domain subtrees need the browser rules too.
func hostsData() ([]byte, error) {
	names := map[string]bool{}
	for _, raw := range domains {
		d := strings.ToLower(strings.TrimSpace(raw))
		if !validDomain.MatchString(d) {
			return nil, fmt.Errorf("dominio inválido: %q", d)
		}
		for _, prefix := range []string{"", "www.", "m.", "mobile.", "app.", "api."} {
			names[prefix+d] = true
		}
	}
	keys := make([]string, 0, len(names))
	for k := range names {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	var lines []string
	for _, k := range keys {
		lines = append(lines, "0.0.0.0 "+k, ":: "+k)
	}
	return []byte(strings.Join(lines, "\n")), nil
}

func newline(b []byte) string {
	if bytes.Contains(b, []byte("\r\n")) {
		return "\r\n"
	}
	return "\n"
}
func validateHostsBytes(b []byte) error {
	if len(b) > 4*1024*1024 {
		return errors.New("archivo hosts supera 4 MiB; no modificar")
	}
	if bytes.Contains(b, []byte{0}) || bytes.HasPrefix(b, []byte{0xff, 0xfe}) || bytes.HasPrefix(b, []byte{0xfe, 0xff}) {
		return errors.New("codificación hosts no compatible; no modificar")
	}
	return nil
}

// markerRange returns the complete VOLVE block's position (without unrelated content).
func markerRange(base []byte) (int, int, error) {
	start := bytes.Index(base, []byte(hostsBegin))
	end := bytes.Index(base, []byte(hostsEnd))
	if (start < 0) != (end < 0) {
		return 0, 0, errors.New("marcadores VOLVE incompletos: no se modifica hosts")
	}
	if start < 0 {
		return -1, -1, nil
	}
	if end <= start || bytes.Count(base, []byte(hostsBegin)) != 1 || bytes.Count(base, []byte(hostsEnd)) != 1 {
		return 0, 0, errors.New("marcadores VOLVE ambiguos")
	}
	if start > 0 && base[start-1] != '\n' {
		return 0, 0, errors.New("marcador VOLVE no comienza en nueva línea")
	}
	lineEnd := bytes.IndexByte(base[start:], '\n')
	if lineEnd < 0 {
		return 0, 0, errors.New("encabezado VOLVE sin salto de línea")
	}
	lineEnd += start + 1
	header := strings.TrimSuffix(strings.TrimSpace(string(base[start:lineEnd])), "\r")
	if !strings.HasPrefix(header, hostsBegin) {
		return 0, 0, errors.New("cabecera VOLVE incorrecta")
	}
	digest := strings.TrimPrefix(header, hostsBegin)
	if len(digest) != 64 {
		return 0, 0, errors.New("checksum VOLVE malformado")
	}
	body := bytes.TrimRight(base[lineEnd:end], "\r\n")
	// Normalize LF/CRLF before verification (the generated body is LF).
	normalized := bytes.ReplaceAll(body, []byte("\r\n"), []byte("\n"))
	sha := sha256.Sum256(normalized)
	if hex.EncodeToString(sha[:]) != digest {
		return 0, 0, errors.New("las reglas VOLVE fueron modificadas; no se borran automáticamente")
	}
	markerFinish := end + len(hostsEnd)
	if markerFinish < len(base) && base[markerFinish] == '\r' {
		markerFinish++
	}
	if markerFinish < len(base) && base[markerFinish] == '\n' {
		markerFinish++
	}
	return start, markerFinish, nil
}

func addHostsContent(base []byte) ([]byte, bool, error) {
	if e := validateHostsBytes(base); e != nil {
		return nil, false, e
	}
	start, _, e := markerRange(base)
	if e != nil {
		return nil, false, e
	}
	body, e := hostsData()
	if e != nil {
		return nil, false, e
	}
	if start >= 0 {
		return base, false, nil
	} // existing verified VOLVE block, idempotent
	nl := newline(base)
	checksum := sha256.Sum256(body)
	block := hostsBegin + hex.EncodeToString(checksum[:]) + "\n" + string(body) + "\n" + hostsEnd + "\n"
	block = strings.ReplaceAll(block, "\n", nl)
	out := append([]byte(nil), base...)
	if len(out) > 0 && out[len(out)-1] != '\n' {
		out = append(out, []byte(nl)...)
	}
	out = append(out, []byte(block)...)
	if e = validateHostsBytes(out); e != nil {
		return nil, false, e
	}
	return out, true, nil
}

func removeHostsContent(base []byte) ([]byte, bool, error) {
	if e := validateHostsBytes(base); e != nil {
		return nil, false, e
	}
	start, end, e := markerRange(base)
	if e != nil {
		return nil, false, e
	}
	if start < 0 {
		return base, false, nil
	}
	out := append([]byte(nil), base[:start]...)
	out = append(out, base[end:]...)
	return out, true, nil
}
