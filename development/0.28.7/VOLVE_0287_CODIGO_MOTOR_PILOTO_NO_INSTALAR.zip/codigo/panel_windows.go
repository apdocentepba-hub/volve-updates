//go:build windows

package main

import (
	"context"
	"crypto/sha256"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"
)

// Native Win32 panel. No webview, browser extensions, external GUI frameworks,
// continuously-running background polling or transient console windows.
const (
	wsOverlappedWindow = 0x00CF0000
	wsVisible          = 0x10000000
	wsChild            = 0x40000000
	wsTabStop          = 0x00010000
	wsVScroll          = 0x00200000
	esMultiline        = 0x0004
	esReadOnly         = 0x0800
	esAutoVScroll      = 0x0040
	wsBorder           = 0x00800000
	wmCreate           = 0x0001
	wmCtlColorStatic   = 0x0138
	wmPaint            = 0x000F
	wmDrawItem         = 0x002B
	wmDestroy          = 0x0002
	wmClose            = 0x0010
	wmCommand          = 0x0111
	wmSetFont          = 0x0030
	wmSetText          = 0x000C
	wmAppDataReady     = 0x8001
	cwUseDefault       = 0x80000000
	idRefresh          = 101
	idDoctor           = 102
	idInstall          = 103
	idCatalog          = 104
	idFolder           = 105
	idClose            = 106
	idTestDNS          = 107
	idRehearsal        = 108
	idInstallAll       = 109
	idRestoreDNS       = 110
	idHealth           = 111
	idSample           = 112
	idRepairRescue     = 113
	idUpdates          = 114
	idHelp             = 115
	idAdvanced         = 116
	idBrowserAddons    = 117
	idMotorUpdates     = 118
)

var (
	dllKernel         = syscall.NewLazyDLL("kernel32.dll")
	dllGDI            = syscall.NewLazyDLL("gdi32.dll")
	procCreate        = user.NewProc("CreateWindowExW")
	procRegister      = user.NewProc("RegisterClassExW")
	procDef           = user.NewProc("DefWindowProcW")
	procSend          = user.NewProc("SendMessageW")
	procPost          = user.NewProc("PostMessageW")
	panelCallback     uintptr
	panelTextHwnd     uintptr
	panelHwnd         uintptr
	panelTextGuard    sync.Mutex
	panelText         string
	panelRequest      uint64
	panelBusy         bool
	panelStagedUpdate string
	advancedControls  []uintptr
	advancedVisible   bool
	panelLabelFont    uintptr
	panelHeaderFont   uintptr
	panelBgBrush      uintptr
)

type wndClassEx struct {
	CbSize     uint32
	Style      uint32
	WndProc    uintptr
	ClsExtra   int32
	WndExtra   int32
	HInstance  uintptr
	Icon       uintptr
	Cursor     uintptr
	Background uintptr
	MenuName   *uint16
	ClassName  *uint16
	IconSm     uintptr
}
type point struct{ X, Y int32 }
type winMessage struct {
	Hwnd    uintptr
	Msg     uint32
	WParam  uintptr
	LParam  uintptr
	Time    uint32
	Pt      point
	Private uint32
}

func makeFont(height, weight int) uintptr {
	face := utf16p("Segoe UI")
	h, _, _ := dllGDI.NewProc("CreateFontW").Call(uintptr(int32(height)), 0, 0, 0, uintptr(weight), 0, 0, 0, 1, 0, 0, 0, 0, uintptr(unsafe.Pointer(face)))
	return h
}
func largeLabel(w uintptr, text string, x, y, width, height int32, large bool) uintptr {
	h := widget(w, "STATIC", text, wsVisible|wsChild, x, y, width, height, 0)
	font := panelLabelFont
	if large {
		font = panelHeaderFont
	}
	if font != 0 {
		procSend.Call(h, wmSetFont, font, 1)
	}
	return h
}
func advancedWidget(w uintptr, text string, x, y, width, height, id int32) {
	h := widget(w, "BUTTON", text, wsChild|wsTabStop|bsOwnerDraw, x, y, width, height, id)
	advancedControls = append(advancedControls, h)
}
func toggleAdvanced() {
	advancedVisible = !advancedVisible
	show := uintptr(0)
	if advancedVisible {
		show = 5
	}
	for _, h := range advancedControls {
		user.NewProc("ShowWindow").Call(h, show)
	}
	if panelHwnd != 0 {
		user.NewProc("InvalidateRect").Call(panelHwnd, 0, 1)
	}
	if panelTextHwnd != 0 {
		if advancedVisible {
			user.NewProc("ShowWindow").Call(panelTextHwnd, 0)
		} else {
			user.NewProc("ShowWindow").Call(panelTextHwnd, 5)
		}
	}
}
func updatePanel(w uintptr) {
	panelTextGuard.Lock()
	if panelBusy {
		panelTextGuard.Unlock()
		msg("Ya hay una comprobación en curso.", MB_ICONINFORMATION)
		return
	}
	panelBusy = true
	panelRequest++
	req := panelRequest
	panelTextGuard.Unlock()
	if advancedVisible {
		toggleAdvanced()
	}
	setText(panelTextHwnd, "VOLVÉ | ACTUALIZACIÓN DEL PROGRAMA\r\n\r\nComprobando la versión firmada. Solo se aceptan paquetes autorizados y con huella SHA-256 válida.\r\n\r\nNo se modifica el DNS ni se reemplaza el motor residente.")
	go func() {
		result := panelToolBounded("--check-app-updates", 120*time.Second)
		panelTextGuard.Lock()
		panelBusy = false
		if req == panelRequest {
			panelStagedUpdate = ""
			const marker = "\nVOLVE_STAGE_READY="
			if i := strings.LastIndex(result, marker); i >= 0 {
				panelStagedUpdate = strings.TrimSpace(result[i+len(marker):])
				result = result[:i]
			}
			panelText = result
			procPost.Call(w, wmAppDataReady, 0, 0)
		}
		panelTextGuard.Unlock()
	}()
}
func utf16p(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func widget(w uintptr, class, text string, style uint32, x, y, width, height, id int32) uintptr {
	c := utf16p(class)
	t := utf16p(text)
	h, _, _ := procCreate.Call(0, uintptr(unsafe.Pointer(c)), uintptr(unsafe.Pointer(t)), uintptr(style), uintptr(x), uintptr(y), uintptr(width), uintptr(height), w, uintptr(id), 0, 0)
	if h != 0 {
		font, _, _ := dllGDI.NewProc("GetStockObject").Call(17)
		procSend.Call(h, wmSetFont, font, 1)
	}
	return h
}
func setText(hwnd uintptr, s string) {
	if hwnd == 0 {
		return
	}
	p := utf16p(panelCRLF(s))
	procSend.Call(hwnd, wmSetText, 0, uintptr(unsafe.Pointer(p)))
}
func panelStatus() string {
	info, err := inspect()
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return "SIN INSTALAR. Ejecutá Instalar/Reparar.\r\n\r\nEl DNS masivo NO está activo.\r\n"
		}
		return "DIAGNÓSTICO NO COMPLETO: " + err.Error() + "\r\n\r\n" + info
	}
	return fmt.Sprintf("VOLVÉ %s — ESTADO COMPROBADO\r\n\r\n%s\r\n\r\nIMPORTANTE: la descarga de catálogos no garantiza por sí misma filtrado de red. Verificá la línea «DNS real» del diagnóstico.", version, strings.ReplaceAll(info, "\n", "\r\n"))
}

// Execute a bounded, read-only diagnostic outside the window message loop.
func testDNSPanel(w uintptr) {
	panelTextGuard.Lock()
	if panelBusy {
		panelTextGuard.Unlock()
		msg("VOLVÉ ya está ejecutando otra comprobación.\nCuando termine, volvé a presionar el botón.", MB_ICONINFORMATION)
		return
	}
	panelBusy = true
	panelRequest++
	req := panelRequest
	panelTextGuard.Unlock()
	setText(panelTextHwnd, "PROBANDO MOTOR DNS CON LISTA MASIVA REAL...\r\nUsando solo puertos locales temporales, sin modificar DNS de Windows.\r\nLa operación puede consumir memoria mientras carga 600.000 dominios.")
	go func() {
		s := panelToolBounded("--dns-preflight", 65*time.Second)
		panelTextGuard.Lock()
		panelBusy = false
		if req == panelRequest {
			panelText = s
			procPost.Call(w, wmAppDataReady, 0, 0)
		}
		panelTextGuard.Unlock()
	}()
}

func rehearsalPanel(w uintptr) {
	panelTextGuard.Lock()
	if panelBusy {
		panelTextGuard.Unlock()
		msg("VOLVÉ ya está ejecutando otra comprobación.\nCuando termine, volvé a presionar el botón.", MB_ICONINFORMATION)
		return
	}
	panelBusy = true
	panelRequest++
	req := panelRequest
	panelTextGuard.Unlock()
	setText(panelTextHwnd, "ENSAYANDO MOTOR DNS EN PUERTO 53 Y RECUPERACIÓN...\r\nSin alterar el DNS de Windows. Puede tardar mientras carga el catálogo completo.")
	go func() {
		s := panelToolBounded("--dns-recovery-rehearsal", 100*time.Second)
		panelTextGuard.Lock()
		panelBusy = false
		if req == panelRequest {
			panelText = s
			procPost.Call(w, wmAppDataReady, 0, 0)
		}
		panelTextGuard.Unlock()
	}()
}

// One-click, read-only health report against the ALREADY INSTALLED DNS worker.
func samplePanel(w uintptr) {
	panelTextGuard.Lock()
	if panelBusy {
		panelTextGuard.Unlock()
		msg("VOLVÉ ya está ejecutando otra prueba.", MB_ICONINFORMATION)
		return
	}
	panelBusy = true
	panelRequest++
	req := panelRequest
	panelTextGuard.Unlock()
	setText(panelTextHwnd, "PROBANDO 100 DOMINIOS DEL CATÁLOGO CON DNS LOCAL...\r\nNo se abre ningún sitio ni se cambia la configuración.")
	go func() {
		txt := panelToolBounded("--sample-100", 60*time.Second)
		panelTextGuard.Lock()
		panelBusy = false
		if req == panelRequest {
			panelText = txt
			procPost.Call(w, wmAppDataReady, 0, 0)
		}
		panelTextGuard.Unlock()
	}()
}

var healthOnlyPanel bool

func healthPanel(w uintptr) {
	if !isAdmin() {
		setText(panelTextHwnd, "VOLVÉ | DIAGNÓSTICO ADMINISTRATIVO\r\n"+
			"El respaldo de rescate está protegido. Se solicitará autorización de Windows (UAC).\r\n"+
			"La comprobación elevada es de SOLO LECTURA: no modifica DNS, reglas ni tareas.")
		e := requireAdmin("--healthcheck-admin")
		if e != nil && !errors.Is(e, errSpawned) {
			setText(panelTextHwnd, "DIAGNÓSTICO NO REALIZADO: no se concedió permiso de administrador.\r\n"+
				"La protección actual no se modificó. Motivo: "+e.Error())
		}
		return
	}
	panelTextGuard.Lock()
	if panelBusy {
		panelTextGuard.Unlock()
		msg("VOLVÉ ya está realizando otra comprobación.", MB_ICONINFORMATION)
		return
	}
	panelBusy = true
	panelRequest++
	req := panelRequest
	panelTextGuard.Unlock()
	setText(panelTextHwnd, "COMPROBANDO PROTECCIÓN REAL...\r\nDNS IPv4/IPv6, adaptador, rescate y catálogo.\r\nSolo lectura; no se cambia la conexión.")
	go func() {
		report := panelToolBounded("--healthcheck", 85*time.Second)
		panelTextGuard.Lock()
		panelBusy = false
		if req == panelRequest {
			panelText = report
			procPost.Call(w, wmAppDataReady, 0, 0)
		}
		panelTextGuard.Unlock()
	}()
}

func refreshPanel(w uintptr) {
	if panelTextHwnd == 0 {
		return
	}
	panelTextGuard.Lock()
	if panelBusy {
		panelTextGuard.Unlock()
		return
	}
	panelBusy = true
	panelRequest++
	req := panelRequest
	panelTextGuard.Unlock()
	setText(panelTextHwnd, "Comprobando reglas y catálogo en segundo plano (límite: 20 segundos). El panel seguirá respondiendo...")
	go func() {
		s := panelToolBounded("--panel-report", 20*time.Second)
		panelTextGuard.Lock()
		panelBusy = false
		if req == panelRequest {
			panelText = s
			procPost.Call(w, wmAppDataReady, 0, 0)
		}
		panelTextGuard.Unlock()
	}()
}

// The checker runs OUT OF PROCESS, with a hard timeout. Even if reg.exe or
// Windows Task Scheduler hangs, the panel message loop can still repaint,
// accept Close, and safely allow a later manual retry.
func panelToolBounded(argument string, timeout time.Duration) string {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	self, err := os.Executable()
	if err != nil {
		return "No se pudo encontrar el ejecutable: " + err.Error()
	}
	cmd := exec.CommandContext(ctx, self, argument)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: createNoWindow}
	data, err := cmd.CombinedOutput()
	if ctx.Err() != nil {
		return "La prueba superó el límite de tiempo y fue detenida. El panel continúa operativo.\r\n" +
			"Las reglas de Windows y el DNS de los adaptadores NO fueron modificados."
	}
	if len(data) == 0 || len(data) > 150000 {
		return "El informe está vacío o excede el límite; estado no verificado."
	}
	if err != nil {
		return "RESULTADO NO APROBADO: " + err.Error() + "\r\n" + string(data)
	}
	return string(data)
}

func shellOpen(path string) error {
	verb := utf16p("open")
	p := utf16p(path)
	r, _, err := shell.NewProc("ShellExecuteW").Call(0, uintptr(unsafe.Pointer(verb)), uintptr(unsafe.Pointer(p)), 0, 0, 1)
	if r <= 32 {
		return fmt.Errorf("Windows no pudo abrir la ruta (%d): %v", r, err)
	}
	return nil
}
func panelWndProc(w uintptr, message uint32, wp, lp uintptr) uintptr {
	switch message {
	case wmCreate:
		panelHwnd = w
		if healthOnlyPanel {
			widget(w, "STATIC", "VOLVÉ | DIAGNÓSTICO ADMINISTRATIVO", wsVisible|wsChild, 24, 20, 780, 30, 0)
			widget(w, "STATIC", "Solo lectura: DNS IPv4/IPv6, motor, rescate y catálogo. No modifica Windows.", wsVisible|wsChild, 24, 60, 825, 25, 0)
			panelTextHwnd = widget(w, "EDIT", "Preparando comprobación...", wsVisible|wsChild|wsBorder|wsVScroll|esMultiline|esReadOnly|esAutoVScroll, 24, 100, 843, 482, 0)
			widget(w, "BUTTON", "Cerrar", wsVisible|wsChild|wsTabStop, 743, 616, 124, 35, idClose)
			healthPanel(w)
			return 0
		}
		// Branded, owner-drawn layout. Everything remains native and keyboard accessible.
		panelHeaderFont = makeFont(-38, 750)
		panelLabelFont = makeFont(-17, 500)
		// Main actions in a short, calm hierarchy: status, health, lists, app update.
		styledButton(w, "Mi protección", 32, 167, 198, 53, idRefresh)
		styledButton(w, "Verificar seguridad", 239, 167, 200, 53, idHealth)
		styledButton(w, "Actualizar listas", 448, 167, 199, 53, idCatalog)
		styledButton(w, "Actualizar VOLVÉ", 656, 167, 219, 53, idUpdates)
		styledButton(w, "Necesito un momento", 32, 235, 410, 56, idHelp)
		styledButton(w, "Herramientas avanzadas", 454, 235, 421, 56, idAdvanced)
		panelTextHwnd = widget(w, "EDIT", "Consultando la protección...", wsVisible|wsChild|wsBorder|wsVScroll|esMultiline|esReadOnly|esAutoVScroll, 32, 338, 843, 249, 0)
		// Risky functions stay out of the primary UI.
		advancedControls = nil
		advancedWidget(w, "Diagnóstico adicional", 32, 339, 266, 53, idDoctor)
		advancedWidget(w, "Instalar / Reparar", 309, 339, 266, 53, idInstall)
		advancedWidget(w, "Prueba DNS temporal", 586, 339, 289, 53, idTestDNS)
		advancedWidget(w, "Ensayar rescate", 32, 404, 266, 53, idRehearsal)
		advancedWidget(w, "Activar DNS (admin)", 309, 404, 266, 53, idInstallAll)
		advancedWidget(w, "Restaurar DNS", 586, 404, 289, 53, idRestoreDNS)
		advancedWidget(w, "Carpeta de datos", 32, 469, 266, 53, idFolder)
		advancedWidget(w, "Reparar tarea rescate", 309, 469, 266, 53, idRepairRescue)
		advancedWidget(w, "Probar 100 dominios", 586, 469, 289, 53, idSample)
		advancedWidget(w, "Integrar navegadores", 32, 535, 410, 50, idBrowserAddons)
		advancedWidget(w, "Consultar motor (piloto)", 454, 535, 421, 50, idMotorUpdates)
		styledButton(w, "Cerrar", 751, 622, 124, 40, idClose)
		refreshPanel(w)
		return 0
	case wmAppDataReady:
		panelTextGuard.Lock()
		s := panelText
		staged := panelStagedUpdate
		panelStagedUpdate = ""
		panelTextGuard.Unlock()
		setText(panelTextHwnd, s)
		if staged != "" && !healthOnlyPanel {
			if msg("Nueva actualización verificada y descargada.\n\n¿Instalar ahora SOLO el Centro de protección?\nNo se cambiarán el DNS ni el motor residente.\n\nWindows solicitará permiso de administrador.", MB_YESNOCANCEL|MB_ICONQUESTION) == 6 {
				if e := launchPanelUpdateAdmin(staged); e != nil {
					msg("No se pudo iniciar la instalación del panel: "+e.Error(), MB_ICONERROR)
				}
			}
		}
		return 0
	case wmCommand:
		if healthOnlyPanel {
			if uint16(wp&0xffff) == idClose {
				user.NewProc("DestroyWindow").Call(w)
			}
			return 0
		}
		switch uint16(wp & 0xffff) {
		case idRefresh:
			if advancedVisible {
				toggleAdvanced()
			}
			refreshPanel(w)
		case idAdvanced:
			toggleAdvanced()
		case idBrowserAddons:
			browserAddonsOptin(w)
		case idHelp:
			if e := openSupportPage(); e != nil {
				msg("No se pudo abrir el mensaje de ayuda: "+e.Error(), MB_ICONERROR)
			}
		case idUpdates:
			updatePanel(w)
		case idMotorUpdates:
			motorPilotPanel(w)
		case idHealth:
			healthPanel(w)
		case idSample:
			samplePanel(w)
		case idTestDNS:
			testDNSPanel(w)
		case idRehearsal:
			rehearsalPanel(w)
		case idInstallAll:
			answer := msg("Esta opción instala y ACTIVA DNS local en Windows.\nPuede afectar tu conexión si falla. Guardá primero el BAT de recuperación.\n\n¿Confirmás activar VOLVÉ?", MB_YESNOCANCEL|MB_ICONQUESTION)
			if answer == 6 {
				e := requireAdmin("--install-all")
				if e != nil && !errors.Is(e, errSpawned) {
					msg(e.Error(), MB_ICONERROR)
				}
			}
		case idRepairRescue:
			answer := msg("Reparar únicamente la tarea de rescate de VOLVÉ?\n\nSolo si coincide exactamente con el defecto de rutas duplicadas. Conserva el DNS activo, motores, registro, catálogo y el BAT.\n\nEl rescate real ante un fallo seguirá sin estar validado.", MB_YESNOCANCEL|MB_ICONQUESTION)
			if answer == 6 {
				if isAdmin() {
					outcome, er := repairRescueTask()
					if er != nil {
						msg("REPARACIÓN NO CONFIRMADA: "+er.Error(), MB_ICONERROR)
					} else {
						msg(outcome, MB_ICONINFORMATION)
					}
				} else {
					e := requireAdmin("--repair-rescue-task")
					if e != nil && !errors.Is(e, errSpawned) {
						msg("No se abrió reparación: "+e.Error(), MB_ICONERROR)
					}
				}
			}
		case idRestoreDNS:
			answer := msg("¿Restaurar DNS automatico de Windows? Conserva navegadores y hosts.", MB_YESNOCANCEL|MB_ICONQUESTION)
			if answer == 6 {
				e := requireAdmin("--dns-restore")
				if e != nil && !errors.Is(e, errSpawned) {
					msg(e.Error(), MB_ICONERROR)
				}
			}
		case idDoctor:
			e := requireAdmin("--doctor-admin")
			if e != nil && !errors.Is(e, errSpawned) {
				msg("No se abrió el diagnóstico: "+e.Error(), MB_ICONERROR)
			}
		case idInstall:
			e := requireAdmin("--install")
			if e != nil && !errors.Is(e, errSpawned) {
				msg("No se abrió el instalador: "+e.Error(), MB_ICONERROR)
			}
		case idCatalog:
			e := requireAdmin("--refresh-catalog")
			if e != nil && !errors.Is(e, errSpawned) {
				msg("No se abrió el actualizador: "+e.Error(), MB_ICONERROR)
			}
		case idFolder:
			p, e := statePath()
			if e == nil {
				e = shellOpen(filepath.Dir(p))
			}
			if e != nil {
				msg("No pude abrir los datos: "+e.Error(), MB_ICONERROR)
			}
		case idClose:
			user.NewProc("DestroyWindow").Call(w)
		}
		return 0
	case wmPaint:
		if !healthOnlyPanel {
			drawPanelChrome(w)
			return 0
		}
	case wmDrawItem:
		if !healthOnlyPanel {
			drawPanelButton(lp)
			return 1
		}
	case wmCtlColorStatic:
		if panelBgBrush == 0 {
			panelBgBrush, _, _ = dllGDI.NewProc("CreateSolidBrush").Call(colorRef(244, 248, 250))
		}
		dllGDI.NewProc("SetBkMode").Call(wp, 1)
		dllGDI.NewProc("SetTextColor").Call(wp, 0x00453b13)
		return panelBgBrush
	case wmClose:
		user.NewProc("DestroyWindow").Call(w)
		return 0
	case wmDestroy:
		panelTextGuard.Lock()
		panelRequest++
		panelTextGuard.Unlock()
		user.NewProc("PostQuitMessage").Call(0)
		return 0
	}
	r, _, _ := procDef.Call(w, uintptr(message), wp, lp)
	return r
}
func showPanel() {
	// Win32 windows and their GetMessage/DispatchMessage loop must run on the SAME OS thread.
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	hinst, _, _ := dllKernel.NewProc("GetModuleHandleW").Call(0)
	panelCallback = syscall.NewCallback(panelWndProc)
	className := utf16p("VOLVE_PANEL_WINDOW_0283")
	panelBgBrush, _, _ = dllGDI.NewProc("CreateSolidBrush").Call(colorRef(244, 248, 250))
	c := wndClassEx{CbSize: uint32(unsafe.Sizeof(wndClassEx{})), WndProc: panelCallback, HInstance: hinst, Background: panelBgBrush, ClassName: className}
	// IDC_ARROW = MAKEINTRESOURCE(32512)
	c.Cursor, _, _ = user.NewProc("LoadCursorW").Call(0, 32512)
	if r, _, e := procRegister.Call(uintptr(unsafe.Pointer(&c))); r == 0 {
		msg("No pude registrar la ventana de VOLVÉ: "+e.Error(), MB_ICONERROR)
		return
	}
	titleText := "VOLVÉ " + version + " — Centro de protección"
	if healthOnlyPanel {
		titleText = "VOLVÉ " + version + " — Diagnóstico administrador (solo lectura)"
	}
	titlep := utf16p(titleText)
	w, _, e := procCreate.Call(0, uintptr(unsafe.Pointer(className)), uintptr(unsafe.Pointer(titlep)), wsOverlappedWindow|wsVisible, cwUseDefault, cwUseDefault, 914, 706, 0, 0, hinst, 0)
	if w == 0 {
		msg("No se pudo abrir el panel: "+e.Error(), MB_ICONERROR)
		return
	}
	user.NewProc("ShowWindow").Call(w, 5)
	user.NewProc("UpdateWindow").Call(w)
	var m winMessage
	for {
		r, _, _ := user.NewProc("GetMessageW").Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		user.NewProc("TranslateMessage").Call(uintptr(unsafe.Pointer(&m)))
		user.NewProc("DispatchMessageW").Call(uintptr(unsafe.Pointer(&m)))
	}
}

// Place a second copy of this executable in ProgramData and create Start menu
// shortcut so an installed user can reopen the control panel at any time.
// Never touch other shortcuts or programs.
func installPanelShortcut() error {
	if !isAdmin() {
		return errors.New("se requiere administrador")
	}
	path, e := statePath()
	if e != nil {
		return e
	}
	dir := filepath.Dir(path)
	if e = os.MkdirAll(dir, 0700); e != nil {
		return e
	}
	self, e := os.Executable()
	if e != nil {
		return e
	}
	target := filepath.Join(dir, "VOLVE_Centro_Proteccion_"+strings.ReplaceAll(version, ".", "_")+".exe")
	data, e := os.ReadFile(self)
	if e != nil {
		return e
	}
	if old, er := os.ReadFile(target); er == nil {
		if sha256.Sum256(old) == sha256.Sum256(data) {
			return createPanelLinks(target)
		}
		// Windows can deny replacing an executable that is currently running.
		// Do not delete or overwrite such a binary; report and preserve it.
		if er = os.Remove(target); er != nil {
			return fmt.Errorf("panel anterior en uso; cerralo antes de actualizar: %w", er)
		}
	} else if !errors.Is(er, os.ErrNotExist) {
		return er
	}
	tmp, e := os.CreateTemp(dir, ".VOLVE_Centro-*.exe")
	if e != nil {
		return e
	}
	defer os.Remove(tmp.Name())
	if _, e = tmp.Write(data); e != nil {
		tmp.Close()
		return e
	}
	if e = tmp.Sync(); e != nil {
		tmp.Close()
		return e
	}
	if e = tmp.Close(); e != nil {
		return e
	}
	if e = os.Rename(tmp.Name(), target); e != nil {
		return e
	}
	return createPanelLinks(target)
}
func psQuote(s string) string { return "'" + strings.ReplaceAll(s, "'", "''") + "'" }
func createPanelLinks(target string) error {
	pd := os.Getenv("ProgramData")
	if pd == "" {
		return errors.New("ProgramData no disponible para acceso directo")
	}
	locations := []string{filepath.Join(pd, "Microsoft", "Windows", "Start Menu", "Programs", "VOLVE - Centro de proteccion.lnk")}
	if pub := os.Getenv("PUBLIC"); pub != "" {
		locations = append(locations, filepath.Join(pub, "Desktop", "VOLVE - Centro de proteccion.lnk"))
	}
	for _, dst := range locations {
		ps := "$s=(New-Object -ComObject WScript.Shell).CreateShortcut(" + psQuote(dst) + ");" +
			"$s.TargetPath=" + psQuote(target) + ";$s.WorkingDirectory=" + psQuote(filepath.Dir(target)) + ";$s.Description='VOLVE - Centro de proteccion';$s.Save()"
		out, e := hiddenCommand("powershell.exe", "-NoProfile", "-NonInteractive", "-Command", ps).CombinedOutput()
		if e != nil {
			return fmt.Errorf("no pude crear acceso directo %s: %w %s", dst, e, strings.TrimSpace(string(out)))
		}
	}
	return nil
}
