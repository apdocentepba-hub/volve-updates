//go:build windows

package main

import (
	"os/exec"
	"syscall"
)

// Every Windows helper is launched without a console window. In a GUI
// executable, calling reg.exe or schtasks.exe without this can flash
// hundreds of terminal windows during policy verification and repair.
// CREATE_NO_WINDOW also prevents an initial console allocation, which
// HideWindow alone does not guarantee in all Windows configurations.
const createNoWindow = 0x08000000

func hiddenCommand(name string, args ...string) *exec.Cmd {
	cmd := exec.Command(name, args...)
	cmd.SysProcAttr = &syscall.SysProcAttr{
		HideWindow:    true,
		CreationFlags: createNoWindow,
	}
	return cmd
}
