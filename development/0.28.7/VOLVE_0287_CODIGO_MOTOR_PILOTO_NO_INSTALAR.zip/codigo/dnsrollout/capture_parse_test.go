package dnsrollout

import (
	"encoding/binary"
	"errors"
	"strings"
	"testing"
	"unicode/utf16"
)

const goodSnapshot = `{"schema":1,"interface_index":8,"interface_guid":"12345678-9012-3456-7890-123456789012","alias":"Ethernet","restore_mode":"automatic","ipv4":["8.8.8.8"],"ipv6":["2606:4700:4700::1111"]}`

func TestCapturePowerShellJSON(t *testing.T) {
	variants := map[string][]byte{"plain": []byte(goodSnapshot), "utf8-bom": append([]byte{0xEF, 0xBB, 0xBF}, []byte(goodSnapshot)...)}
	utf16data := make([]byte, 2+len(utf16.Encode([]rune(goodSnapshot)))*2)
	utf16data[0] = 0xFF
	utf16data[1] = 0xFE
	for i, v := range utf16.Encode([]rune(goodSnapshot)) {
		binary.LittleEndian.PutUint16(utf16data[2+i*2:], v)
	}
	variants["utf16le-bom"] = utf16data
	for name, b := range variants {
		t.Run(name, func(t *testing.T) {
			snap, err := parseCaptureResult(b, nil, nil)
			if err != nil {
				t.Fatal(err)
			}
			if snap.InterfaceIndex != 8 {
				t.Fatal(snap.InterfaceIndex)
			}
		})
	}
}
func TestCapturePowerShellNeverTrustCLIXML(t *testing.T) {
	tests := []struct {
		name        string
		out, errout []byte
		runerr      error
		want        string
	}{
		{"stderr-serialized", []byte(goodSnapshot), []byte("#< CLIXML\r\nWarning"), nil, "CLIXML"},
		{"combined-old-bug", []byte("#< CLIXML\r\n" + goodSnapshot), nil, nil, "no comienza"},
		{"real-failure", nil, []byte("VOLVE_DNS_CAPTURE_ERROR: Interfaz no accesible"), errors.New("exit status 8"), "Interfaz no accesible"},
		{"empty", nil, nil, nil, "no devolvió"},
		{"trailing", []byte(goodSnapshot + "\nWARNING"), nil, nil, "adicional"},
		{"invalid-ip", []byte(strings.ReplaceAll(goodSnapshot, "8.8.8.8", "127.0.0.1")), nil, nil, "no es segura"},
	}
	for _, x := range tests {
		t.Run(x.name, func(t *testing.T) {
			_, err := parseCaptureResult(x.out, x.errout, x.runerr)
			if err == nil || !strings.Contains(err.Error(), x.want) {
				t.Fatalf("got %v want %q", err, x.want)
			}
		})
	}
}

func TestPowerShellCapturesLegitimateIPv6Router(t *testing.T) {
	for _, ip := range []string{"fe80::1", "fe80::1%8"} {
		src := strings.ReplaceAll(goodSnapshot, "2606:4700:4700::1111", ip)
		snap, e := parseCaptureResult([]byte(src), nil, nil)
		if e != nil {
			t.Fatalf("%s: %v", ip, e)
		}
		if len(snap.IPv6) != 1 || snap.IPv6[0] != ip {
			t.Fatal("modified original DNS")
		}
	}
	src := strings.ReplaceAll(goodSnapshot, "2606:4700:4700::1111", "fe80::1%99")
	if _, e := parseCaptureResult([]byte(src), nil, nil); e == nil {
		t.Fatal("accepted wrong adapter zone")
	}
}

func TestCapturedDuplicateAutomaticWindowsDNSPreserved(t *testing.T) {
	for _, original := range []string{`["fe80::1","FE80:0:0::1"]`, `["2001:4860:4860::8888","2001:4860:4860::8888"]`} {
		src := strings.Replace(goodSnapshot, `["2606:4700:4700::1111"]`, original, 1)
		got, e := parseCaptureResult([]byte(src), nil, nil)
		if e != nil {
			t.Fatalf("automatic duplicates incorrectly rejected: %v", e)
		}
		if len(got.IPv6) != 2 {
			t.Fatalf("raw duplicate list not retained: %#v", got.IPv6)
		}
		if got.DuplicateServers() != 1 {
			t.Fatalf("wrong duplicate count %d", got.DuplicateServers())
		}
		manual := strings.Replace(src, `"restore_mode":"automatic"`, `"restore_mode":"manual"`, 1)
		if _, e := parseCaptureResult([]byte(manual), nil, nil); e == nil {
			t.Fatal("manual duplicates must remain blocked")
		}
	}
}
