package dnsrollout

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"strings"
	"unicode/utf16"
	"unicode/utf8"
	"volve-browser-protection/dnsactivation"
)

// utf16PowerShell converts known Unicode encodings, preserving a strict JSON boundary.
// No prefix searching: stray diagnostics must not be silently ignored.
func utf16PowerShell(b []byte) ([]byte, error) {
	if bytes.HasPrefix(b, []byte{0xEF, 0xBB, 0xBF}) {
		b = b[3:]
	}
	little, big := false, false
	if bytes.HasPrefix(b, []byte{0xFF, 0xFE}) {
		little = true
		b = b[2:]
	}
	if bytes.HasPrefix(b, []byte{0xFE, 0xFF}) {
		big = true
		b = b[2:]
	}
	if !little && !big && len(b) >= 4 && b[1] == 0 && b[3] == 0 {
		little = true
	}
	if little || big {
		if len(b)%2 != 0 {
			return nil, errors.New("salida UTF-16 truncada")
		}
		u := make([]uint16, len(b)/2)
		for i := range u {
			if little {
				u[i] = uint16(b[2*i]) | uint16(b[2*i+1])<<8
			} else {
				u[i] = uint16(b[2*i])<<8 | uint16(b[2*i+1])
			}
		}
		b = []byte(string(utf16.Decode(u)))
	}
	if !utf8.Valid(b) {
		return nil, errors.New("salida de PowerShell no es UTF-8 válido")
	}
	b = bytes.TrimSpace(b)
	b = bytes.TrimPrefix(b, []byte{0xEF, 0xBB, 0xBF})
	return bytes.TrimSpace(b), nil
}

func captureErrorText(b []byte) string {
	decoded, e := utf16PowerShell(b)
	if e != nil {
		return "salida de error no decodificable"
	}
	s := strings.TrimSpace(string(decoded))
	if len(s) > 1200 {
		s = s[:1200] + "…"
	}
	if s == "" {
		return "sin detalle de PowerShell"
	}
	if strings.HasPrefix(s, "#< CLIXML") {
		return "PowerShell informó un error serializado en CLIXML; revisar registros del sistema"
	}
	return s
}

func parseCaptureResult(stdout, stderr []byte, cmdErr error) (dnsactivation.Snapshot, error) {
	var s dnsactivation.Snapshot
	if len(stdout) > 64*1024 || len(stderr) > 64*1024 {
		return s, errors.New("respuesta DNS excesiva")
	}
	if cmdErr != nil {
		return s, fmt.Errorf("consulta DNS de Windows falló: %v; %s", cmdErr, captureErrorText(stderr))
	}
	if len(bytes.TrimSpace(stderr)) != 0 {
		return s, fmt.Errorf("PowerShell informó problemas durante el inventario: %s", captureErrorText(stderr))
	}
	plain, err := utf16PowerShell(stdout)
	if err != nil {
		return s, fmt.Errorf("no pude decodificar inventario DNS: %w", err)
	}
	if len(plain) == 0 {
		return s, errors.New("PowerShell no devolvió datos DNS; revisar permisos y configuración")
	}
	if !bytes.HasPrefix(plain, []byte{'{'}) {
		return s, fmt.Errorf("inventario no comienza con JSON; inicio recibido: %q", string(plain[:min(len(plain), 100)]))
	}
	d := json.NewDecoder(bytes.NewReader(plain))
	d.DisallowUnknownFields()
	if err = d.Decode(&s); err != nil {
		return s, fmt.Errorf("JSON del inventario DNS inválido: %w", err)
	}
	// Reject trailing values/logs even if a snapshot was valid.
	var extra interface{}
	if err = d.Decode(&extra); err == nil {
		return s, errors.New("inventario DNS contiene datos adicionales")
	} else if err != io.EOF {
		return s, fmt.Errorf("inventario DNS incluye texto adicional: %w", err)
	}
	if err = s.Validate(); err != nil {
		return s, fmt.Errorf("configuración DNS no es segura para el ensayo: %w", err)
	}
	return s, nil
}
