package dnsrollout

// A rehearsal exercises a real listener on loopback:53 and the production
// rollback transaction with an in-memory adapter. It deliberately does NOT
// register tasks, persist a real adapter backup or change a Windows DNS setting.
import (
	"context"
	"errors"
	"fmt"
	"os"
	"strings"
	"time"

	"volve-browser-protection/dnsactivation"
	"volve-browser-protection/dnspreflight"
)

type simulation struct {
	original        dnsactivation.Snapshot
	loopback        bool
	restoreVerified bool
	injectedFailure bool
}

func (s *simulation) Capture(context.Context) (dnsactivation.Snapshot, error)  { return s.original, nil }
func (s *simulation) Preflight(context.Context, dnsactivation.Snapshot) error  { return nil }
func (s *simulation) ArmRescue(context.Context) error                          { return nil }
func (s *simulation) VerifyRescue(context.Context) error                       { return nil }
func (s *simulation) StartMotor(context.Context, dnsactivation.Snapshot) error { return nil }
func (s *simulation) VerifyMotor(context.Context) error                        { return nil }
func (s *simulation) SetLoopback(_ context.Context, _ dnsactivation.Snapshot) error {
	s.loopback = true
	return nil
}
func (s *simulation) VerifyWindowsDNS(context.Context, dnsactivation.Snapshot) error {
	if s.injectedFailure {
		return errors.New("FALLO INYECTADO: el adaptador simulado no resuelve")
	}
	if !s.loopback {
		return errors.New("adaptador simulado aún sin loopback")
	}
	return nil
}
func (s *simulation) RestoreDNS(context.Context, dnsactivation.Snapshot) error {
	s.loopback = false
	return nil
}
func (s *simulation) VerifyRestored(context.Context, dnsactivation.Snapshot) error {
	if s.loopback {
		return errors.New("no volvió el DNS original")
	}
	s.restoreVerified = true
	return nil
}
func (s *simulation) StopNewMotor(context.Context) error { return nil }

// SimulateRollback uses the exact transaction implementation that future
// privileged code must call, including the journal and compensation routine.
// Only temporary files, and a simulated adapter, are modified.
func SimulateRollback(s dnsactivation.Snapshot) error {
	if err := s.Validate(); err != nil {
		return fmt.Errorf("inventario original no es apto: %w", err)
	}
	folder, err := os.MkdirTemp("", "volve-dns-rehearsal-")
	if err != nil {
		return err
	}
	defer os.RemoveAll(folder)
	store := dnsactivation.FileStore{Directory: folder}
	d := &simulation{original: s, injectedFailure: true}
	ctx, cancel := context.WithTimeout(context.Background(), 12*time.Second)
	defer cancel()
	failure := dnsactivation.Activate(ctx, store, d)
	if failure == nil || !strings.Contains(strings.ToLower(failure.Error()), "restored") {
		return fmt.Errorf("fallo provocado no restaurado correctamente: %v", failure)
	}
	if !d.restoreVerified || d.loopback {
		return errors.New("no se confirmó recuperación del adaptador simulado")
	}
	j, err := store.Load()
	if err != nil || j != nil {
		return fmt.Errorf("diario del fallo no quedó limpio: %#v %v", j, err)
	}
	return nil
}

func Rehearse(catalogDir string, minFull int) (string, error) {
	original, err := CaptureOriginalDNS(context.Background())
	if err != nil {
		return "ENSAYO NO APROBADO: no pude verificar la configuración DNS original (solo lectura): " + err.Error() + "\nNo se modificó ningún adaptador.", err
	}
	if err := original.Validate(); err != nil {
		return "ENSAYO NO APROBADO: respaldo DNS incompatible: " + err.Error() + "\nNo se modificó ningún adaptador.", err
	}
	r, err := dnspreflight.VerifyOnPort53(catalogDir, minFull)
	if err != nil {
		return "ENSAYO NO APROBADO: el motor no pudo pasar la prueba real en loopback:53: " + err.Error() + "\nNo se modificó ningún adaptador.", err
	}
	if !r.IPv4 || !r.TCP || !r.Port53IPv4 {
		err = errors.New("no se verificó UDP y TCP sobre localhost:53")
		return "ENSAYO NO APROBADO: " + err.Error(), err
	}
	if err = SimulateRollback(original); err != nil {
		return "ENSAYO NO APROBADO: transacción simulada no recuperó: " + err.Error(), err
	}
	result := fmt.Sprintf("ENSAYO DE ACTIVACIÓN Y RECUPERACIÓN: APROBADO (SIN CAMBIAR WINDOWS)\n\nAdaptador original identificado en modo %s (solo lectura); IPv4: %d servidor(es), IPv6: %d servidor(es).\nHaGeZi Full real leído: %d dominios. Reglas cargadas: %d.\nMotor DNS en 127.0.0.1:53 (UDP + TCP): bloqueo real y permiso controlado OK.\nMotor temporal detenido al finalizar la prueba; puerto 53 liberado.\n\nFallo provocado después de conmutar un ADAPTADOR SIMULADO: restauración del estado original confirmada; diario limpiado.\n\nATENCIÓN: No se modificó el DNS de ningún adaptador, ni se creó tarea de rescate SYSTEM real. Esta prueba NO confirma recuperación de Windows tras un corte eléctrico. NO activar el DNS de producción hasta validar el rescate real en máquina de pruebas.", original.RestoreMode, len(original.IPv4), len(original.IPv6), r.FullDomains, r.TotalRules)
	if repeated := original.DuplicateServers(); repeated > 0 {
		result += fmt.Sprintf("\nAVISO: Windows informó %d DNS original(es) repetido(s) en modo AUTOMÁTICO. El inventario conserva exactamente las entradas originales y el ensayo de reversión es SIMULADO: todavía falta probar recuperación DHCP real.", repeated)
	}
	for _, raw := range original.IPv6 {
		if strings.HasPrefix(strings.ToLower(raw), "fe80:") {
			result += "\nAVISO: Windows usa DNS IPv6 de enlace local. Se preservó el valor original; aún NO se verificó una recuperación real de ese DNS."
			break
		}
	}
	if !r.IPv6 {
		result += "\nIPv6 loopback no verificado: " + r.IPv6Warning
	}
	return result, nil
}
