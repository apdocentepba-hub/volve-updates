//go:build windows

package dnsrollout

import (
	"bytes"
	"context"
	"encoding/base64"
	"errors"
	"os"
	"os/exec"
	"syscall"
	"time"
	"unicode/utf16"
	"volve-browser-protection/dnsactivation"
)

// This script has NO Set-* commands. It only observes the original DNS config.
const snapshotReadOnly = `
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding=[System.Text.Encoding]::UTF8
try {
$adapters=@(Get-NetAdapter -ErrorAction Stop | Where-Object {
  $_.Status -eq 'Up' -and $_.HardwareInterface -and
  $null -ne (Get-NetIPInterface -InterfaceIndex ([int]$_.ifIndex) -AddressFamily IPv4 -ErrorAction SilentlyContinue)
})
if($adapters.Count -ne 1){throw "Se necesita exactamente una interfaz física IPv4 activa, se detectaron $($adapters.Count)"}
$a=$adapters[0]
$index=[int]$a.ifIndex
$guid=([string]$a.InterfaceGuid).Trim('{','}')
$ipv4=@((Get-DnsClientServerAddress -InterfaceIndex $index -AddressFamily IPv4 -ErrorAction Stop).ServerAddresses | Where-Object {$_})
$ipv6=@((Get-DnsClientServerAddress -InterfaceIndex $index -AddressFamily IPv6 -ErrorAction Stop).ServerAddresses | Where-Object {$_})
$r4=Get-ItemProperty -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\{$guid}" -ErrorAction Stop
$r6=Get-ItemProperty -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters\Interfaces\{$guid}" -ErrorAction SilentlyContinue
$m4=![string]::IsNullOrWhiteSpace([string]$r4.NameServer)
$m6=![string]::IsNullOrWhiteSpace([string]$r6.NameServer)
if($m4 -ne $m6){throw 'Hay asignación DNS mixta IPv4/IPv6, no habilitar activación automática'}
$mode=if($m4){'manual'}else{'automatic'}
$snapshot=@{schema=1;interface_index=$index;interface_guid=$guid;alias=[string]$a.Name;restore_mode=$mode;ipv4=@($ipv4);ipv6=@($ipv6)}
$json=ConvertTo-Json -InputObject $snapshot -Compress -Depth 5
[Console]::Out.WriteLine($json)
} catch {
  [Console]::Error.WriteLine('VOLVE_DNS_CAPTURE_ERROR: ' + $_.Exception.Message)
  exit 8
}
`

func CaptureOriginalDNS(parent context.Context) (dnsactivation.Snapshot, error) {
	var s dnsactivation.Snapshot
	ctx, cancel := context.WithTimeout(parent, 12*time.Second)
	defer cancel()
	if os.Getenv("ProgramData") == "" {
		return s, errors.New("ProgramData no disponible")
	}
	units := utf16.Encode([]rune(snapshotReadOnly))
	encoded := make([]byte, 2*len(units))
	for i, u := range units {
		encoded[i*2] = byte(u)
		encoded[i*2+1] = byte(u >> 8)
	}
	cmd := exec.CommandContext(ctx, "powershell.exe", "-NoProfile", "-NonInteractive", "-EncodedCommand", base64.StdEncoding.EncodeToString(encoded))
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	// Windows PowerShell 5.1 can send CLIXML diagnostics to stderr, beginning
	// with '#< CLIXML'. CombinedOutput mixed these diagnostics into JSON.
	// Keep streams separate and never accept errors as a valid DNS snapshot.
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err := cmd.Run()
	if ctx.Err() != nil {
		return s, errors.New("la lectura de interfaces excedió 12 segundos")
	}
	return parseCaptureResult(stdout.Bytes(), stderr.Bytes(), err)
}
