//go:build !windows

package dnsrollout

import (
	"context"
	"errors"
	"volve-browser-protection/dnsactivation"
)

func CaptureOriginalDNS(context.Context) (dnsactivation.Snapshot, error) {
	return dnsactivation.Snapshot{}, errors.New("esta auditoría requiere Windows")
}
