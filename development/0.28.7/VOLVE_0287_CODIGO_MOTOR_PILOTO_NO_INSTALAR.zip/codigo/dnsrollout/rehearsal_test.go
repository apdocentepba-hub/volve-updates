package dnsrollout

import (
	"testing"
	"volve-browser-protection/dnsactivation"
)

func TestSimulatedRollbackRestoresOriginal(t *testing.T) {
	s := dnsactivation.Snapshot{Schema: 1, InterfaceIndex: 4, InterfaceGUID: "bd0e8d73-b193-4f9b-a1d8-ef1192148612", Alias: "Ethernet", RestoreMode: "automatic", IPv4: []string{"192.0.2.53"}, IPv6: []string{"2001:db8::1"}}
	if err := SimulateRollback(s); err != nil {
		t.Fatal(err)
	}
}
func TestInvalidSnapshotRejected(t *testing.T) {
	s := dnsactivation.Snapshot{Schema: 1, InterfaceIndex: 4, InterfaceGUID: "hello", Alias: "Ethernet", RestoreMode: "manual"}
	if err := SimulateRollback(s); err == nil {
		t.Fatal("unsafe snapshot accepted")
	}
}

// A DHCP resolver list can include repeated server addresses. Rehearsal must
// never rewrite the original raw list or treat it as evidence of live rollback.
func TestSimulatedRollbackWithDHCPDuplicates(t *testing.T) {
	s := dnsactivation.Snapshot{Schema: 1, InterfaceIndex: 8, InterfaceGUID: "12345678-9012-3456-7890-123456789012", Alias: "Ethernet", RestoreMode: "automatic", IPv4: []string{"192.0.2.53"}, IPv6: []string{"fe80::1", "fe80::1"}}
	if err := SimulateRollback(s); err != nil {
		t.Fatal(err)
	}
	if len(s.IPv6) != 2 || s.DuplicateServers() != 1 {
		t.Fatal("original DNS array was altered")
	}
	s.RestoreMode = "manual"
	if err := SimulateRollback(s); err == nil {
		t.Fatal("manual duplicates were incorrectly accepted")
	}
}
