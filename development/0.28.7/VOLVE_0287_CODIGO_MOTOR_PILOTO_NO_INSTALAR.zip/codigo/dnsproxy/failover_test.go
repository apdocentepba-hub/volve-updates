package dnsproxy

import (
	"context"
	"encoding/binary"
	"net"
	"strings"
	"testing"
	"time"
	"volve-browser-protection/blocker"
)

// Simulate a router that silently stops answering and verify that the second
// upstream still resolves ordinary domains, while betting blocks remain local.
func TestSlowFirstUpstreamStillAllowsHealthyFallback(t *testing.T) {
	stalled, err := net.ListenPacket("udp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer stalled.Close()
	working, err := net.ListenPacket("udp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer working.Close()
	go func() {
		buf := make([]byte, 2048)
		for {
			n, client, e := working.ReadFrom(buf)
			if e != nil {
				return
			}
			_, end, e := readQName(buf[:n])
			if e != nil {
				continue
			}
			ans := append([]byte(nil), buf[:end]...)
			ans[2], ans[3] = 0x81, 0x80
			binary.BigEndian.PutUint16(ans[6:8], 1)
			ans = append(ans, 0xc0, 0x0c, 0, 1, 0, 1, 0, 0, 0, 10, 0, 4, 93, 184, 215, 14)
			_, _ = working.WriteTo(ans, client)
		}
	}()
	probeAddr, err := net.ListenPacket("udp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	port := probeAddr.LocalAddr().(*net.UDPAddr).Port
	probeAddr.Close()
	ctx, cancel := context.WithCancel(context.Background())
	srv := New(blocker.New(nil, true), []string{stalled.LocalAddr().String(), working.LocalAddr().String()})
	done := make(chan error, 1)
	go func() { done <- srv.Run(ctx, "127.0.0.1", port) }()
	select {
	case <-srv.Ready():
	case e := <-done:
		t.Fatal(e)
	case <-time.After(time.Second):
		t.Fatal("not ready")
	}
	start := time.Now()
	err = Probe(net.JoinHostPort("127.0.0.1", itoa(port)), "test.casino.bet.ar", "example.org")
	elapsed := time.Since(start)
	cancel()
	select {
	case <-done:
	case <-time.After(3 * time.Second):
		t.Fatal("server failed to stop")
	}
	if err != nil {
		t.Fatalf("failover should survive a nonresponding first resolver: %v", err)
	}
	if elapsed >= 8*time.Second {
		t.Fatalf("failover too slow: %s", elapsed)
	}
}

func TestProbeIdentifiesDomainOnTimeout(t *testing.T) {
	listen, err := net.ListenPacket("udp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer listen.Close()
	err = Probe(listen.LocalAddr().String(), "test.casino.bet.ar", "example.org")
	if err == nil || !strings.Contains(err.Error(), "test.casino.bet.ar") {
		t.Fatalf("missing useful timeout domain: %v", err)
	}
}
