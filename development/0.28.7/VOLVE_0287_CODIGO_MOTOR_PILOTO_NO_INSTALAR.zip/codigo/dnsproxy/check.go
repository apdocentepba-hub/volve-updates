package dnsproxy

import (
	"context"
	"errors"
	"fmt"
	"net"
	"time"
)

// QueryRCode makes a direct DNS UDP query. It does not use hosts, change any
// resolver setting or open the domain in a browser.
func QueryRCode(ctx context.Context, server, domain string) (byte, error) {
	query := makeDNSQuestion(domain)
	dialer := net.Dialer{Timeout: 1200 * time.Millisecond}
	c, err := dialer.DialContext(ctx, "udp", server)
	if err != nil {
		return 0, err
	}
	defer c.Close()
	deadline := time.Now().Add(1900 * time.Millisecond)
	if d, ok := ctx.Deadline(); ok && d.Before(deadline) {
		deadline = d
	}
	if err = c.SetDeadline(deadline); err != nil {
		return 0, err
	}
	if _, err = c.Write(query); err != nil {
		return 0, err
	}
	answer := make([]byte, 2048)
	n, err := c.Read(answer)
	if err != nil {
		return 0, err
	}
	if n < 12 || answer[0] != query[0] || answer[1] != query[1] {
		return 0, fmt.Errorf("respuesta DNS mal formada de %s", server)
	}
	if answer[2]&0x80 == 0 {
		return 0, errors.New("respuesta no tiene bandera QR")
	}
	return answer[3] & 0xf, nil
}
