package dnsproxy

import (
	"context"
	"encoding/binary"
	"net"
	"testing"
	"time"
	"volve-browser-protection/blocker"
)

func query(name string) []byte {
	q := make([]byte, 12)
	binary.BigEndian.PutUint16(q[0:2], 0x9143)
	binary.BigEndian.PutUint16(q[2:4], 0x0100)
	binary.BigEndian.PutUint16(q[4:6], 1)
	for _, label := range split(name) {
		q = append(q, byte(len(label)))
		q = append(q, []byte(label)...)
	}
	q = append(q, 0, 0, 1, 0, 1)
	return q
}
func split(s string) []string {
	a := []string{}
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '.' {
			a = append(a, s[start:i])
			start = i + 1
		}
	}
	return append(a, s[start:])
}
func TestExactAndDeepWildcardDNS(t *testing.T) {
	b := blocker.New([]string{"stake.com"}, true)
	s := New(b, nil)
	for _, name := range []string{"bet.ar", "pba.stake.bet.ar", "more.even.deeper.stake.bet.ar", "pba.betsson.bet.ar", "foo.stake.com"} {
		msg := query(name)
		response, e := s.handle(msg)
		if e != nil || len(response) < 16 || response[3]&0xf != 3 {
			t.Fatalf("not NXDOMAIN %s: %v", name, e)
		}
		if response[0] != msg[0] || response[1] != msg[1] {
			t.Fatal("transaction ID mismatch")
		}
	}
}
func TestNormalDNSForwardsToFakeUpstream(t *testing.T) {
	listener, e := net.ListenPacket("udp", "127.0.0.1:0")
	if e != nil {
		t.Fatal(e)
	}
	defer listener.Close()
	go func() {
		b := make([]byte, 512)
		n, a, er := listener.ReadFrom(b)
		if er != nil {
			return
		}
		r := append([]byte(nil), b[:n]...)
		r[2] = 0x81
		r[3] = 0x80
		listener.WriteTo(r, a)
	}()
	proxy := New(blocker.New([]string{}, true), []string{listener.LocalAddr().String()})
	msg := query("example.org")
	r, e := proxy.handle(msg)
	if e != nil || len(r) == 0 || r[3] != 0x80 {
		t.Fatalf("forward failed: %v %v", e, r)
	}
}
func TestInvalidQuestionNotForwarded(t *testing.T) {
	s := New(blocker.New(nil, true), nil)
	_, e := s.handle([]byte{0})
	if e == nil {
		t.Fatal("bad packet was accepted")
	}
}
func TestDoesNotBindPublicIP(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), time.Millisecond)
	defer cancel()
	s := New(blocker.New(nil, true), nil)
	if e := s.Run(ctx, "0.0.0.0", 53555); e == nil {
		t.Fatal("public listener allowed")
	}
}
func TestLiveLoopbackUDP(t *testing.T) {
	// Allocate free port, release, then bind for a local integration test.
	temp, e := net.ListenPacket("udp", "127.0.0.1:0")
	if e != nil {
		t.Fatal(e)
	}
	port := temp.LocalAddr().(*net.UDPAddr).Port
	temp.Close()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	s := New(blocker.New(nil, true), nil)
	done := make(chan error, 1)
	go func() { done <- s.Run(ctx, "127.0.0.1", port) }()
	select {
	case <-s.Ready():
	case e := <-done:
		t.Fatalf("DNS server failed: %v", e)
	case <-time.After(2 * time.Second):
		t.Fatal("did not start")
	}
	c, e := net.DialTimeout("udp", net.JoinHostPort("127.0.0.1", itoa(port)), time.Second)
	if e != nil {
		t.Fatal(e)
	}
	defer c.Close()
	c.SetDeadline(time.Now().Add(time.Second))
	if _, e = c.Write(query("unknown.bet.ar")); e != nil {
		t.Fatal(e)
	}
	res := make([]byte, 2048)
	n, e := c.Read(res)
	if e != nil {
		t.Fatal(e)
	}
	if n < 12 || res[3]&15 != 3 {
		t.Fatalf("expected NXDOMAIN, got %v", res[:n])
	}
	cancel()
	select {
	case e = <-done:
		if e != nil {
			t.Fatal(e)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("did not stop")
	}
}
func itoa(v int) string {
	if v == 0 {
		return "0"
	}
	s := ""
	for v > 0 {
		s = string(rune('0'+v%10)) + s
		v /= 10
	}
	return s
}
