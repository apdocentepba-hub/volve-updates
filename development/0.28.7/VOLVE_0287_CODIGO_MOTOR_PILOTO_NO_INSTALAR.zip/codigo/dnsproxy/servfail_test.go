package dnsproxy

import (
	"context"
	"net"
	"strconv"
	"testing"
	"time"
	"volve-browser-protection/blocker"
)

func TestNoUpstreamsReturnsServfailNotTimeout(t *testing.T) {
	temp, err := net.ListenPacket("udp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	port := temp.LocalAddr().(*net.UDPAddr).Port
	temp.Close()
	ctx, cancel := context.WithCancel(context.Background())
	srv := New(blocker.New(nil, true), nil)
	done := make(chan error, 1)
	go func() { done <- srv.Run(ctx, "127.0.0.1", port) }()
	select {
	case <-srv.Ready():
	case <-time.After(time.Second):
		t.Fatal("not ready")
	}
	conn, err := net.DialTimeout("udp", "127.0.0.1:"+strconv.Itoa(port), time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	if err := conn.SetDeadline(time.Now().Add(500 * time.Millisecond)); err != nil {
		t.Fatal(err)
	}
	q := query("example.org")
	if _, err := conn.Write(q); err != nil {
		t.Fatal(err)
	}
	b := make([]byte, 1024)
	n, err := conn.Read(b)
	cancel()
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("server did not stop")
	}
	if err != nil || n < 12 || b[3]&15 != 2 {
		t.Fatalf("expected fast SERVFAIL on upstream outage, got %d %v", n, err)
	}
}
