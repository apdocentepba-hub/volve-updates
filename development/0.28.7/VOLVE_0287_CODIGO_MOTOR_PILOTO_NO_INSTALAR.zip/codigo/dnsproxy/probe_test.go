package dnsproxy

import (
	"context"
	"encoding/binary"
	"net"
	"strconv"
	"testing"
	"time"
	"volve-browser-protection/blocker"
)

// This test exercises the real UDP server and client, not just the rules matching.
func TestProbeRealSockets(t *testing.T) {
	upstream, err := net.ListenPacket("udp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer upstream.Close()
	go func() {
		b := make([]byte, 2048)
		for {
			n, peer, e := upstream.ReadFrom(b)
			if e != nil {
				return
			}
			q := append([]byte{}, b[:n]...)
			_, end, e := readQName(q)
			if e != nil {
				continue
			}
			resp := append([]byte{}, q[:end]...)
			resp[2], resp[3] = 0x81, 0x80
			binary.BigEndian.PutUint16(resp[6:8], 1)
			resp = append(resp, 0xc0, 0x0c, 0, 1, 0, 1, 0, 0, 0, 60, 0, 4, 93, 184, 215, 14)
			_, _ = upstream.WriteTo(resp, peer)
		}
	}()
	free, e := net.ListenPacket("udp", "127.0.0.1:0")
	if e != nil {
		t.Fatal(e)
	}
	port := free.LocalAddr().(*net.UDPAddr).Port
	free.Close()
	ctx, cancel := context.WithCancel(context.Background())
	srv := New(blocker.New([]string{"stake.com"}, true), []string{upstream.LocalAddr().String()})
	done := make(chan error, 1)
	go func() { done <- srv.Run(ctx, "127.0.0.1", port) }()
	select {
	case <-srv.Ready():
	case <-time.After(time.Second):
		t.Fatal("server not ready")
	}
	err = Probe(net.JoinHostPort("127.0.0.1", strconv.Itoa(port)), "pba.stake.bet.ar", "example.org")
	cancel()
	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("server did not stop")
	}
	if err != nil {
		t.Fatal(err)
	}
}
