package dnsproxy

import (
	"context"
	"encoding/binary"
	"fmt"
	"net"
	"strings"
	"time"
	"volve-browser-protection/blocker"
)

// SelfTest checks DNS on loopback without modifying Windows adapters, hosts, or registry.
func SelfTest() (string, error) {
	data := blocker.New([]string{"betwarrior.bet.ar", "stake.com", "casino.test"}, true)
	upstream, err := net.ListenPacket("udp", "127.0.0.1:0")
	if err != nil {
		return "", err
	}
	defer upstream.Close()
	go func() {
		q := make([]byte, 2048)
		for {
			n, peer, e := upstream.ReadFrom(q)
			if e != nil {
				return
			}
			r := append([]byte{}, q[:n]...)
			if len(r) > 12 {
				r[2] = 0x81
				r[3] = 0x80
				_, _ = upstream.WriteTo(r, peer)
			}
		}
	}()
	server := New(data, []string{upstream.LocalAddr().String()})
	temp, err := net.ListenPacket("udp", "127.0.0.1:0")
	if err != nil {
		return "", err
	}
	port := temp.LocalAddr().(*net.UDPAddr).Port
	temp.Close()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := make(chan error, 1)
	go func() { done <- server.Run(ctx, "127.0.0.1", port) }()
	select {
	case <-server.Ready():
	case e := <-done:
		return "", fmt.Errorf("DNS test server failed: %w", e)
	case <-time.After(2 * time.Second):
		return "", fmt.Errorf("DNS test server did not start")
	}
	conn, err := net.DialTimeout("udp", fmt.Sprintf("127.0.0.1:%d", port), time.Second)
	if err != nil {
		return "", err
	}
	defer conn.Close()
	check := func(host string, expectBlocked bool) error {
		m := makeDNSQuestion(host)
		if e := conn.SetDeadline(time.Now().Add(2 * time.Second)); e != nil {
			return e
		}
		if _, e := conn.Write(m); e != nil {
			return e
		}
		buffer := make([]byte, 2048)
		n, e := conn.Read(buffer)
		if e != nil {
			return e
		}
		if n < 12 || binary.BigEndian.Uint16(buffer[0:2]) != binary.BigEndian.Uint16(m[0:2]) {
			return fmt.Errorf("invalid DNS reply for %s", host)
		}
		rcode := buffer[3] & 0x0f
		if expectBlocked && rcode != 3 {
			return fmt.Errorf("%s should be blocked, rcode=%d", host, rcode)
		}
		if !expectBlocked && rcode != 0 {
			return fmt.Errorf("%s should be allowed, rcode=%d", host, rcode)
		}
		return nil
	}
	for _, c := range []struct {
		domain  string
		blocked bool
	}{
		{"nueva.apuesta.bet.ar", true}, {"pba.stake.bet.ar", true}, {"deeper.mirror.stake.com", true}, {"example.org", false}, {"salud.gob.ar", false},
	} {
		if err = check(c.domain, c.blocked); err != nil {
			cancel()
			<-done
			return "", err
		}
	}
	cancel()
	select {
	case err = <-done:
		if err != nil {
			return "", err
		}
	case <-time.After(time.Second * 3):
		return "", fmt.Errorf("DNS server did not stop")
	}
	return "5 consultas DNS respondidas correctamente: 3 bloqueadas, 2 permitidas. Puerto local temporal; Windows NO modificado.", nil
}
func makeDNSQuestion(host string) []byte {
	q := []byte{0x41, 0x56, 0x01, 0x00, 0, 1, 0, 0, 0, 0, 0, 0}
	for _, p := range strings.Split(host, ".") {
		q = append(q, byte(len(p)))
		q = append(q, []byte(p)...)
	}
	return append(q, 0, 0, 1, 0, 1)
}
