package dnsproxy

import (
	"context"
	"net"
	"testing"
)

func TestQueryRCode(t *testing.T) {
	pc, err := net.ListenPacket("udp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer pc.Close()
	go func() {
		buf := make([]byte, 1024)
		n, peer, err := pc.ReadFrom(buf)
		if err != nil {
			return
		}
		_, end, err := readQName(buf[:n])
		if err != nil {
			return
		}
		_, _ = pc.WriteTo(NXDOMAIN(buf[:n], end), peer)
	}()
	code, err := QueryRCode(context.Background(), pc.LocalAddr().String(), "bet365.com")
	if err != nil || code != 3 {
		t.Fatalf("rcode=%d, err=%v", code, err)
	}
}
