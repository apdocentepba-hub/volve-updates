package dnsproxy

import (
	"context"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"net"
	"strings"
	"sync"
	"sync/atomic"
	"time"
	"volve-browser-protection/blocker"
)

type Server struct {
	ready     chan struct{}
	rules     atomic.Pointer[blocker.Engine]
	upstreams []string
	timeout   time.Duration
	udp       net.PacketConn
	tcp       net.Listener
	wg        sync.WaitGroup
}

func New(rules *blocker.Engine, upstreams []string) *Server {
	s := &Server{upstreams: append([]string(nil), upstreams...), timeout: 1800 * time.Millisecond, ready: make(chan struct{})}
	s.rules.Store(rules)
	return s
}
func (s *Server) Ready() <-chan struct{}      { return s.ready }
func (s *Server) SwapRules(e *blocker.Engine) { s.rules.Store(e) }
func readQName(msg []byte) (string, int, error) {
	if len(msg) < 17 {
		return "", 0, errors.New("invalid DNS header")
	}
	if binary.BigEndian.Uint16(msg[4:6]) != 1 {
		return "", 0, errors.New("query must have exactly one question")
	}
	var labels []string
	pos := 12
	for steps := 0; steps < 128; steps++ {
		if pos >= len(msg) {
			return "", 0, io.ErrUnexpectedEOF
		}
		n := int(msg[pos])
		pos++
		if n == 0 {
			if pos+4 > len(msg) {
				return "", 0, io.ErrUnexpectedEOF
			}
			return strings.Join(labels, "."), pos + 4, nil
		}
		// Compression pointers in DNS questions are legal but not expected from local stubs.
		// Reject rather than misparse and forward malicious packets.
		if n&0xc0 != 0 || n > 63 || pos+n > len(msg) {
			return "", 0, errors.New("invalid or compressed question")
		}
		labels = append(labels, string(msg[pos:pos+n]))
		pos += n
	}
	return "", 0, errors.New("too many labels")
}
func NXDOMAIN(query []byte, questionEnd int) []byte {
	resp := make([]byte, questionEnd)
	copy(resp, query[:questionEnd])
	flags := uint16(0x8083) | binary.BigEndian.Uint16(query[2:4])&0x0100
	binary.BigEndian.PutUint16(resp[2:4], flags)
	// ANCOUNT NSCOUNT and ARCOUNT all zero: strip EDNS and additional records.
	for i := 6; i < 12; i++ {
		resp[i] = 0
	}
	return resp
}

// SERVFAIL is returned when forwarding fails. A valid response allows the
// client and watchdog to distinguish a broken upstream from a dead local motor.
func SERVFAIL(query []byte) []byte {
	_, end, err := readQName(query)
	if err != nil {
		return nil
	}
	reply := NXDOMAIN(query, end)
	reply[3] = (reply[3] & 0xF0) | 2
	return reply
}

func (s *Server) handle(query []byte) ([]byte, error) {
	host, end, e := readQName(query)
	if e != nil {
		return nil, e
	}
	if rule := s.rules.Load(); rule != nil {
		if yes, _ := rule.Match(host); yes {
			return NXDOMAIN(query, end), nil
		}
	}
	var last error
	for _, target := range s.upstreams {
		conn, e := net.DialTimeout("udp", target, s.timeout)
		if e != nil {
			last = e
			continue
		}
		_ = conn.SetDeadline(time.Now().Add(s.timeout))
		if _, e = conn.Write(query); e != nil {
			last = e
			conn.Close()
			continue
		}
		response := make([]byte, 65535)
		n, re := conn.Read(response)
		conn.Close()
		if re != nil {
			last = re
			continue
		}
		if n < 12 || response[0] != query[0] || response[1] != query[1] {
			last = errors.New("invalid DNS upstream response")
			continue
		}
		return response[:n], nil
	}
	return nil, fmt.Errorf("upstreams failed: %w", last)
}
func (s *Server) Run(ctx context.Context, host string, port int) error {
	// Only loopback listeners are permitted. NO public DNS server exposed.
	if host != "127.0.0.1" && host != "::1" {
		return errors.New("only loopback listeners are allowed")
	}
	addr := net.JoinHostPort(host, fmt.Sprint(port))
	udp, e := net.ListenPacket("udp", addr)
	if e != nil {
		return e
	}
	s.udp = udp
	tcp, e := net.Listen("tcp", addr)
	if e != nil {
		udp.Close()
		return e
	}
	s.tcp = tcp
	close(s.ready)
	s.wg.Add(2)
	go func() {
		defer s.wg.Done()
		buf := make([]byte, 65535)
		for {
			n, peer, e := udp.ReadFrom(buf)
			if e != nil {
				return
			}
			query := append([]byte(nil), buf[:n]...)
			// Each packet is separately allocated for safe concurrency.
			s.wg.Add(1)
			go func(q []byte, a net.Addr) {
				defer s.wg.Done()
				r, e := s.handle(q)
				if e != nil {
					r = SERVFAIL(q)
				}
				if len(r) >= 12 {
					_, _ = udp.WriteTo(r, a)
				}
			}(query, peer)
		}
	}()
	go func() {
		defer s.wg.Done()
		for {
			c, e := tcp.Accept()
			if e != nil {
				return
			}
			s.wg.Add(1)
			go func() {
				defer s.wg.Done()
				defer c.Close()
				_ = c.SetDeadline(time.Now().Add(12 * time.Second))
				var length [2]byte
				if _, e := io.ReadFull(c, length[:]); e != nil {
					return
				}
				n := int(binary.BigEndian.Uint16(length[:]))
				if n < 12 || n > 65500 {
					return
				}
				q := make([]byte, n)
				if _, e := io.ReadFull(c, q); e != nil {
					return
				}
				ans, e := s.handle(q)
				if e != nil {
					ans = SERVFAIL(q)
				}
				if len(ans) < 12 {
					return
				}
				binary.BigEndian.PutUint16(length[:], uint16(len(ans)))
				_, _ = c.Write(length[:])
				_, _ = c.Write(ans)
			}()
		}
	}()
	<-ctx.Done()
	udp.Close()
	tcp.Close()
	s.wg.Wait()
	return nil
}

// Probe verifies the locally running DNS proxy without modifying OS settings.
// It requires NXDOMAIN for a betting domain and at least one A answer for a safe domain.
func Probe(addr, blocked, allowed string) error {
	check := func(host string, wantBlocked bool) error {
		q := makeDNSQuestion(host)
		conn, err := net.DialTimeout("udp", addr, 1500*time.Millisecond)
		if err != nil {
			return err
		}
		defer conn.Close()
		deadline := 2 * time.Second // Blocked answers never depend on upstream DNS.
		if !wantBlocked {
			deadline = 8 * time.Second // Allow both upstream resolvers to fail over.
		}
		if err = conn.SetDeadline(time.Now().Add(deadline)); err != nil {
			return fmt.Errorf("consulta %q: %w", host, err)
		}
		if _, err = conn.Write(q); err != nil {
			return err
		}
		r := make([]byte, 4096)
		n, err := conn.Read(r)
		if err != nil {
			return fmt.Errorf("consulta %q en %s: %w", host, addr, err)
		}
		if n < 12 || r[0] != q[0] || r[1] != q[1] {
			return errors.New("respuesta DNS inválida")
		}
		rcode := r[3] & 15
		if wantBlocked {
			if rcode != 3 {
				return fmt.Errorf("%s debería bloquearse: rcode=%d", host, rcode)
			}
		} else if rcode != 0 || binary.BigEndian.Uint16(r[6:8]) == 0 {
			return fmt.Errorf("%s debería resolver: rcode=%d; respuestas=%d", host, rcode, binary.BigEndian.Uint16(r[6:8]))
		}
		return nil
	}
	if e := check(blocked, true); e != nil {
		return e
	}
	if e := check(allowed, false); e != nil {
		return e
	}
	return nil
}
