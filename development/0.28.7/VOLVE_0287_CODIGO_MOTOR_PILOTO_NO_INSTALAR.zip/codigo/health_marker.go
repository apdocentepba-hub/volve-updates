package main

import (
	"bytes"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"strings"
	"unicode/utf16"
	"unicode/utf8"
)

var allowedHealthMarkers = map[string]struct{}{
	"VOLVE_DNS_ADAPTER_OK":        {},
	"VOLVE_DNS_ADAPTER_MISMATCH":  {},
	"VOLVE_DNS_ADAPTER_NOT_FOUND": {},
}

// A health marker is trusted only when it is the entire stdout response.
// Never accept an apparently valid marker hidden inside an error or CLIXML.
func parseHealthMarker(stdout, stderr []byte, cmdErr error) (string, error) {
	if len(stdout) > 16384 || len(stderr) > 16384 {
		return "", errors.New("salida de PowerShell excesiva")
	}
	if cmdErr != nil {
		return "", fmt.Errorf("PowerShell falló (%v)", cmdErr)
	}
	if len(bytes.TrimSpace(stderr)) > 0 && !onlyPowerShellProgress(stderr) {
		return "", errors.New("PowerShell informó errores o advertencias, no solo progreso")
	}
	s, err := decodeHealthText(stdout)
	if err != nil {
		return "", err
	}
	s = strings.TrimSpace(s)
	if _, ok := allowedHealthMarkers[s]; !ok {
		if s == "" {
			return "", errors.New("PowerShell no devolvió un resultado")
		}
		return "", errors.New("PowerShell devolvió una salida distinta del marcador esperado")
	}
	return s, nil
}

func decodeHealthText(b []byte) (string, error) {
	if bytes.HasPrefix(b, []byte{0xef, 0xbb, 0xbf}) {
		b = b[3:]
	}
	little, big := false, false
	if bytes.HasPrefix(b, []byte{0xff, 0xfe}) {
		little = true
		b = b[2:]
	} else if bytes.HasPrefix(b, []byte{0xfe, 0xff}) {
		big = true
		b = b[2:]
	}
	if !little && !big && len(b) > 3 && b[1] == 0 && b[3] == 0 {
		little = true
	}
	if !little && !big && len(b) > 3 && b[0] == 0 && b[2] == 0 {
		big = true
	}
	if little || big {
		if len(b)%2 != 0 {
			return "", errors.New("salida UTF-16 incompleta")
		}
		words := make([]uint16, len(b)/2)
		for i := range words {
			if little {
				words[i] = uint16(b[i*2]) | uint16(b[i*2+1])<<8
			} else {
				words[i] = uint16(b[i*2])<<8 | uint16(b[i*2+1])
			}
		}
		return string(utf16.Decode(words)), nil
	}
	if !utf8.Valid(b) {
		return "", errors.New("codificación de PowerShell no reconocida")
	}
	return string(b), nil
}

// Some Windows PowerShell 5.1 cmdlets emit harmless CLIXML progress to stderr
// even when the command succeeds. Accept this ONLY if every top-level CLIXML
// object declares S="progress". Errors, warnings and any free text are rejected.
func onlyPowerShellProgress(stderr []byte) bool {
	s, err := decodeHealthText(stderr)
	if err != nil {
		return false
	}
	s = strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(s), "#< CLIXML"))
	if !strings.HasPrefix(s, "<Objs") {
		return false
	}
	decoder := xml.NewDecoder(strings.NewReader(s))
	depth, seenRoot, count := 0, false, 0
	for {
		tok, e := decoder.Token()
		if errors.Is(e, io.EOF) {
			break
		}
		if e != nil {
			return false
		}
		switch v := tok.(type) {
		case xml.StartElement:
			if depth == 0 {
				if seenRoot || v.Name.Local != "Objs" {
					return false
				}
				seenRoot = true
			} else if depth == 1 {
				if v.Name.Local != "Obj" {
					return false
				}
				progress := false
				for _, a := range v.Attr {
					if a.Name.Local == "S" && a.Value == "progress" {
						progress = true
					}
				}
				if !progress {
					return false
				}
				count++
			}
			depth++
		case xml.EndElement:
			depth--
			if depth < 0 {
				return false
			}
		case xml.CharData:
			if depth <= 1 && strings.TrimSpace(string(v)) != "" {
				return false
			}
		}
	}
	return seenRoot && depth == 0 && count > 0
}
