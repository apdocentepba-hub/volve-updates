//go:build windows

package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"
)

// reportProtectionHealth performs READ-ONLY checks. It intentionally does not
// refresh feeds, start tasks or adjust a single DNS server. This command is
// safe to run from a separate newer panel against an existing 0.27.0 worker.
func reportProtectionHealth() (string, error) {
	var out strings.Builder
	out.WriteString("VOLVÉ | COMPROBACIÓN DE PROTECCIÓN REAL (solo lectura)\n")
	out.WriteString("No se modificaron DNS, tareas, hosts ni navegadores.\n\n")
	root, err := installRoot()
	if err != nil {
		return out.String(), err
	}
	journalFile := filepath.Join(root, rescueJournal)
	raw, err := os.ReadFile(journalFile)
	if errors.Is(err, os.ErrNotExist) {
		out.WriteString("ACTIVACIÓN: no existe registro de activación DNS.\n")
		out.WriteString("No se puede afirmar que Windows use VOLVÉ. No pulses activar para hacer esta comprobación.\n")
		return out.String(), nil
	}
	if protectedJournalRead(err) {
		out.WriteString("RESPALDO: protegido por Windows (acceso denegado).\n")
		out.WriteString("La protección NO se puede confirmar con permisos normales.\n")
		out.WriteString("Pulsá «Comprobar protección REAL» y aceptá el permiso de administrador para un diagnóstico completo.\n")
		out.WriteString("No se cambiaron permisos ni configuración DNS.\n")
		return out.String(), nil
	}
	if err != nil {
		return out.String(), fmt.Errorf("no se puede leer respaldo de activación: %w", err)
	}
	if len(raw) > 8192 {
		return out.String(), errors.New("registro de activación demasiado grande; no se confía en sus datos")
	}
	var j dnsProductionBackup
	if err := json.Unmarshal(raw, &j); err != nil {
		return out.String(), fmt.Errorf("registro de activación inválido: %w", err)
	}
	if j.Schema != 1 || j.Mode != "automatic" || j.Phase != "active" || j.InterfaceIndex < 1 {
		out.WriteString("ACTIVACIÓN: registro pendiente o inconsistente, estado real NO confirmado.\n")
		out.WriteString("Conservá el BAT de recuperación. No repitas la activación.\n")
		return out.String(), nil
	}
	if !regexp.MustCompile(`(?i)^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$`).MatchString(j.InterfaceGUID) {
		return out.String(), errors.New("registro sin GUID válido; no se consulta ni modifica el adaptador")
	}
	out.WriteString("ACTIVACIÓN: registro activo; comprobar el motor y la configuración de Windows.\n")

	// Detect a local DNS motor which answers both blocked and permitted names.
	// The direct probes bypass the hosts file, just like nslookup -Server does.
	if e := checkDNSLocal(); e != nil {
		fmt.Fprintf(&out, "MOTOR: FALLA de comprobación DNS directa: %v\n", e)
	} else {
		out.WriteString("MOTOR: OK. Bet bloqueada y dominio permitido resuelto por IPv4 e IPv6.\n")
	}

	// Use the adapter GUID, never a possibly stale interface index after reboot.
	// The output is a fixed marker; no IPs are interpolated from user data.
	script := `$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';` +
		`$g='` + j.InterfaceGUID + `';` +
		`$adapters=@(Get-NetAdapter -ErrorAction Stop | Where-Object {([string]$_.InterfaceGuid).Trim('{}') -ieq $g});` +
		`if($adapters.Count -ne 1){[Console]::Out.WriteLine('VOLVE_DNS_ADAPTER_NOT_FOUND');exit 0};` +
		`$idx=[int]$adapters[0].ifIndex;` +
		`$v4=@((Get-DnsClientServerAddress -InterfaceIndex $idx -AddressFamily IPv4 -ErrorAction Stop).ServerAddresses | Where-Object {$_});` +
		`$v6=@((Get-DnsClientServerAddress -InterfaceIndex $idx -AddressFamily IPv6 -ErrorAction Stop).ServerAddresses | Where-Object {$_});` +
		`if($v4.Count -eq 1 -and $v4[0] -eq '127.0.0.1' -and $v6.Count -eq 1 -and $v6[0] -eq '::1'){` +
		`[Console]::Out.WriteLine('VOLVE_DNS_ADAPTER_OK')` +
		`}else{[Console]::Out.WriteLine('VOLVE_DNS_ADAPTER_MISMATCH')}`
	result, er := queryAdapterMarker(script)
	switch {
	case er != nil:
		fmt.Fprintf(&out, "WINDOWS DNS: NO VERIFICABLE; %v.\n", er)
	case strings.TrimSpace(result) == "VOLVE_DNS_ADAPTER_OK":
		out.WriteString("WINDOWS DNS: OK. Ethernet original usa exclusivamente 127.0.0.1 y ::1.\n")
	case strings.TrimSpace(result) == "VOLVE_DNS_ADAPTER_MISMATCH":
		out.WriteString("WINDOWS DNS: ATENCIÓN. Uno o ambos DNS ya no apuntan exclusivamente al filtro.\n")
	case strings.TrimSpace(result) == "VOLVE_DNS_ADAPTER_NOT_FOUND":
		out.WriteString("WINDOWS DNS: ATENCIÓN. No se identifica el adaptador original por GUID.\n")
	default:
		out.WriteString("WINDOWS DNS: respuesta no reconocida; resultado NO verificable.\n")
	}

	// ScheduledTask may refuse queries from a non-admin panel. This is not a
	// reason to call an actually running filter inactive.
	exe, _ := installedExe()
	rootWatchdog := filepath.Join(root, "VOLVE_DNS_Watchdog_0270.ps1")
	for _, task := range []struct{ label, name, target, arg string }{
		{"Servicio al iniciar Windows", dnsServiceTask, exe, "--dns-service"},
		{"Rescate independiente", dnsRescueTask, filepath.Join(os.Getenv("WINDIR"), "System32", "WindowsPowerShell", "v1.0", "powershell.exe"), "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File " + `"` + rootWatchdog + `"`},
	} {
		ok, e := confirmOwnTask(task.name, task.target, task.arg)
		switch {
		case e != nil:
			fmt.Fprintf(&out, "%s: NO VERIFICABLE (%s); tarea no modificada.\n", task.label, explainTaskReason(e))
			if strings.Contains(strings.ToLower(e.Error()), "argumentos distintos") {
				if detail := explainTaskArgumentMismatch(task.name, task.arg); detail != "" {
					fmt.Fprintln(&out, detail)
				}
			}
		case !ok:
			fmt.Fprintf(&out, "%s: NO ENCONTRADA.\n", task.label)
		default:
			fmt.Fprintf(&out, "%s: registrada y propiedad verificable (ejecución futura no demostrada).\n", task.label)
		}
	}
	full := filepath.Join(root, "catalog", "feeds", "hagezi_gambling_full.txt")
	if st, e := os.Stat(full); e == nil {
		age := time.Since(st.ModTime())
		if age < 0 {
			age = 0
		}
		fmt.Fprintf(&out, "CATÁLOGO: archivo Full presente; última modificación hace %.1f horas.\n", age.Hours())
		if age > 3*time.Hour {
			out.WriteString("ACTUALIZADOR: revisar tarea horaria, fuente o conectividad; archivo no modificado recientemente.\n")
		}
	} else {
		out.WriteString("CATÁLOGO: no se pudo comprobar archivo Full.\n")
	}
	out.WriteString("\nLIMITACIONES: esta comprobación no valida recuperación tras corte de energía, actualización horaria, VPN ni aplicaciones con DNS propio.\n")
	return out.String(), nil
}
