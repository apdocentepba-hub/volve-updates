//go:build windows

package main

import (
	"encoding/xml"
	"strings"
	"unicode"
)

// Only diagnostic text; never modifies a scheduled task or relaxes ownership.
// The expected action is still required to match exactly in confirmOwnTask.
func explainTaskArgumentMismatch(name, expected string) string {
	data, exists, e := taskQuery(name)
	if e != nil || !exists {
		return "DETALLE: no se pudo volver a leer la tarea."
	}
	text, e := decodeTaskXML(data)
	if e != nil {
		return "DETALLE: no se pudo decodificar XML."
	}
	if i := strings.Index(text, "?>"); i >= 0 && strings.HasPrefix(strings.TrimSpace(text), "<?xml") {
		text = strings.TrimSpace(text[i+2:])
	}
	var d taskDocument
	if e = xml.Unmarshal([]byte(text), &d); e != nil || len(d.Actions.Exec) != 1 {
		return "DETALLE: la tarea no tiene una acción identificable."
	}
	return "DETALLE parámetros esperados: " + printableTaskArg(expected) + "\n" +
		"DETALLE parámetros encontrados: " + printableTaskArg(d.Actions.Exec[0].Arguments)
}

func printableTaskArg(s string) string {
	if len(s) > 340 {
		s = s[:340] + "..."
	}
	return strings.Map(func(r rune) rune {
		if r == '\t' {
			return ' '
		}
		if unicode.IsControl(r) {
			return ' '
		}
		return r
	}, s)
}
