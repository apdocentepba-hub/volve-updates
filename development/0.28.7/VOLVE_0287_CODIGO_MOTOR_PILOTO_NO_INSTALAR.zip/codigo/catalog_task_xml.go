package main

import (
	"encoding/binary"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"strings"
	"unicode/utf16"
	"unicode/utf8"
)

// schtasks /Query /XML may return UTF-16LE, UTF-16BE, UTF-8, or UTF-8 with BOM
// depending on Windows build and the caller's console. Never compare raw bytes.
func decodeTaskXML(b []byte) (string, error) {
	if len(b) == 0 || len(b) > (1<<20) {
		return "", errors.New("XML de tarea vacío o demasiado grande")
	}
	if len(b) >= 3 && string(b[:3]) == "\xef\xbb\xbf" {
		b = b[3:]
	}
	var order binary.ByteOrder = binary.LittleEndian
	offset := 0
	if len(b) >= 2 && b[0] == 0xff && b[1] == 0xfe {
		offset = 2
	} else if len(b) >= 2 && b[0] == 0xfe && b[1] == 0xff {
		offset = 2
		order = binary.BigEndian
	} else if len(b) >= 2 && b[0] == '<' && b[1] == 0 { // no BOM
	} else if len(b) >= 2 && b[0] == 0 && b[1] == '<' {
		order = binary.BigEndian
	} else if utf8.Valid(b) && !strings.ContainsRune(string(b), '\x00') {
		return string(b), nil
	} else {
		return "", errors.New("codificación de XML de tarea no reconocida")
	}
	b = b[offset:]
	if len(b)%2 != 0 {
		return "", errors.New("XML UTF-16 truncado")
	}
	words := make([]uint16, len(b)/2)
	for i := range words {
		words[i] = order.Uint16(b[2*i : 2*i+2])
	}
	result := string(utf16.Decode(words))
	if strings.HasPrefix(result, "\ufeff") {
		result = strings.TrimPrefix(result, "\ufeff")
	}
	return result, nil
}

type taskExec struct {
	Command   string `xml:"Command"`
	Arguments string `xml:"Arguments"`
}
type taskDocument struct {
	XMLName xml.Name `xml:"Task"`
	Actions struct {
		Exec     []taskExec `xml:"Exec"`
		InnerXML string     `xml:",innerxml"`
	} `xml:"Actions"`
	Principals struct {
		Principal []struct {
			UserID string `xml:"UserId"`
		} `xml:"Principal"`
	} `xml:"Principals"`
}

func normalizedWinPath(s string) string {
	// Safe comparison only: don't resolve symlinks or expand environment variables.
	s = strings.TrimSpace(strings.Trim(s, `"`))
	s = strings.ReplaceAll(s, "/", `\`)
	s = strings.TrimPrefix(s, `\\?\`)
	// filepath.Clean on Linux does not understand Windows separators.
	parts := strings.Split(s, `\`)
	var out []string
	for _, p := range parts {
		if p == "" || p == "." {
			continue
		}
		if p == ".." {
			return ""
		}
		out = append(out, p)
	}
	return strings.ToLower(strings.Join(out, `\`))
}

// Legacy XML may be UTF-16. A task is only ours if it has precisely one
// executable, the expected full executable path, the exact --refresh argument,
// and its principal is LocalSystem. A substring match would be unsafe.
func verifyTaskXML(raw []byte, exe string) error {
	return verifySystemTaskXML(raw, exe, "--refresh")
}

// Exact action + SYSTEM identity. A substring match is unsafe.
func verifySystemTaskXML(raw []byte, exe, arguments string) error {
	docText, e := decodeTaskXML(raw)
	if e != nil {
		return e
	}
	// XML declares encoding="utf-16", although Go's xml.Decoder takes UTF-8.
	// Remove only the declaration, preserving the original elements/contents.
	if i := strings.Index(docText, "?>"); i >= 0 && strings.HasPrefix(strings.TrimSpace(docText), "<?xml") {
		docText = strings.TrimSpace(docText[i+2:])
	}
	var doc taskDocument
	if e = xml.Unmarshal([]byte(docText), &doc); e != nil {
		return fmt.Errorf("XML de tarea inválido: %w", e)
	}
	// Reject a task with additional actions even when its first Exec matches.
	decoder := xml.NewDecoder(strings.NewReader(doc.Actions.InnerXML))
	depth, actionCount := 0, 0
	for {
		tok, er := decoder.Token()
		if er != nil {
			if errors.Is(er, io.EOF) {
				break
			}
			return fmt.Errorf("acciones de tarea inválidas: %w", er)
		}
		switch e := tok.(type) {
		case xml.StartElement:
			if depth == 0 {
				if e.Name.Local != "Exec" {
					return errors.New("la tarea tiene acciones ajenas; se conserva")
				}
				actionCount++
			}
			depth++
		case xml.EndElement:
			depth--
		}
	}
	if actionCount != 1 {
		return errors.New("número de acciones no reconocido")
	}
	if len(doc.Actions.Exec) != 1 || normalizedWinPath(doc.Actions.Exec[0].Command) == "" || normalizedWinPath(doc.Actions.Exec[0].Command) != normalizedWinPath(exe) {
		return errors.New("la tarea existente tiene otro ejecutable; se conserva sin modificar")
	}
	if strings.TrimSpace(doc.Actions.Exec[0].Arguments) != strings.TrimSpace(arguments) {
		return errors.New("la tarea existente tiene argumentos distintos; se conserva sin modificar")
	}
	if len(doc.Principals.Principal) != 1 {
		return errors.New("la tarea no declara un solo principal; se conserva")
	}
	user := strings.ToLower(strings.TrimSpace(doc.Principals.Principal[0].UserID))
	if user != "s-1-5-18" && user != "system" && user != `nt authority\system` {
		return errors.New("la tarea no pertenece a SYSTEM; se conserva")
	}

	return nil
}
