//go:build windows

package singlefile

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"os"
	"path/filepath"
	"testing"
)

func TestWindowsAuthenticodeRejectsSyntheticUnsignedAndMissingPins(t *testing.T) {
	root, pub, _ := fixture(t)
	exe := filepath.Join(t.TempDir(), "VOLVE_Setup_LAB.exe")
	if err := Assemble(fakePE(t), root, exe, pub); err != nil {
		t.Fatal(err)
	}
	data, err := os.ReadFile(exe)
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(data)
	filePin := hex.EncodeToString(sum[:])
	empty := "0000000000000000000000000000000000000000000000000000000000000000"
	for _, tc := range []struct{ name, cert, file string }{
		{"no-cert-pin", "", filePin}, {"no-file-pin", empty, ""},
		{"bad-file-pin", empty, empty}, {"unsigned-pe", empty, filePin},
	} {
		t.Run(tc.name, func(t *testing.T) {
			if err := VerifyWindowsPublisherSignature(context.Background(), exe, tc.cert, tc.file); err == nil {
				t.Fatal("unsafe EXE accepted")
			}
		})
	}
}
func TestWindowsAuthenticodeRejectsCancellation(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	pin := "0000000000000000000000000000000000000000000000000000000000000000"
	if err := VerifyWindowsPublisherSignature(ctx, "C:\\missing.exe", pin, pin); err == nil {
		t.Fatal("cancelled context accepted")
	}
}

// The hosted Windows CI injects a real Microsoft-signed OS executable and
// cert/file SHA256 pins computed independently. The test proves WinTrust
// Status=Valid and the strict certificate pin against a real signature.
func TestWindowsAuthenticodeAcceptsRealTrustedSystemEXE(t *testing.T) {
	if os.Getenv("GITHUB_ACTIONS") != "true" || os.Getenv("RUNNER_ENVIRONMENT") != "github-hosted" {
		t.Skip("requires a hosted disposable Windows CI and real signed system executable")
	}
	path := os.Getenv("VOLVE_CI_AUTHENTICODE_OS_BINARY")
	cert := os.Getenv("VOLVE_CI_AUTHENTICODE_CERT_SHA256")
	file := os.Getenv("VOLVE_CI_AUTHENTICODE_FILE_SHA256")
	if path == "" || cert == "" || file == "" {
		t.Fatal("missing independent signed Windows executable fixture")
	}
	if err := VerifyWindowsPublisherSignature(context.Background(), path, cert, file); err != nil {
		t.Fatalf("genuine signed Windows PE rejected: %v", err)
	}
	wrong := "0000000000000000000000000000000000000000000000000000000000000000"
	if cert == wrong {
		t.Fatal("zero pinned certificate is not an acceptable fixture")
	}
	if err := VerifyWindowsPublisherSignature(context.Background(), path, wrong, file); err == nil {
		t.Fatal("wrong certificate pin was accepted")
	}
}
