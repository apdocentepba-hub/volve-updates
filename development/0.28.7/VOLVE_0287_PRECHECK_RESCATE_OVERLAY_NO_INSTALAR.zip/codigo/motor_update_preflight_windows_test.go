//go:build windows

package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestMotorJournalReadOnlyRejectsUnsafeStates(t *testing.T) {
	valid := dnsProductionBackup{Schema: 1, Phase: "active", Mode: "automatic", InterfaceIndex: 4, InterfaceGUID: "abcd-1234", ActivatedAt: time.Now().UTC().Format(time.RFC3339)}
	raw, _ := json.Marshal(valid)
	if _, err := validateMotorRescueJournal(raw); err != nil {
		t.Fatalf("valid: %v", err)
	}
	cases := [][]byte{[]byte(`{"schema":1,"phase":"pending","mode":"automatic","interface_index":4,"interface_guid":"abcd","activated_at":"2026-10-29T15:00:00Z"}`),
		[]byte(`{"schema":1,"phase":"active","mode":"manual","interface_index":4,"interface_guid":"abcd","activated_at":"2026-10-29T15:00:00Z"}`),
		[]byte(`{"schema":1,"phase":"active","mode":"automatic","interface_index":0,"interface_guid":"abcd","activated_at":"2026-10-29T15:00:00Z"}`),
		[]byte(`{"schema":1,"phase":"active","mode":"automatic","interface_index":4,"interface_guid":"abcd","activated_at":"2026-10-29T15:00:00Z","execute":"evil"}`),
		append(raw, []byte(` {}`)...),
		nil,
	}
	for i, c := range cases {
		if _, err := validateMotorRescueJournal(c); err == nil {
			t.Errorf("case %d accepted", i)
		}
	}
}
func TestMotorPreflightOnlyReadsKnownFiles(t *testing.T) {
	dir := t.TempDir()
	file := filepath.Join(dir, "VOLVE_DNS_Watchdog_0270.ps1")
	if err := os.WriteFile(file, []byte("correct script"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := verifyExactRescueScript(file, "correct script"); err != nil {
		t.Fatal(err)
	}
	if err := verifyExactRescueScript(file, "other script"); err == nil {
		t.Fatal("unknown script accepted")
	}
	if _, err := digestMotorFile(file); err != nil {
		t.Fatal(err)
	}
	if err := os.Mkdir(filepath.Join(dir, "directory"), 0700); err != nil {
		t.Fatal(err)
	}
	if _, err := digestMotorFile(filepath.Join(dir, "directory")); err == nil {
		t.Fatal("directory accepted")
	}
	if err := os.WriteFile(file, nil, 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := digestMotorFile(file); err == nil {
		t.Fatal("empty file accepted")
	}
	if !strings.Contains(file, "Watchdog") {
		t.Fatal("test error")
	}
}
