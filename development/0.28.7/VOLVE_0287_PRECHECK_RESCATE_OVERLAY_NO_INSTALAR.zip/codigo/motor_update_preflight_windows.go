//go:build windows

package main

// This is an intentionally READ-ONLY gate for a future motor switchover.
// The developer pilot does not expose any code path to change SYSTEM tasks,
// the current DNS configuration, the watchdog, or the DNS-rescue journal.
import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const motorPreflightMaxFileBytes = 80 << 20

func safeRegularFile(path string, max int64) (os.FileInfo, error) {
	info, err := os.Lstat(path)
	if err != nil {
		return nil, err
	}
	if !info.Mode().IsRegular() || info.Size() <= 0 || info.Size() > max {
		return nil, fmt.Errorf("archivo no regular o tamaño no autorizado: %s", filepath.Base(path))
	}
	return info, nil
}

func digestMotorFile(path string) (string, error) {
	if _, err := safeRegularFile(path, motorPreflightMaxFileBytes); err != nil {
		return "", err
	}
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	n, err := io.Copy(h, io.LimitReader(f, motorPreflightMaxFileBytes+1))
	if err != nil {
		return "", err
	}
	if n <= 0 || n > motorPreflightMaxFileBytes {
		return "", errors.New("motor de tamaño no permitido")
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

func verifyExactRescueScript(path, expected string) error {
	if _, err := safeRegularFile(path, 1<<20); err != nil {
		return err
	}
	got, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	if !bytes.Equal(got, []byte(expected)) {
		return fmt.Errorf("script de emergencia distinto del original: %s", filepath.Base(path))
	}
	return nil
}

func validateMotorRescueJournal(raw []byte) (dnsProductionBackup, error) {
	var j dnsProductionBackup
	if len(raw) == 0 || len(raw) > 16384 {
		return j, errors.New("registro DNS ausente o excesivo")
	}
	dec := json.NewDecoder(bytes.NewReader(raw))
	dec.DisallowUnknownFields()
	if err := dec.Decode(&j); err != nil {
		return j, fmt.Errorf("registro DNS inválido: %w", err)
	}
	var extra any
	if dec.Decode(&extra) != io.EOF {
		return j, errors.New("datos adicionales en el registro DNS")
	}
	if j.Schema != 1 || j.Phase != "active" || j.Mode != "automatic" || j.InterfaceIndex <= 0 || strings.TrimSpace(j.InterfaceGUID) == "" {
		return j, errors.New("el registro DNS no está activo o no permite recuperar DHCP")
	}
	if _, err := time.Parse(time.RFC3339, j.ActivatedAt); err != nil {
		return j, errors.New("fecha de activación DNS no verificable")
	}
	return j, nil
}

// preflightMotorUpgradeReadOnly checks evidence that the existing motor and
// independent rescue are positively owned by VOLVÉ. Importantly, a successful
// report is NOT authorization to swap tasks: an independent watchdog/rollback
// after process termination still needs real validation on Windows.
func preflightMotorUpgradeReadOnly() (string, error) {
	if !isAdmin() {
		return "", errors.New("diagnóstico requiere administrador; no se modificó Windows")
	}
	root, err := installRoot()
	if err != nil {
		return "", err
	}
	exe := filepath.Join(root, dnsServiceFile)
	exeHash, err := digestMotorFile(exe)
	if err != nil {
		return "", fmt.Errorf("motor instalado no verificable: %w", err)
	}
	rawTask, exists, err := taskQuery(dnsServiceTask)
	if err != nil {
		return "", err
	}
	if !exists {
		return "", errors.New("tarea del motor no encontrada")
	}
	if err := verifySystemTaskXML(rawTask, exe, "--dns-service"); err != nil {
		return "", fmt.Errorf("la tarea SYSTEM del motor no coincide: %w", err)
	}
	watchdog := filepath.Join(root, "VOLVE_DNS_Watchdog_0270.ps1")
	rescue := filepath.Join(root, rescueFile)
	if err := verifyExactRescueScript(watchdog, watchdogPS); err != nil {
		return "", err
	}
	if err := verifyExactRescueScript(rescue, rescuePS); err != nil {
		return "", err
	}
	winDir := os.Getenv("WINDIR")
	if winDir == "" || !filepath.IsAbs(winDir) {
		return "", errors.New("directorio Windows no identificable")
	}
	psExe := filepath.Join(winDir, "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
	rawRescue, exists, err := taskQuery(dnsRescueTask)
	if err != nil {
		return "", err
	}
	if !exists {
		return "", errors.New("tarea SYSTEM de rescate no encontrada")
	}
	if err := verifySystemTaskXML(rawRescue, psExe, expectedRescueArgs(watchdog)); err != nil {
		return "", fmt.Errorf("la tarea SYSTEM de rescate no coincide: %w", err)
	}
	journal, err := backupPath()
	if err != nil {
		return "", err
	}
	if _, err := safeRegularFile(journal, 16384); err != nil {
		return "", fmt.Errorf("sin respaldo DNS recuperable: %w", err)
	}
	data, err := os.ReadFile(journal)
	if err != nil {
		return "", err
	}
	j, err := validateMotorRescueJournal(data)
	if err != nil {
		return "", err
	}
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	done := make(chan error, 1)
	go func() { done <- checkDNSLocal() }()
	select {
	case err = <-done:
	case <-ctx.Done():
		err = ctx.Err()
	}
	if err != nil {
		return "", fmt.Errorf("motor DNS no responde en ambas familias: %w", err)
	}
	return fmt.Sprintf("VOLVÉ — EVALUACIÓN DE MOTOR (SOLO LECTURA)\nMotor heredado: %s\nSHA-256: %s\nTarea SYSTEM: propiedad verificada\nRescate SYSTEM: propiedad verificada\nScripts de rescate: íntegros\nRegistro de recuperación: activo (adaptador %d)\nDNS IPv4 e IPv6: pruebas correctas\n\nNO se modificaron DNS, binarios ni tareas. NO se autorizó actualizar el motor. La reversión ante corte de energía sigue sin probarse.", filepath.Base(exe), exeHash, j.InterfaceIndex), nil
}
