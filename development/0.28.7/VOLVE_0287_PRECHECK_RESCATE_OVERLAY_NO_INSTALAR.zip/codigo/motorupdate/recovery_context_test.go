package motorupdate

import (
	"context"
	"errors"
	"strings"
	"testing"
)

// DNS recovery must not be canceled merely because the update was canceled.
type cancelingSwitch struct {
	fakeDriver
	cancel                  context.CancelFunc
	sawFreshRecoveryContext bool
}

func (d *cancelingSwitch) Switch(ctx context.Context) error {
	d.cancel()
	return ctx.Err()
}
func (d *cancelingSwitch) Restore(ctx context.Context) error {
	if ctx.Err() != nil {
		return errors.New("recovery reused canceled context")
	}
	d.sawFreshRecoveryContext = true
	return d.fakeDriver.Restore(ctx)
}
func (d *cancelingSwitch) Probe(ctx context.Context) error {
	if ctx.Err() != nil {
		return errors.New("probe reused canceled context")
	}
	return d.fakeDriver.Probe(ctx)
}
func TestCanceledUpgradeStillRecoversOriginalEngine(t *testing.T) {
	path, key := stagedTestFile(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	d := &cancelingSwitch{cancel: cancel}
	err := ApplyWithRollback(ctx, path, key, "0.27.0", "0.28.7", d)
	if err == nil || !strings.Contains(err.Error(), "revertida") || !d.sawFreshRecoveryContext || !d.recovered {
		t.Fatalf("rollback after cancellation not verified: %v, %+v", err, d)
	}
}
